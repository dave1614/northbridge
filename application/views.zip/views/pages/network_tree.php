
<style>
  img{
    width: 100%;
    height: 350px;
  }

  
  #edit-profile-form{
    margin-top: 30px;
    margin-bottom: 30px;
  }

  #edit-profile-form label{
    color: #7ea960;
  }
  /*.btn.btn-primary:focus,
  .btn.btn-primary:active,
  .btn.btn-primary:hover{
    color: #7ea960;
    background-color: #fff;
    border-color: #7ea960;
  }*/

  /*#submit-button:hover {
    background-image:none;
   }

  .btn.btn-primary{
    color: #fff;
    background-color: #7ea960;
    border-color: #7ea960;
    transition: 2s;
  }
*/
  .heading-text{
    color: #7ea960;
    font-size: 35px;
    font-weight: bold;
    margin-top: 35px;
  }

  form .btn.btn-submit{
    background-color: #7ea960;
    border-color: #7ea960;
    color: #fff;

  }

  form .spinner-border{
      display: none;
    }
</style>
<script>
  function goDownMlm(elem,event,mlm_db_id,your_mlm_db_id){
    elem = $(elem);
    var package = elem.attr("data-package");
    $(".spinner-overlay").show();
    var form_data = {
      show_records : true,
      mlm_db_id : mlm_db_id,
      your_mlm_db_id : your_mlm_db_id,
      package : package
    }
    var url = "<?php echo site_url('sabicapital/view_your_genealogy_tree_down'); ?>"
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : form_data,
      success : function (response) {
        $(".spinner-overlay").hide();
        if(response.success && response.messages != ""){
          var messages = response.messages;

          $("#network-tree-card .card-body").html(messages);
          $("#network-tree-card .tf-tree .tf-nc .user-name").each(function(index, el) {
            var user_name = $(this).html();
            var formatted_username = user_name.slice(0,-4);
            $(this).html(formatted_username);
          }); 
          $("#body-cont").show();
        }else{
          swal({
            title: 'Ooops',
            text: "Something Went Wrong",
            type: 'warning'
          })
        }
      },error : function () {
        $(".spinner-overlay").hide();
        swal({
          title: 'Ooops',
          text: "Something Went Wrong",
          type: 'error'
        })
      }
    });
  }

  function goUpMlm(elem,event,mlm_db_id,your_mlm_db_id){
    elem = $(elem);
    var package = elem.attr("data-package");
    $(".spinner-overlay").show();
    var form_data = {
      show_records : true,
      mlm_db_id : your_mlm_db_id,
      package : package
    }
    var url = "<?php echo site_url('sabicapital/view_your_genealogy_tree'); ?>"
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : form_data,
      success : function (response) {
        $(".spinner-overlay").hide();
        if(response.success && response.messages != ""){
          var messages = response.messages;
          
          $("#network-tree-card .card-body").html(messages);
          $("#network-tree-card .tf-tree .tf-nc .user-name").each(function(index, el) {
            var user_name = $(this).html();
            var formatted_username = user_name.slice(0,-4);
            $(this).html(formatted_username);
          }); 
          $("#body-cont").show();
        }else{
          swal({
            title: 'Ooops',
            text: "Something Went Wrong",
            type: 'warning'
          })
        }
      },error : function () {
        $(".spinner-overlay").hide();
        swal({
          title: 'Ooops',
          text: "Something Went Wrong",
          type: 'error'
        })
      }
    });
  }
</script>
<link href="<?php echo base_url('assets/css/treeflex.css') ?>" rel="stylesheet">
  <style>
    .ratio{
      font-weight: bold;
    }
    .tf-tree{
      text-align: center;
      /*cursor: col-resize;*/
    }
  
    .tf-tree .tf-nc .name{
      font-size: 20px;
    }

    .tf-tree .tf-nc {
      width: 150px;
      height: 220px;
      background: #fff;
      border: 0;
      border-radius: 4px;
      position: relative;
      padding-bottom: 10px;
      /*cursor: pointer;*/

    }

    .tf-tree .tf-nc .icons-div{
      /*margin-top: 10px;
      margin-bottom: 20px;*/
      /*position: absolute; 
      bottom: 0px; */
    }

    .tf-nc.business{
      border: 5px solid #7ea960;
      box-shadow: 0 2px 6px 0 #7ea960;
    }

    .tf-nc.basic{
      border: 5px solid #7ea960;
      box-shadow: 0 2px 6px 0 #7ea960;
    }

    .tf-nc.basic .package{
      color: #7ea960;
      text-transform: uppercase;
      font-weight: 700;
    }

    .tf-nc.business .package{
      color: #7ea960;
      text-transform: uppercase;
      font-weight: 700;
    }
    .tf-nc .register-text{
      line-height: 200px;
      font-size: 19px;
      font-weight: bold;
    }

    .tf-nc.register{
      border: 5px solid #000;
    }

    .tf-tree .tf-nc .user-name{
      font-weight: bold;
      font-size: 18px;
      font-style: italic;
    }

    .tf-custom .tf-nc:before,
    .tf-custom .tf-nc:after {
      /* css here */
    }

    .tf-custom li li:before {
      /* css here */
    }

    .spinner{
      display: none;
    }

    .tf-tree{
      color: #7ea960;
    }

    .tf-tree img{
      display: none;
    }

    .tf-tree .package{
      display: none;
    }
  </style>
<!-- Page Content -->
  <div class="">
    <div class="container-fluid" style="min-height: 300px;">
      <div class="spinner-overlay" style="display: none; z-index: 20000000">
        <div class="spinner-well">
          <img src="<?php echo base_url('assets/images/tests_loader (2).gif') ?>" alt="Loading..." style="">
        </div>
      </div>

      <div class="" id="body-cont" style="display: none;">
        <h3 class="text-center heading-text">Your Network Tree</h3>
        <div class="row justify-content-center">
          <div id="network-tree-card" class="card shadow col-sm-10" style="min-height: 300px; margin-top: 30px;">
            <div class="card-body">
              
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div style="color: #7ea960;" class="modal fade" data-backdrop="static" id="settings-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title text-center" style="color: #7ea960; text-transform: capitalize;">Profile Settings</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" id="modal-body" style="padding: 0;">
          <div class="list-group">
            <a href="#" class="list-group-item" style="color: #7ea960;" onclick="changePasswordSelected(this,event)">Change Your Password</a>
            <a href="#" class="list-group-item" style="color: #7ea960;">Second item</a>
            <a href="#" class="list-group-item" style="color: #7ea960;">Third item</a>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
        </div>
      </div>
    </div>
  </div>

  <div  class="modal fade" data-backdrop="static" id="change-password-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title text-center" style="color: #7ea960; text-transform: capitalize;">Change Your Password</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" id="modal-body">
          <?php 
              $attr = array('class' => 'container','id' => 'change-password-form');
              echo form_open('sabicapital/process_sign_in',$attr);
            ?>

              <div class="form-group">
                
                <input type="text" class="form-control shadow-sm" id="old_password" name="old_password" placeholder="Enter Old Password">
                <span class="form-error"></span>
              </div>
              
              <div class="form-group">
                
                <input type="text" class="form-control shadow-sm" id="new_password" name="new_password" placeholder="Enter New Password">
                <span class="form-error"></span>
              </div>
              <button class="btn btn-submit btn-block text-center shadow-sm" type="submit">
                Submit 
                <!-- <div class="clearfix"> -->
                  <div style="margin-bottom:20px;" class="spinner-border spinner-border-sm float-right" role="status">
                    <span class="sr-only">Loading...</span>
                  </div>
                <!-- </div> -->
              </button>
              
            </form>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
        </div>
      </div>
    </div>
  </div>

  <div id="open-user-settings-modal-btn" onclick="openSettingsModal(this,event)" rel="tooltip" data-toggle="tooltip" title="User Settings" style="display: none; background: #7ea960; cursor: pointer; position: fixed; bottom: 0; right: 0;  border-radius: 50%; cursor: pointer; fill: #fff; height: 56px; outline: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.2);">
    <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
      <i class="fas fa-cog" style="font-size: 25px; color: #fff;" aria-hidden="true"></i>
    </div>
  </div>


  <script>
    $(document).ready(function () {
      $(".spinner-overlay").show();
      var form_data = {
        show_records : true
      }
      var url = "<?php echo site_url('sabicapital/view_your_genealogy_tree'); ?>"
      $.ajax({
        url : url,
        type : "POST",
        responseType : "json",
        dataType : "json",
        data : form_data,
        success : function (response) {
          $(".spinner-overlay").hide();
          if(response.success && response.messages != ""){
            var messages = response.messages;
            
            
            $("#network-tree-card .card-body").html(messages);

            $("#network-tree-card .tf-tree .tf-nc .user-name").each(function(index, el) {
              var user_name = $(this).html();
              var formatted_username = user_name.slice(0,-4);
              $(this).html(formatted_username);
            }); 
            
            $("#body-cont").show();
          }else{
            swal({
              title: 'Ooops',
              text: "Something Went Wrong",
              type: 'warning'
            }).then(function(){
              document.location.reload();
            });
          }
        },error : function () {
          $(".spinner-overlay").hide();
          swal({
            title: 'Ooops',
            text: "Something Went Wrong. Please Check Your Internet Connection.",
            type: 'error'
          }).then(function(){
            document.location.reload();
          });
        }
      });  
    })
  </script>