         <!-- End Navbar -->
<style>
  .tf-tree{
    text-align: center;
    /*cursor: col-resize;*/
  }
  .tf-tree .tf-nc {
    width: 186px;
    height: 264px;
    background: #fff;
    border: 0;
    border-radius: 4px;
    border: 3px solid #ff9800;
    cursor: pointer;
    box-shadow: 0 1px 4px 0 #ff9800;
  }

  .tf-tree .tf-nc .user-name{
    font-weight: bold;
  }

  .tf-custom .tf-nc:before,
  .tf-custom .tf-nc:after {
    /* css here */
  }

  .tf-custom li li:before {
    /* css here */
  }
</style>
<script>

</script>
7
<div class="spinner-overlay" style="display: none;">
  <div class="spinner-well">
    <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading...">
  </div>
</div>
<div class="content">
  <div class="container-fluid">

    <div class="tf-tree example">
      <ul>
        <li>
          <span class="tf-nc">1</span>
          <ul>
            <li>
              <span class="tf-nc">2</span>
              <ul>
                <li><span class="tf-nc">4</span></li>
                <li>
                  <span class="tf-nc">5</span>
                  <ul>
                    <li><span class="tf-nc">9</span></li>
                    <li><span class="tf-nc">10</span></li>
                  </ul>
                </li>
                <li><span class="tf-nc">6</span></li>
              </ul>
            </li>
            <li>
              <span class="tf-nc">3</span>
              <ul>
                <li><span class="tf-nc">7</span></li>
                <li><span class="tf-nc">8</span></li>
              </ul>
            </li>
          </ul>
        </li>
      </ul>
    </div>

    <div class="tf-tree">
      <ul>
        <li>
          <div class="tf-nc">
            <img class="" src="<?php echo base_url('assets/images/avatar21.jpg') ?>" style="width: 100%; border-radius: 50%; height: 50%;" alt="">
            <h4>Nwogo David</h4>
            <h5 class="user-name">dave1614</h5>
          </div>
          <ul>
            <li>
              <span class="tf-nc">2</span>
              <ul>
                <li>
                  <span class="tf-nc">4</span>
                  <ul>
                    <li><span class="tf-nc">8</span></li>
                    <li><span class="tf-nc">9</span></li>
                  </ul>
                </li>
                <li>
                  <span class="tf-nc">5</span>
                  <ul>
                    <li><span class="tf-nc">10</span></li>
                    <li><span class="tf-nc">11</span></li>
                  </ul>
                </li>
              </ul>
            </li>
            <li>
              <span class="tf-nc">3</span>
              <ul>
                <li>
                  <span class="tf-nc">6</span>
                  <ul>
                    <li><span class="tf-nc">12</span></li>
                    <li><span class="tf-nc">13</span></li>
                  </ul>
                </li>
                <li>
                  <span class="tf-nc">7</span>
                  <ul>
                    <li><span class="tf-nc">14</span></li>
                    <li><span class="tf-nc">15</span></li>
                  </ul>
                </li>
              </ul>
            </li>
          </ul>
          
        </li>
      </ul>
    </div>


    <div class="tf-tree">
      <ul>
        <li>
          <span class="tf-nc">1</span>
          <ul>
            
            <?php for($i = 2; $i <= 11; $i++){ ?>
            <li><span class="tf-nc"><?php echo $i; ?></span></li>
            <?php } ?>
          </ul>
        </li>
      </ul>
    </div>

    <?php

      $total = 1;
      $count = 1;
    ?>
    
    <?php
      for($i = 1; $i <= 4; $i++){
        for($j = 1; $j <= 2; $j++){
          $count *= $j;
        }
        $total += $count;
        echo $total . "<br>";
      }
      // echo $count . "<br>";
      // echo $total;
    ?>
    </div>
  </div>
  </div>
  <div id="submit-become-center-leader-form-btn" onclick="submitBecomeCenterLeaderForm(this,event)" rel="tooltip" data-toggle="tooltip" title="Submit The Form" style="background: #9c27b0; cursor: pointer; position: fixed; bottom: 0; right: 0;  border-radius: 50%; cursor: pointer; display: none; fill: #fff; height: 56px; outline: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.2);">
    <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
      <i class="fas fa-paper-plane" style="font-size: 25px; font-weight: normal; color: #fff;" aria-hidden="true"></i>
    </div>
  </div>
</div>
<footer class="footer">
  <div class="container-fluid">
    <!-- <footer>&copy; <?php echo date("Y"); ?> Copyright (meetglobal Issues Global Limited). All Rights Reserved</footer> -->
  </div>
</footer>

<script>
  $(document).ready(function () {
  })
</script>
</div>
</div>
  <!--   Core JS Files   -->
 