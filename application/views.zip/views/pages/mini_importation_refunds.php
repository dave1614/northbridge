
      <div class="spinner-overlay" style="display: none;">
        <div class="spinner-well">
          <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading...">
        </div>
      </div>
      
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <h2 class="text-center">Mini Importation Refunds History</h2>
          <div class="row">
            <div class="col-sm-12">
              <div class="card">
                <div class="card-header">
                  <h4 class="card-title">History Information</h4>
                  
                </div>

                <div class="card-body">
                  <?php
                  $mini_importation_refunds = $this->meetglobal_model->getMiniImportationRefunds();
                  $response_arr = array('messages' => '');
                  if(is_array($mini_importation_refunds)){
                    $j = 0;
                    
                    
                    $response_arr['messages'] .= '<div class="table-div material-datatables table-responsive" style="">';
                    $response_arr['messages'] .= '<table class="table table-striped table-bordered wrap hover display" id="orders-info-table" cellspacing="0" width="100%" style="width:100%">';
                    $response_arr['messages'] .= '<thead>';
                    $response_arr['messages'] .= '<tr>';
                    $response_arr['messages'] .= '<th>#</th>';
                    
                    $response_arr['messages'] .= '<th>Product Name</th>';
                    $response_arr['messages'] .= '<th>Amount</th>';
                    $response_arr['messages'] .= '<th>Date</th>';
                    
                    $response_arr['messages'] .= '</tr>';
                    $response_arr['messages'] .= '<tbody>';
                    foreach($mini_importation_refunds as $row){
                      $j++;
                      $id = $row->id;
                      $product_id = $row->product_id;
                      $amount = $row->amount;
                      $date = $row->date;
                      $time = $row->time;
                      
                      
                      $product_name = $this->meetglobal_model->getProductParamByIdMiniImportation("name",$product_id);
                      
                      $response_arr['messages'] .= "<tr>";

                      $response_arr['messages'] .= '<td>'.$j.'</td>';
                      
                      $response_arr['messages'] .= '<td style="text-transform : capitalize;">'.$product_name.'</td>';
                      $response_arr['messages'] .= '<td style="text-transform : capitalize;">₦ '.number_format($amount,2).'</td>';
                     
                      $response_arr['messages'] .= '<td style="text-transform : capitalize;">'.$date. ' ' . $time .'</td>';
                      $response_arr['messages'] .= "</tr>";
                        
                    }
                    $response_arr['messages'] .= "</tbody>";
                    $response_arr['messages'] .= "</table>";
                  }else{
                    $response_arr['messages'] .= "<h5 class='text-warning'>No History To Dispay.</h5>";
                  }
                  echo $response_arr['messages'];
                  ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    
      
    </div>
  </div>
  <!--   Core JS Files   -->
 <script>
    $(document).ready(function () {
      var table = $('table').DataTable()
    })
 </script>