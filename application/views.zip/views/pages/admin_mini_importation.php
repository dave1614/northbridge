         <!-- End Navbar -->

<script>



function goToDefaultPage () {
  window.location.assign("<?php echo site_url('meetglobal/admin_mini_importation'); ?>");
}

function manageBanners (elem,evt) {
  evt.preventDefault();
  $("#choose-action-card").hide();
  $("#manage-banners-card").show();
  $("#add-new-banner-btn").show("fast");
}

function goBackFromLiveProductsCard (elem,evt) {
  $("#manage-products-choose-action-card").show();
  $("#live-products-card").hide();
  $("#add-new-product-btn").hide("fast");
}

function addNewBanner(elem,evt){
  $("#manage-banners-card").hide();
  $("#add-new-banner-card").show();
  $("#add-new-banner-btn").hide("fast");

}

function goBackFromAddNewBannerCard (elem,evt) {
  $("#manage-banners-card").show();
  $("#add-new-banner-card").hide();
  $("#add-new-banner-btn").show("fast");
}

function submitNewBanner (elem,evt) {
  var me = $(elem);
  evt.preventDefault();
  var file_input = elem.querySelector("#banner_img");
  var product_id = elem.querySelector("#product_id").value;
  var url = me.attr("action");
  url += "?product_id="+product_id

  var files = file_input.files;
  console.log(files)
  var form_data = new FormData();
  var error = '';
  
  form_data.append("banner_img",files[0]);
  // form_data.append("product_id",product_id);
      
  $(".spinner-overlay").show();
  $.ajax({
    url : url,
    type : "POST",
    cache: false,
    dataType : "json",
    contentType: false,
    processData: false,
    data : form_data,
    success : function (response) {
      $(".spinner-overlay").hide();
      console.log(response)
      if(response.invalid_product_id){
        $.notify({
          message:"The Product Id Entered Is Invalid"
          },{
            type : "warning"  
        });
      }else if(response.wrong_extension){
        $.notify({
          message:"The File Uploaded Is Not A Valid Image Format"
          },{
            type : "warning"  
        });
      }else if(response.too_large){
        $.notify({
          message:"The File Upladed Is Too Large Max Is 200 KB"
          },{
            type : "warning"  
        });
      }else if(response.not_really_json){
        $.notify({
          message:"This File Format Is Not Really An Image File"
          },{
            type : "warning"  
        });
      }else if(response.success && response.image_name != ""){
        var image_name = response.image_name;
        $("#upload-signature-modal").modal("hide");
        $("#change-signature-modal").modal("hide");
        $.notify({
        message:"Your Signature Has Been Successfully Uploaded. You Can Now Request Death Certificate"
        },{
          type : "success"  
        });
      }else{
        $.notify({
          message:"Sorry Something Went Wrong."
          },{
            type : "warning" 
        });
      }
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    }
  });
}

function manageProducts (elem,evt) {
  evt.preventDefault();
  $("#choose-action-card").hide();
  $("#manage-products-choose-action-card").show();
  
}

function goBackManageProductsChooseAction (elem,evt) {
  $("#choose-action-card").show();
  $("#manage-products-choose-action-card").hide();
}

function liveProducts (elem,evt) {
  evt.preventDefault();
  var url = "<?php echo site_url('meetglobal/get_live_products_mini_importation') ?>"
  $(".spinner-overlay").show();
  $.ajax({
    url : url,
    type : "POST",
    cache: false,
    dataType : "json",
    responseType: "json",
    data : "show_records=true",
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success && response.messages != "") {
        $("#manage-products-choose-action-card").hide();
        $("#live-products-card .card-body").html(response.messages);
        $("#live-products-card").show();
        $("#add-new-product-btn").show("fast");
      }else{
        $.notify({
          message:"Sorry Something Went Wrong."
          },{
            type : "warning" 
        });
      }
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    } 
  }); 
  
}

function goBackFromExpiredProductsCard (elem,evt) {
  $("#manage-products-choose-action-card").show();
        
  $("#expired-products-card").hide();
}

function expiredProducts (elem,evt) {
  evt.preventDefault();
  var url = "<?php echo site_url('meetglobal/get_expired_products_mini_importation') ?>"
  $(".spinner-overlay").show();
  $.ajax({
    url : url,
    type : "POST",
    cache: false,
    dataType : "json",
    responseType: "json",
    data : "show_records=true",
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success && response.messages != "") {
        $("#manage-products-choose-action-card").hide();
        $("#expired-products-card .card-body").html(response.messages);
        $("#expired-products-card").show();
        
      }else{
        $.notify({
          message:"Sorry Something Went Wrong."
          },{
            type : "warning" 
        });
      }
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    } 
  }); 
  
}

function addNewProduct(elem,evt){
  $("#live-products-card").hide();
  $("#add-new-product-card").show();
  $("#add-new-product-btn").hide("fast");
}

function submitNewproduct (elem,evt) {
  var me = $(elem);
  evt.preventDefault();
  var file_input = elem.querySelector("#image");
  var form_info = me.serializeArray();
  console.log(form_info)
  var url = me.attr("action");
  

  var files = file_input.files;
  console.log(files)
  var form_data = new FormData();
  var error = '';
  
  for(var i = 0; i < form_info.length; i++){
    form_data.append(form_info[i].name,form_info[i].value);
  }
  form_data.append("image",files[0]);
  console.log(form_data)
      
  $(".spinner-overlay").show();
  $.ajax({
    url : url,
    type : "POST",
    cache: false,
    dataType : "json",
    contentType: false,
    processData: false,
    data : form_data,
    success : function (response) {
      $(".spinner-overlay").hide();
      console.log(response)
      if(response.wrong_extension){
        $.notify({
          message:"The File Uploaded Is Not A Valid Image Format"
          },{
            type : "warning"  
        });
      }else if(response.too_large){
        $.notify({
          message:"The File Upladed Is Too Large Max Is 200 KB"
          },{
            type : "warning"  
        });
      }else if(response.not_really_json){
        $.notify({
          message:"This File Format Is Not Really An Image File"
          },{
            type : "warning"  
        });
      }else if(response.success && response.image_name != ""){
        $.notify({
        message:"Product Uploaded Successfully"
        },{
          type : "success"  
        });
        setTimeout(function () {
          goToDefaultPage()
        }, 2000);
      }else{
        me.find(".form-error").html("");
        $.each(response.messages, function (key,value) {

        var element = me.find("#"+key);
        
        element.closest('div.form-group')
                
                .find('.form-error').remove();
        element.after(value);
        
       });
        $.notify({
        message:"Some Values Where Not Valid. Please Enter Valid Values"
        },{
          type : "warning"  
        });
      }
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    }
  });
}

function goBackFromEditProductCard (elem,evt) {
  $("#edit-product-card").hide();
  $("#add-new-product-btn").show("fast");
  $("#live-products-card").show();
}

function submitEditproductForm (elem,evt) {
  var me = $(elem);
  evt.preventDefault();
  var file_input = elem.querySelector("#image");
  var form_info = me.serializeArray();
  console.log(form_info)
  var url = me.attr("action");
  

  var files = file_input.files;
  console.log(files)
  var form_data = new FormData();
  var error = '';
  
  for(var i = 0; i < form_info.length; i++){
    form_data.append(form_info[i].name,form_info[i].value);
  }
  var product_id = me.attr("data-id");
  form_data.append('product_id',product_id);
  if(files.length > 0){
    form_data.append("image",files[0]);
  }
  console.log(form_data)
      
  $(".spinner-overlay").show();
  $.ajax({
    url : url,
    type : "POST",
    cache: false,
    dataType : "json",
    contentType: false,
    processData: false,
    data : form_data,
    success : function (response) {
      $(".spinner-overlay").hide();
      console.log(response)
      if(response.wrong_extension){
        $.notify({
          message:"The File Uploaded Is Not A Valid Image Format"
          },{
            type : "warning"  
        });
      }else if(response.too_large){
        $.notify({
          message:"The File Upladed Is Too Large Max Is 200 KB"
          },{
            type : "warning"  
        });
      }else if(response.not_really_json){
        $.notify({
          message:"This File Format Is Not Really An Image File"
          },{
            type : "warning"  
        });
      }else if(response.success){
        $.notify({
        message:"Product Edited Successfully"
        },{
          type : "success"  
        });

        if(response.image_name != ""){
          var image_name = response.image_name;
          me.find("#previous-image").attr("src",image_name);
        }
        
      }else{
        me.find(".form-error").html("");
        $.each(response.messages, function (key,value) {

        var element = me.find("#"+key);
        
        element.closest('div.form-group')
                
                .find('.form-error').remove();
        element.after(value);
        
       });
        $.notify({
        message:"Some Values Where Not Valid. Please Enter Valid Values"
        },{
          type : "warning"  
        });
      }
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    }
  });
}

function loadProductInfo (elem,evt) {
  var me = $(elem);
  var id = me.attr("data-id");

  var form_data = {
    product_id : id
  };

  $(".spinner-overlay").show();
  var url = "<?php echo site_url('meetglobal/get_mini_importation_info') ?>";

  $.ajax({
    url : url,
    type : "POST",
    dataType : "json",
    responseType: "json",
    data : form_data,
    success : function (response) {
      $(".spinner-overlay").hide();
      console.log(response);

      if(response.success && response.messages.length != 0){
        var messages = response.messages;
        var name_concat = response.name_concat;
        $("#edit-product-card .card-title").html("Edit " + name_concat)
        for (const [key, value] of Object.entries(messages)) {
            if(key == "image"){
              $("#edit-product-card #previous-image").attr("src","<?php echo base_url('assets/images/') ?>"+value);
            }else{
              $("#edit-product-card #" +key).val(value);
            }
            
        }
        $("#edit-product-card #users-with-slots").html(response.html);
        $("#edit-product-card #edit-product-form").attr("data-id",id);
        $("#edit-product-card").show();
        $("#add-new-product-btn").hide("fast");
        $("#live-products-card").hide();
      }

    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    }
  });  
}

function productsOnWayToCenterLeader (elem,evt) {
  evt.preventDefault();
  $(".spinner-overlay").show();
  var url = "<?php echo site_url('meetglobal/get_products_on_way_to_center_leader') ?>";
  var form_data = {
    show_records : true
  }

  $.ajax({
    url : url,
    type : "POST",
    dataType : "json",
    responseType: "json",
    data : form_data,
    success : function (response) {
      $(".spinner-overlay").hide();
      console.log(response);
      if(response.success){
        var messages = response.messages;
        $("#products-on-way-to-center-leader-card .card-body").html(messages);
        $("#products-on-way-to-center-leader-table").DataTable({
          aLengthMenu: [
              [25, 50, 100, 200, -1],
              [25, 50, 100, 200, "All"]
          ],
          iDisplayLength: -1
        });
        $("#products-on-way-to-center-leader-card").show();
        $("#manage-products-choose-action-card").hide();
      }
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    } 
  });   
}

function goBackProductsOnWayToCenterLeaderCard (elem,evt) {
  $("#products-on-way-to-center-leader-card").hide();
  $("#manage-products-choose-action-card").show();
}

function loadCenterLeaderProductInfo(elem,evt){
  elem = $(elem);
  var product_id = elem.attr("data-product-id");
  var center_leader_id = elem.attr("data-center-leader");
  console.log(product_id + " : " + center_leader_id)
  $(".spinner-overlay").show();
  var url = "<?php echo site_url('meetglobal/get_products_on_way_to_center_leader_info') ?>";
  var form_data = {
    show_records : true,
    product_id : product_id,
    center_leader_id : center_leader_id
  }

  $.ajax({
    url : url,
    type : "POST",
    dataType : "json",
    responseType: "json",
    data : form_data,
    success : function (response) {
      $(".spinner-overlay").hide();
      console.log(response);
      if(response.success){
        var messages = response.messages;
        $("#products-on-way-to-center-leader-info-card .card-body").html(messages);
        $("#products-on-way-to-center-leader-info-card #statuses-table").DataTable({
          aLengthMenu: [
              [25, 50, 100, 200, -1],
              [25, 50, 100, 200, "All"]
          ],
          iDisplayLength: -1
        });
        $("#products-on-way-to-center-leader-info-card #dispatchers-table").DataTable({
          aLengthMenu: [
              [25, 50, 100, 200, -1],
              [25, 50, 100, 200, "All"]
          ],
          iDisplayLength: -1
        });
        $("#products-on-way-to-center-leader-info-card").show();
        $("#add-status-btn").attr("data-product-id",product_id);
        $("#add-status-btn").attr("data-center-leader",center_leader_id);

        if(!response.no_status){
          $("#add-status-btn").show("fast");
        }
        $("#products-on-way-to-center-leader-card").hide();
      }
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    } 
  }); 
}

function goBackProductsOnWayToCenterLeaderInfoCard (elem,evt) {
  
  $("#products-on-way-to-center-leader-info-card").hide();
  $("#add-status-btn").hide("fast");
  $("#products-on-way-to-center-leader-card").show();
}

function addNewStatus (elem,evt) {
  elem = $(elem);
  var product_id = elem.attr("data-product-id");
  var center_leader_id = elem.attr("data-center-leader");
  console.log(product_id + " : " + center_leader_id)

  $("#add-status-form").attr("data-product-id",product_id);
  $("#add-status-form").attr("data-center-leader",center_leader_id);
  $("#add-status-modal").modal("show");

}

function deleteStatus(elem,evt,id) {
  swal({
    title: 'Warning!',
    text: "Are You Sure You Want To Delete This Status? ",
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes Delete!'
  }).then(function(){
    $(".spinner-overlay").show();
    var url = "<?php echo site_url('meetglobal/delete_order_status_mini_importation_info') ?>";
    var form_data = {
      id : id
    };
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : form_data,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success){
          var messages = response.messages;
          $.notify({
          message:"Status Deleted Successfully"
          },{
            type : "success"  
          });

          $("#products-on-way-to-center-leader-info-card #order-status-div").remove();

          $("#products-on-way-to-center-leader-info-card #center-leader-info-div").after(messages);

          $("#products-on-way-to-center-leader-info-card #statuses-table").DataTable({
            aLengthMenu: [
                [25, 50, 100, 200, -1],
                [25, 50, 100, 200, "All"]
            ],
            iDisplayLength: -1
          });
        }else{
          $.notify({
            message:"Sorry Something Went Wrong."
            },{
              type : "warning" 
          });
        } 
      },error : function () {
        $(".spinner-overlay").hide();
        $.notify({
          message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
          },{
            type : "danger" 
        });
      } 
    }); 
  });    
}

function selectUserAsDispatcher (elem,evt) {
  evt.preventDefault();
  
  $(".spinner-overlay").show();
  var url = "<?php echo site_url('meetglobal/list_users_to_select_as_dispatcher') ?>";
  var form_data = {
    show_records : true
  };
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : form_data,
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success){
        var messages = response.messages;
        $("#choose-action-card").hide();
        $("#select-user-as-dispatcher-card .card-body").html(messages);
        $("#select-user-as-dispatcher-card #select-user-as-dispatcher-table").DataTable({
          aLengthMenu: [
              [25, 50, 100, 200, -1],
              [25, 50, 100, 200, "All"]
          ],
          iDisplayLength: -1
        });
        $("#select-user-as-dispatcher-card").show();
       
      }else{
        $.notify({
          message:"Sorry Something Went Wrong."
          },{
            type : "warning" 
        });
      } 
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    } 
  });
}

function goBackSelectUserAsDispatcherCard (elem,evt) {
  $("#choose-action-card").show();
  $("#select-user-as-dispatcher-card").hide();
}


function addUserAsDispatcher(elem,evt,id) {
  elem = $(elem);
  var full_name = elem.attr("data-full-name");
  swal({
    title: 'Warning!',
    text: "Are You Sure You Want To Select <em class='text-primary'>" + full_name + "</em> As A Dispatcher?",
    type: 'question',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes Select!'
  }).then(function(){
    $(".spinner-overlay").show();
    var url = "<?php echo site_url('meetglobal/add_user_as_dispatcher') ?>";
    var form_data = {
      id : id
    };
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : form_data,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success){
          var messages = response.messages;
          var full_name = response.full_name;
          $.notify({
            message: full_name +" Has Been Successfully Selected As Dispatcher"
            },{
              type : "success" 
          });

          $("#select-user-as-dispatcher-card .card-body").html(messages);
          $("#select-user-as-dispatcher-card #select-user-as-dispatcher-table").DataTable({
            aLengthMenu: [
                [25, 50, 100, 200, -1],
                [25, 50, 100, 200, "All"]
            ],
            iDisplayLength: -1
          });

        }else if(response.invalid_user){
          swal({
            title: 'Error!',
            text: "Invalid User Selected!",
            type: 'error'
          })
        }else{
          $.notify({
            message:"Sorry Something Went Wrong."
            },{
              type : "warning" 
          });
        } 
      },error : function () {
        $(".spinner-overlay").hide();
        $.notify({
          message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
          },{
            type : "danger" 
        });
      } 
    }); 
  });
}

function selectThisDispatcher(elem,evt,dispatcher_id){
  elem = $(elem);
  var full_name = elem.attr("data-full-name");
  var center_leader_id = $("#add-status-btn").attr("data-center-leader");
  var product_id = $("#add-status-btn").attr("data-product-id");
  swal({
    title: 'Warning!',
    text: "Are You Sure You Want To Select <em class='text-primary'>" + full_name + "</em> To Dispatch This Product?",
    type: 'question',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes Select!'
  }).then(function(){
    
    var url = "<?php echo site_url('meetglobal/select_this_user_to_dispatch') ?>";
    var form_data = {
      dispatcher_id : dispatcher_id,
      center_leader_id : center_leader_id,
      product_id : product_id
    };

    console.log(form_data)
    $(".spinner-overlay").show();
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : form_data,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success){
          var full_name = response.full_name;
          $.notify({
            message: full_name +" Has Been Successfully Selected To Dispatch This Product To This Center Leader"
            },{
              type : "success" 
          });
          setTimeout(function () {
            goToDefaultPage();
          },2000);

        }else if(response.invalid_user){
          swal({
            title: 'Error!',
            text: "Invalid User Selected!",
            type: 'error'
          })
        }else if(response.already_assigned){
          swal({
            title: 'Error!',
            text: "This Product Has Been Assigned To A Dispatcher Before.",
            type: 'error'
          })
        }else{
          $.notify({
            message:"Sorry Something Went Wrong."
            },{
              type : "warning" 
          });
        } 
      },error : function () {
        $(".spinner-overlay").hide();
        $.notify({
          message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
          },{
            type : "danger" 
        });
      } 
    }); 
  });
}

function merchantRequests (elem,evt) {
  evt.preventDefault();
  $(".spinner-overlay").show();
  var url = "<?php echo site_url('meetglobal/get_merchant_requests') ?>";
  var form_data = {
    show_records : true
  };
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : form_data,
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success && response.messages){
        var messages = response.messages;
        $("#merchant-requests-card .card-body").html(messages);
        $("#merchant-requests-card #merchant-requests-table").DataTable({
          aLengthMenu: [
              [25, 50, 100, 200, -1],
              [25, 50, 100, 200, "All"]
          ],
          iDisplayLength: -1
        });
        $("#merchant-requests-card").show();
        $("#choose-action-card").hide();

      }else{
        $.notify({
          message:"Sorry Something Went Wrong."
          },{
            type : "warning" 
        });
      } 
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    } 
  }); 
}

function goBackMerchantRequestsCard (elem,evt) {
  $("#merchant-requests-card").hide();
  $("#choose-action-card").show();
}

function viewMerchantRequestInfo(elem,evt,id) {
  $(".spinner-overlay").show();
  var url = "<?php echo site_url('meetglobal/view_merchant_request_info') ?>";
  var form_data = {
    show_records : true,
    id : id
  };
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : form_data,
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success && response.messages){
        var messages = response.messages;
        $("#merchant-request-info-card .card-body").html(messages);
        $("#merchant-request-info-card").show();
        $("#merchant-requests-card").hide();
        $("#disapprove-merchant-request-btn").attr("data-id",id);
        $("#disapprove-merchant-request-btn").show("fast");

      }else{
        $.notify({
          message:"Sorry Something Went Wrong."
          },{
            type : "warning" 
        });
      } 
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    } 
  }); 
}

function disapproveMerchantRequest (elem,evt) {
  elem = $(elem);
  var id = elem.attr("data-id");
  swal({
    title: 'Warning!',
    text: "Are You Sure You Want To Disapprove This Product? ",
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes',
    cancelButtonText: 'No'
  }).then(function(){
    $(".spinner-overlay").show();
    var url = "<?php echo site_url('meetglobal/disapprove_merchant_request') ?>";
    var form_data = {
      show_records : true,
      id : id
    };
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : form_data,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success){
          $.notify({
            message:"Request Successfully Disapproved"
            },{
              type : "success" 
          });
          setTimeout(function () {
            document.location.reload();
          },1500);
        }else{
          $.notify({
            message:"Sorry Something Went Wrong."
            },{
              type : "warning" 
          });
        }
      },error : function () {
        $(".spinner-overlay").hide();
        $.notify({
          message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
          },{
            type : "danger" 
        });
      }
    });  
  });
}

function goBackMerchantRequestInfoCard (elem,evt) {
  $("#merchant-request-info-card").hide();
  $("#merchant-requests-card").show();
  $("#disapprove-merchant-request-btn").hide("fast");
}

function approveMerchantProduct (elem,evt) {
  
  evt.preventDefault();
  var me = $(elem);
  var url = me.attr("action");
  swal({
    title: 'Warning!',
    text: "Are You Sure You Want To Approve This Product? ",
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes',
    cancelButtonText: 'No'
  }).then(function(){
    
    // var file_input = elem.querySelector("#image");
    var form_data = me.serializeArray();
    
    console.log(form_data)
        
    $(".spinner-overlay").show();
    $.ajax({
      url : url,
      type : "POST",
      cache: false,
      dataType : "json",
      responseType : "json",
      data : form_data,
      success : function (response) {
        $(".spinner-overlay").hide();
        console.log(response)
        
        if(response.success){
          $.notify({
          message:"Merchant Request Approved Successfully"
          },{
            type : "success"  
          });
          setTimeout(function () {
            goToDefaultPage()
          }, 2000);
        }else{
          me.find(".form-error").html("");
          $.each(response.messages, function (key,value) {

          var element = me.find("#"+key);
          
          element.closest('div.form-group')
                  
                  .find('.form-error').remove();
          element.after(value);
          
         });
          $.notify({
          message:"Some Values Where Not Valid. Please Enter Valid Values"
          },{
            type : "warning"  
          });
        }
      },error : function () {
        $(".spinner-overlay").hide();
        $.notify({
          message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
          },{
            type : "danger" 
        });
      }
    });
  });  
}
</script>

<style>
  tr{
    cursor: pointer;
  }

  #shop .owl-carousel img{
    max-height: 340px;
  }

  .product-card{
    padding: 15px;
    margin: 15px;
    cursor: pointer;
  }

  .product-card .card-body{
    padding: 0;
  }

  .product-card .card-body .product-img{
    height: 170px; 
    width: 170px;
  }

  .product-card .card-body .product-info h3{
    font-size: 16px;
    text-transform: capitalize;
    font-weight: 600;
  }

  .product-card .card-body .product-info .product-price-div{
    padding-top: 7px;
    border-top: 1px solid rgb(242, 242, 242);
    padding-bottom : 7px;
    border-bottom: 1px solid rgb(242, 242, 242);
  }

  .product-card .card-body .product-info .product-real-price{
    font-size: 20px;
    
    font-weight: 700;
  }

  .product-card .card-body .product-info .product-fake-price{
    font-size: 14px;
    text-decoration: line-through;
    font-weight: 400;
    float: right;
  }

  .product-card .card-body .btn-orange{
    background-color: rgb(0,0,0,0);
    border: 1px solid #FF9900;
    color: #FF9900;
    border-radius: 3px;
    padding: 8px;
    font-size: 14px;
    font-weight: 600;
    margin-top: 20px;
    display: block;
    width: 100%;
    text-transform: none;
    transition-delay: 0s;
    transition-duration: 0.3s;
    transition-property: all;
    transition-timing-function: ease-in-out;
    cursor: pointer;
  }

</style>

<div class="spinner-overlay" style="display: none;">
  <div class="spinner-well">
    <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading...">
  </div>
</div>
<div class="content">
  <div class="container-fluid">
    <h2 class="text-center sub-head" style="">Mini Importation</h2>

    <section id="services">
      
      <div class="card" id="choose-action-card">
        <div class="card-header">
          <h4 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Choose Option: </h4>
        </div>
        <div class="card-body">
          <table class="table">
            <tbody>
              <tr class="pointer-cursor">
                <td>1</td>
                <td><a href="#" onclick="manageBanners(this,event)">Manage Banners</a></td>
              </tr>

              <tr class="pointer-cursor">
                <td>2</td>
                <td><a href="#" onclick="manageProducts(this,event)">Manage Products</a></td>
              </tr>

              <tr class="pointer-cursor">
                <td>3</td>
                <td><a href="#" onclick="selectUserAsDispatcher(this,event)">Select User As Dispatcher</a></td>
              </tr>

              <tr class="pointer-cursor">
                <td>4</td>
                <td><a href="#" onclick="merchantRequests(this,event)">Merchant Requests</a></td>
              </tr>
              

            </tbody>
          </table>
        </div>
      </div>

      <div class="card" id="manage-products-choose-action-card" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackManageProductsChooseAction(this,event)">Go Back</button>
          <h4 class="card-title" id="welcome-heading" style="text-transform: capitalize;">View: </h4>
        </div>
        <div class="card-body">
          <table class="table">
            <tbody>
              <tr class="pointer-cursor">
                <td>1</td>
                <td><a href="#" onclick="liveProducts(this,event)">Live Products</a></td>
              </tr>

              <tr class="pointer-cursor">
                <td>2</td>
                <td><a href="#" onclick="expiredProducts(this,event)">Expired Products</a></td>
              </tr>

              <tr class="pointer-cursor">
                <td>3</td>
                <td><a href="#" onclick="productsOnWayToCenterLeader(this,event)">Products On The Way To Center Leader</a></td>
              </tr>

              
            </tbody>
          </table>
        </div>
      </div>


      <div class="card" id="merchant-requests-card" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackMerchantRequestsCard(this,event)">Go Back</button>
          <h4 class="card-title" id="welcome-heading" style="text-transform: capitalize;">New Merchant Requests</h4>
        </div>
        <div class="card-body">
          
        </div>
      </div>

      <div class="card" id="merchant-request-info-card" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackMerchantRequestInfoCard(this,event)">Go Back</button>
          <h4 class="card-title" id="welcome-heading" style="text-transform: capitalize;"></h4>
        </div>
        <div class="card-body">
          
        </div>
      </div>




      <div class="card" id="products-on-way-to-center-leader-card" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackProductsOnWayToCenterLeaderCard(this,event)">Go Back</button>
          <h4 class="card-title" id="welcome-heading" style="text-transform: capitalize;">products on the way to center leader: </h4>
        </div>
        <div class="card-body">
          
        </div>
      </div>

      <div class="card" id="products-on-way-to-center-leader-info-card" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackProductsOnWayToCenterLeaderInfoCard(this,event)">Go Back</button>
          <h4 class="card-title" id="welcome-heading" style="text-transform: capitalize;"></h4>
        </div>
        <div class="card-body">
          
        </div>
      </div>

      <div class="card" id="manage-banners-card" style="display: none;">
        <div class="card-header">
          <button onclick="goBackFromManageBannersCard(this,event)" class="btn btn-warning btn-round">Go Back</button>
          <h4 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Manage Banners: </h4>
        </div>
        <div class="card-body">
          <?php
            $banners = $this->meetglobal_model->getMiniImportationBanners();
            if(is_array($banners)){
          ?>
          <div class="container">
            <div class="row">
          <?php
              foreach($banners as $row){
                $id = $row->id;
                $product_id = $row->id;
                $image = $row->image;
                $date = $row->date;
                $time = $row->time;

          ?>
          
          <div class="col-sm-6 banner-div" data-id="<?php echo $id; ?>" data-image="<?php echo $image; ?>" style="cursor: pointer;">
            <img src="<?php echo base_url('assets/images/'.$image) ?>" class="col-12" alt="">
            <h4>Upload Date: <?php echo $date . " " . $time; ?></h4>
          </div>    
            
          <?php
              }
          ?>
            </div>
          </div>
          <?php    
            }else{
              echo "<h4 class='text-warning'>No Banner Uploaded. Click The Button To Add.</h4>";
            }
          ?>
        </div>
      </div>

      <div class="card" id="live-products-card" style="display: none;">
        <div class="card-header">
          <button onclick="goBackFromLiveProductsCard(this,event)" class="btn btn-warning btn-round">Go Back</button>
          <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Live Products: </h3>
        </div>
        <div class="card-body">

          
        </div>
      </div>

      <div class="card" id="expired-products-card" style="display: none;">
        <div class="card-header">
          <button onclick="goBackFromExpiredProductsCard(this,event)" class="btn btn-warning btn-round">Go Back</button>
          <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Expired Products: </h3>
        </div>
        <div class="card-body">
          
        </div>
      </div>

      <div class="card" id="add-new-banner-card" style="display: none;">
        <div class="card-header">
          <button onclick="goBackFromAddNewBannerCard(this,event)" class="btn btn-warning btn-round">Go Back</button>
          <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Add A New Banner</h3>
        </div>
        <div class="card-body">
          <?php
            $attr = array('id' => 'add-new-banner-form','onsubmit' => 'submitNewBanner(this,event)');
           echo form_open_multipart('meetglobal/submit_add_new_banner_form',$attr);
          ?>
          
            <div class="form-group">
              <label for="product_id">Enter Product Id: </label>
              <input type="number" name="product_id" id="product_id" class="form-control">
              <span class="form-error"></span>
            </div>

            <div >
              <label for="image">Select Banner Image: </label>
              
              <input class="" type="file" name="banner_img" id="banner_img" accept="image/*">
              
            </div>

            <input type="submit" class="btn btn-primary" value="PROCEED">

          </form>
        </div>
      </div>

      <div class="card" id="add-new-product-card" style="display: none;">
        <div class="card-header">
          <button onclick="goBackFromAddNewProductCard(this,event)" class="btn btn-warning btn-round">Go Back</button>
          <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Add A New Product</h3>
        </div>
        <div class="card-body">
          <?php
            $attr = array('id' => 'add-new-product-form','onsubmit' => 'submitNewproduct(this,event)');
           echo form_open_multipart('meetglobal/submit_add_new_product_form',$attr);
          ?>
          
            <div class="form-group">
              <label for="name">Enter Product Name: </label>
              <input type="text" name="name" id="name" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="quantity">Enter Product Quantity: </label>
              <input type="number" name="quantity" id="quantity" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="old_price">Enter Product Old Price: </label>
              <input type="number" step="any" name="old_price" id="old_price" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="new_price">Enter Product New Price: </label>
              <input type="number" step="any" name="new_price" id="new_price" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="expiry_date">Enter Product Expiry Date: </label>
              <input type="date" name="expiry_date" id="expiry_date" class="form-control">
              <span class="form-error"></span>
            </div>

            <div >
              <label for="image">Select Product Image: </label>
              <input class="" type="file" name="image" id="image" accept="image/*">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="weight">Enter Product Weight(kg): </label>
              <input type="number" step="any" name="weight" id="weight" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="length">Enter Product Length(cm): </label>
              <input type="number" step="any" name="length" id="length" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="width">Enter Product Width(cm): </label>
              <input type="number" step="any" name="width" id="width" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="height">Enter Product Height(cm): </label>
              <input type="number" step="any" name="height" id="height" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="new_price">Enter Product Shipping Fee: </label>
              <input type="number" step="any" name="shipping_fee" id="shipping_fee" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="description">Enter Product Description: </label>
              <textarea name="description" id="description" cols="30" rows="10" class="form-control"></textarea>
              <span class="form-error"></span>
            </div>

            <input type="submit" class="btn btn-primary" value="PROCEED">

          </form>
        </div>
      </div>

      <div class="card" id="edit-product-card" style="display: none;">
        <div class="card-header">
          <button onclick="goBackFromEditProductCard(this,event)" class="btn btn-warning btn-round">Go Back</button>
          <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Edit </h3>
        </div>
        <div class="card-body">
          <?php
            $attr = array('id' => 'edit-product-form','onsubmit' => 'submitEditproductForm(this,event)');
           echo form_open_multipart('meetglobal/submit_edit_product_form',$attr);
          ?>
          
            <div class="form-group">
              <label for="name">Edit Product Name: </label>
              <input type="text" name="name" id="name" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="quantity">Edit Product Remaining Quantity: </label>
              <input type="number" name="quantity" id="quantity" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="old_price">Edit Product Old Price: </label>
              <input type="number" step="any" name="old_price" id="old_price" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="new_price">Edit Product New Price: </label>
              <input type="number" step="any" name="new_price" id="new_price" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="expiry_date">Edit Product Expiry Date: </label>
              <input type="date" name="expiry_date" id="expiry_date" class="form-control">
              <span class="form-error"></span>
            </div>


            <div class="form-group">
              <label for="previous-image">Current Product Image: </label>
              <img src="" alt="" id="previous-image" class="col-4">
            </div>


            <div >
              <label for="image">Select New Product Image: </label>
              
              <input class="" type="file" name="image" id="image" accept="image/*">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="weight">Edit Product Weight(kg): </label>
              <input type="number" step="any" name="weight" id="weight" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="length">Edit Product Length(cm): </label>
              <input type="number" step="any" name="length" id="length" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="width">Edit Product Width(cm): </label>
              <input type="number" step="any" name="width" id="width" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="height">Edit Product Height(cm): </label>
              <input type="number" step="any" name="height" id="height" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="new_price">Edit Product Shipping Fee: </label>
              <input type="number" step="any" name="shipping_fee" id="shipping_fee" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="description">Edit Product Description: </label>
              <textarea name="description" id="description" cols="30" rows="10" class="form-control"></textarea>
              <span class="form-error"></span>
            </div>

            <input type="submit" class="btn btn-primary" value="PROCEED">

          </form>

          <div id="users-with-slots" style="margin-top: 30px;">
            
          </div>
        </div>
      </div>
    </section>
  </div>

  
  <div class="modal fade" data-backdrop="static" id="add-status-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content" >
        <div class="modal-header">Enter New Status</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="modal-body" id="modal-body">
          <?php 
            $attr = array('id' => 'add-status-form');
            echo form_open('meetglobal/add_order_status',$attr);
          ?>
          
          <div class="form-group">
            <label for="status">Status: </label>
            <textarea name="status" id="status" cols="30" rows="10" class="form-control"></textarea>
            <span class="form-error"></span> 
          </div>

          <input type="submit" class="btn btn-primary" >

          </form>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal" aria-label="Close">Close</button>
        </div>
      </div>
    </div>
  </div>
  
  <div id="add-status-btn" onclick="addNewStatus(this,event)" rel="tooltip" data-toggle="tooltip" title="Add New Status" style="background: #9c27b0; cursor: pointer; position: fixed; bottom: 0; right: 0;  border-radius: 50%; cursor: pointer; display: none; fill: #fff; height: 56px; outline: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.2);">
    <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
      <i class="fas fa-plus" style="font-size: 25px; color: #fff;" aria-hidden="true"></i>
    </div>
  </div>

  <div id="add-new-banner-btn" onclick="addNewBanner(this,event)" rel="tooltip" data-toggle="tooltip" title="Add New Banner" style="background: #9c27b0; cursor: pointer; position: fixed; bottom: 0; right: 0;  border-radius: 50%; cursor: pointer; display: none; fill: #fff; height: 56px; outline: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.2);">
    <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
      <i class="fas fa-plus" style="font-size: 25px; color: #fff;" aria-hidden="true"></i>
    </div>
  </div>

   <div id="disapprove-merchant-request-btn" onclick="disapproveMerchantRequest(this,event)" rel="tooltip" data-toggle="tooltip" title="Disapprove This Merchant Request" style="background: #f44336; cursor: pointer; position: fixed; bottom: 0; right: 0;  border-radius: 50%; cursor: pointer; display: none; fill: #fff; height: 56px; outline: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.2);">
    <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
      <i class="fas fa-times" style="font-size: 25px; color: #fff;" aria-hidden="true"></i>
    </div>
  </div>

  <div id="add-new-product-btn" onclick="addNewProduct(this,event)" rel="tooltip" data-toggle="tooltip" title="Add New Product" style="background: #9c27b0; cursor: pointer; position: fixed; bottom: 0; right: 0;  border-radius: 50%; cursor: pointer; display: none; fill: #fff; height: 56px; outline: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.2);">
    <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
      <i class="fas fa-plus" style="font-size: 25px; color: #fff;" aria-hidden="true"></i>
    </div>
  </div>
</div>
<footer class="footer">
  <div class="container-fluid">
    <!-- <footer>&copy; <?php echo date("Y"); ?> Copyright (meetglobal Issues Global Limited). All Rights Reserved</footer> -->
  </div>
</footer>

<script>
  $(document).ready(function () {

    <?php if(isset($_GET['open_products_on_way_to_center_leader_info']) && isset($_GET['center_leader_id']) && isset($_GET['product_id']) && !empty($response_arr)){ ?>
    $("#choose-action-card").hide();
    var product_id = <?php echo $_GET['product_id']; ?>;
    var center_leader_id = <?php echo $_GET['center_leader_id']; ?>;

    var messages = '<?php echo $response_arr['messages']; ?>';
    // console.log(messages)
    $("#products-on-way-to-center-leader-info-card .card-body").html(messages);
    $("#products-on-way-to-center-leader-info-card #statuses-table").DataTable({
      aLengthMenu: [
          [25, 50, 100, 200, -1],
          [25, 50, 100, 200, "All"]
      ],
      iDisplayLength: -1
    });
    $("#products-on-way-to-center-leader-info-card #dispatchers-table").DataTable({
      aLengthMenu: [
          [25, 50, 100, 200, -1],
          [25, 50, 100, 200, "All"]
      ],
      iDisplayLength: -1
    });
    $("#products-on-way-to-center-leader-info-card .card-header button").attr("onclick","goToDefaultPage()");
    $("#products-on-way-to-center-leader-info-card").show();
    $("#add-status-btn").attr("data-product-id",product_id);
    $("#add-status-btn").attr("data-center-leader",center_leader_id);

    $("#add-status-btn").show("fast");
        


    <?php } ?>

    $("#add-status-form").submit(function (evt) {
      evt.preventDefault();
      var elem = $(this);
      var form_data = elem.serializeArray();
      var url = elem.attr("action");
      var product_id = elem.attr("data-product-id");
      var center_leader_id = elem.attr("data-center-leader");
      console.log(product_id + " : " + center_leader_id)

      form_data = form_data.concat({
        "name" : "product_id",
        "value" : product_id
      })

      form_data = form_data.concat({
        "name" : "center_leader_id",
        "value" : center_leader_id
      })

      $(".spinner-overlay").show();
      console.log(form_data)
      $.ajax({
        url : url,
        type : "POST",
        responseType : "json",
        dataType : "json",
        data : form_data,
        success : function (response) {
          console.log(response)
          $(".spinner-overlay").hide();
          if(response.success && response.messages != ""){
            var messages = response.messages;
            $.notify({
            message:"Status Added Successfully"
            },{
              type : "success"  
            });

            $("#products-on-way-to-center-leader-info-card #order-status-div").remove();

            $("#products-on-way-to-center-leader-info-card #center-leader-info-div").after(messages);


            $("#products-on-way-to-center-leader-info-card #statuses-table").DataTable({
              aLengthMenu: [
                  [25, 50, 100, 200, -1],
                  [25, 50, 100, 200, "All"]
              ],
              iDisplayLength: -1
            });
            $("#add-status-modal").modal("hide");
          }else{
            $.each(response.messages, function (key,value) {

            var element = elem.find("#"+key);
            
            element.closest('div.form-group')
                    
                    .find('.form-error').remove();
            element.after(value);
            
           });
            $.notify({
            message:"Some Values Where Not Valid. Please Enter Valid Values"
            },{
              type : "warning"  
            });
          }
        },error : function () {
          $(".spinner-overlay").hide();
          swal({
            title: 'Ooops',
            text: "Something Went Wrong",
            type: 'error'
          })
        } 
      }); 
    })

    
    $("#banner-div").click(function (evt) {
      var me = $(this);
      var id = me.attr("data-id");
      var image = me.attr("data-image");

    })

    $(".my-select").selectpicker();

    <?php if($this->session->center_leader_successful){ ?>
      $.notify({
      message:"Congrats! You Are Now A Center Leader"
      },{
        type : "success"  
      });
    <?php } ?>
  })
</script>
</div>
</div>
  <!--   Core JS Files   -->
 