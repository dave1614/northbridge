<style>  
    form .spinner-border{
    	display: none;
    }
    
</style> 
<script>
	function openSignUpDiv (elem,evt) {
		window.scrollTo(0,0);
		$("#login-div").hide();
		$("#signup-div").show();
	}

	function openLogInDiv (elem,evt) {
		window.scrollTo(0,0);
		$("#signup-div").hide();
		$("#login-div").show();
	}

	function changeYourDetails(elem,evt){
		$("#signup-otp-form input").val("");
		// $("#sign-up-form input").val("");
		$("#signup-div").show();
        $("#signup-otp-div").hide();
	}

	function sendSignUpOtpAgain(elem,evt){
		evt.preventDefault();(
		$("#signup-form").submit);
		$("#signup-otp-form input").val("");
		$("#signup-otp-form").find(".spinner-border").show();
        $("#signup-otp-form").find("button").addClass("disabled");
		setTimeout(function () {
			$("#signup-otp-form").find(".spinner-border").hide();
        	$("#signup-otp-form").find("button").removeClass("disabled");
		}, 3000);
	}

	function forgotPass (elem,evt) {
        $("#login-div").hide("fast");
        $("#enter-username-div").show("fast");
    }

    function sendForgotPassOtp(elem,evt,again = false){
		evt.preventDefault();
		if(!again){
			var spinner = $("#enter-username-form").find(".spinner-border");
		    var btn = $("#enter-username-form").find("button");
		}else{
			var spinner = $("#forgot-pass-otp-form").find(".spinner-border");
		    var btn = $("#forgot-pass-otp-form").find("button");
		}
	    var form_data = $("#enter-username-form").serializeArray();
		btn.addClass("disabled");
		btn.css({
			"cursor" : "unset"
		})
        spinner.show();

        var url = "<?php echo site_url('sabicapital/send_forgot_password_otp') ?>"
		
		$.ajax({
	        url : url,
	        type : "POST",
	        responseType : "json",
	        dataType : "json",
	        data : form_data,
	        success : function (response) {
	        	console.log(response)
	        	btn.removeClass("disabled");
	        	btn.css({
					"cursor" : "pointer"
				})
        		spinner.hide();
        		if(response.success){
		        	$("#enter-username-div").hide();
                    $("#forgot-pass-otp-div .heading-text").html("An OTP Has Been Sent To The Following Email <br> <small><em class=''>" + global_email + "</em></small>");
                    $("#forgot-pass-otp-div").show();
                }else{
                	$.notify({
	                	message:"Sorry Something Went Wrong."
	                },{
	                  	type : "warning"  
	                });
                }
            },error : function () {
            	btn.removeClass("disabled");
        		spinner.hide();
            	$.notify({
                	message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
                },{
                  	type : "danger"  
                });
            }
        });
	}
</script> 
<div class="container" style="margin-top: 100px;">
	<div class="row justify-content-center">
		<div class="col-sm-6 card shadow" style="">
			<div class="card-body" style="padding-top: 30px; padding-bottom: 30px;">
				<div class="row justify-content-center">

					<div class="col-10 animated fadeInLeftBig " style="display: none;" id="enter-new-password-div">

						<h4 class="text-center heading-text">Enter New Password For Username</h4>
						<?php 
							$attr = array('class' => 'container','id' => 'enter-new-password-form');
							
							if(isset($_GET['id'])){
								echo form_open("sabicapital/change_password_reset?id=".$_GET['id'],$attr); 
							}else{
								echo form_open("sabicapital/change_password_reset",$attr); 
							}
						?>
							<div class="form-group">
								
								<input type="text" class="form-control shadow-sm" id="new_password" name="new_password" placeholder="Password">
								<span class="form-error"></span>
							</div>
							
							
							<button class="btn btn-submit btn-block text-center shadow-sm" type="submit">
								Submit 
								<!-- <div class="clearfix"> -->
									<div style="margin-top: 5px;" class="spinner-border spinner-border-sm float-right" role="status">
									  <span class="sr-only">Loading...</span>
									</div>
								<!-- </div> -->
							</button>
						</form>
					</div>

					<div class="col-10 animated fadeInLeftBig " style="display: none;" id="forgot-pass-otp-div">

						<h4 class="text-center heading-text">An OTP Has Been Sent To </h4>
						<?php 
							$attr = array('class' => 'container','id' => 'forgot-pass-otp-form');
							
							if(isset($_GET['id'])){
								echo form_open("sabicapital/verify_user_forgot_password_otp?id=".$_GET['id'],$attr); 
							}else{
								echo form_open("sabicapital/verify_user_forgot_password_otp",$attr); 
							}
						?>
							<div class="form-group">
								
								<input type="text" class="form-control shadow-sm" id="otp_input" name="otp_input" placeholder="Enter OTP">
								<span class="form-error"></span>
							</div>
							
							
							<button class="btn btn-submit btn-block text-center shadow-sm" type="submit">
								Submit 
								<!-- <div class="clearfix"> -->
									<div style="margin-top: 5px;" class="spinner-border spinner-border-sm float-right" role="status">
									  <span class="sr-only">Loading...</span>
									</div>
								<!-- </div> -->
							</button>
						</form>
					</div>

					<div class="col-10 animated fadeInLeftBig " style="display: none;" id="enter-username-div">

						<h4 class="text-center heading-text">Enter Username</h4>
						<?php 
							$attr = array('class' => 'container','id' => 'enter-username-form');
							echo form_open('sabicapital/check_if_user_name_exists',$attr);
						?>
							<div class="form-group">
								
								<input type="text" class="form-control shadow-sm" id="user_name" name="user_name" placeholder="User Name">
								<span class="form-error"></span>
							</div>
							
							
							<button class="btn btn-submit btn-block text-center shadow-sm" type="submit">
								Submit 
								<!-- <div class="clearfix"> -->
									<div style="margin-top: 5px;" class="spinner-border spinner-border-sm float-right" role="status">
									  <span class="sr-only">Loading...</span>
									</div>
								<!-- </div> -->
							</button>
						</form>
					</div>

					<div class="col-10 animated fadeInLeftBig " style="" id="login-div">

						<h4 class="text-center heading-text">Log Into SabiCapital</h4>
						<?php 
							$attr = array('class' => 'container','id' => 'login-form');
							echo form_open('sabicapital/process_sign_in',$attr);
						?>

							<div class="form-group">
								
								<input type="text" class="form-control shadow-sm" id="user_name_login" name="user_name_login" placeholder="User Name">
								<span class="form-error"></span>
							</div>
							
							<div class="form-group">
								
								<input type="password" class="form-control shadow-sm" id="password_login" name="password_login" placeholder="Password">
								<span class="form-error"></span>
							</div>
							<button class="btn btn-submit btn-block text-center shadow-sm" type="submit">
								Submit 
								<!-- <div class="clearfix"> -->
									<div style="margin-bottom:20px;" class="spinner-border spinner-border-sm float-right" role="status">
									  <span class="sr-only">Loading...</span>
									</div>
								<!-- </div> -->
							</button>
							
						</form>

						<p class="btn-seperator" style="margin-bottom: 50px;">
							<span style="color: #7ea960; cursor: pointer;" onclick="forgotPass(this,event)">Forgot Password ?</span>
						</p>
						
						

						<p class="btn-seperator">
							<span>New To Sabicapital?</span>
						</p>
						
						<div class="row justify-content-center" style="margin-top: 40px;">
							<button class="card shadow-sm text-center sign-up-btn" style="" onclick="openSignUpDiv(this,event)">Sign Up</button>
						</div>
					</div>
					<div class="col-10 animated fadeInLeftBig " style="display: none;" id="signup-div">

						<h4 class="text-center heading-text">Create Your Free SabiCapital Account</h4>
						<?php 
							$attr = array('class' => 'container','id' => 'signup-form');
							if(isset($_GET['id'])){
								echo form_open('sabicapital/process_user_sign_up?id='.$_GET['id'],$attr);
							}else{
								echo form_open('sabicapital/process_user_sign_up',$attr);
							}
						?>	

							<div class="form-group">
								
								<input type="text" class="form-control shadow-sm" id="full_name" name="full_name" placeholder="Enter Full Name" >
								<span class="form-error"></span>
							</div>

							<div class="form-group">
								
								<input type="email" class="form-control shadow-sm" id="email" name="email" placeholder="Enter Email Address" >
								<span class="form-error"></span>
							</div>

							<div class="form-group">
								
								<input type="number" class="form-control shadow-sm" id="phone" name="phone" placeholder="Enter Phone Number" >
								<span class="form-error"></span>
							</div>

							<div class="form-group">
								
								<input type="text" class="form-control shadow-sm" id="user_name_sign_up" name="user_name_sign_up" placeholder="Enter User Name" >
								<span class="form-error"></span>
							</div>
							
							<div class="form-group">
								
								<input type="password" class="form-control shadow-sm" id="password_sign_up" name="password_sign_up" placeholder="Password" >
								<span class="form-error"></span>
							</div>
							<button class="btn btn-submit btn-block text-center shadow-sm" type="submit">
								Submit
								<div style="margin-top: 5px;" class="spinner-border spinner-border-sm float-right" role="status">
								  <span class="sr-only">Loading...</span>
								</div>
							</button>
							
						</form>

						<p class="btn-seperator">
							<span>Already Registered?</span>
						</p>
						
						<div class="row justify-content-center" style="margin-top: 40px;">
							<button class="card shadow-sm text-center sign-up-btn" style="" onclick="openLogInDiv(this,event)">
								Log In
								
							</button>
						</div>
					</div>
					<div class="col-10 animated fadeInLeftBig " style="display: none;" id="signup-otp-div">

						<h4 class="text-center heading-text">An OTP Has Been Sent To </h4>
						<?php 
							$attr = array('class' => 'container','id' => 'signup-otp-form','autocomplete' => 'off');
							if(isset($_GET['id'])){
								echo form_open("sabicapital/process_user_sign_up_cont?id=".$_GET['id'],$attr); 
							}else{
								echo form_open("sabicapital/process_user_sign_up_cont",$attr); 
							}
						?>

							<div class="form-group">
								
								<input type="number" class="form-control shadow-sm" id="otp_input" name="otp_input" placeholder="Enter OTP" >
							</div>
							
							<button class="btn btn-submit btn-block text-center shadow-sm" type="submit">
								Proceed 
								<!-- <div class="clearfix"> -->
									<div style="margin-top: 5px;" class="spinner-border spinner-border-sm float-right" role="status">
									  <span class="sr-only">Loading...</span>
									</div>
								<!-- </div> -->
							</button>
							
						</form>

						<p class="btn-seperator" style="margin-top: 40px;">
							<span>Not Received? </span>
						</p>
						
						<div class="row justify-content-center" style="margin-top: 35px;">
							<button class="card shadow-sm text-center sign-up-btn" style="" onclick="sendSignUpOtpAgain(this,event)">Send OTP Again</button>
						</div>

						<p class="btn-seperator" style="margin-top: 60px;">
							<span style="cursor: pointer; color: #7ea960;" onclick="changeYourDetails(this,event)">Change Your Details</span>
						</p>
						
						
					</div>
				</div>
			</div>
		</div>
	</div>
	
</div>

<script>
	$(document).ready(function () {
		$("#enter-new-password-form").submit(function (evt) {
			evt.preventDefault();
			var me = $(this);
			var url = me.attr("action");
			var form_data = me.serializeArray();
			var spinner = me.find(".spinner-border");
			var submit_btn = me.find("button");

			console.log(form_data)
			spinner.show();
			submit_btn.addClass('disabled');
			submit_btn.css({
				"cursor" : "unset"
			})

			$.ajax({
		        url : url,
		        type : "POST",
		        responseType : "json",
		        dataType : "json",
		        data : form_data,
		        success : function (response) {
		        	spinner.hide();
					submit_btn.removeClass('disabled');
					submit_btn.css({
						"cursor" : "pointer"
					})
	        		if(response.success ){
                        var url = response.url;

                        window.location.assign(url);
                    }else if(response.expired){
                        $.notify({
                          message:"It Seems The Requested OTP Has Expired. Please Request A New One"
                          },{
                            type : "warning"
                        });
                    }else if(response.new_password_absent){
                        $.notify({
                          message:"The New Password Is Required."
                          },{
                            type : "warning"  
                        });
                    }else{
                       $.notify({
                          message:"Something Went Wrong."
                          },{
                            type : "warning"  
                        });
                    }  
	            },error : function () {
	            	spinner.hide();
					submit_btn.removeClass('disabled');
					submit_btn.css({
						"cursor" : "pointer"
					})
	            	swal({
	                    title: 'Ooops',
	                    text: "Something Went Wrong. Please Check Your Internet Connection",
	                    type: 'error',						                  
	                })
	            }
	        });

		})

		$("#forgot-pass-otp-form").submit(function (evt) {
			evt.preventDefault();
			var me = $(this);
			var url = me.attr("action");
			var form_data = me.serializeArray();
			var spinner = me.find(".spinner-border");
			var submit_btn = me.find("button");

			console.log(form_data)
			spinner.show();
			submit_btn.addClass('disabled');
			submit_btn.css({
				"cursor" : "unset"
			})

			$.ajax({
		        url : url,
		        type : "POST",
		        responseType : "json",
		        dataType : "json",
		        data : form_data,
		        success : function (response) {
		        	spinner.hide();
					submit_btn.removeClass('disabled');
					submit_btn.css({
						"cursor" : "pointer"
					})
	        		if(response.success ){
                        var user_name = response.user_name;

                        $("#forgot-pass-otp-div").hide();
                        $("#enter-new-password-div .heading-text").html("Enter New Password For Username <br> <small><em class=''>" + user_name + "</em></small>");
                        $("#enter-new-password-div").show();

                    }else if(response.expired){
                        
                        swal({
		                    title: 'Ooops',
		                    text: "It Seems The Requested OTP Has Expired. Please Request A New One",
		                    type: 'warning',						                  
		                })
                    }else if(response.otp_not_present){
                        
                        swal({
		                    title: 'Ooops',
		                    text: "The OTP Field Is Required.",
		                    type: 'warning',						                  
		                })
                    }else if(response.incorrect_otp){
                        swal({
		                    title: 'Ooops',
		                    text: "The OTP Entered Is Incorrect. Please Enter The Valid One.",
		                    type: 'warning',						                  
		                })
                    }else{
                       swal({
		                    title: 'Ooops',
		                    text: "Something Went Wrong.",
		                    type: 'warning',						                  
		                })
                        
                    }  
	            },error : function () {
	            	spinner.hide();
					submit_btn.removeClass('disabled');
					submit_btn.css({
						"cursor" : "pointer"
					})
	            	swal({
	                    title: 'Ooops',
	                    text: "Something Went Wrong. Please Check Your Internet Connection",
	                    type: 'error',						                  
	                })
	            }
	        });

		})

		$("#enter-username-form").submit(function (evt) {
			evt.preventDefault();
			var me = $(this);
			var url = me.attr("action");
			var form_data = me.serializeArray();
			var spinner = me.find(".spinner-border");
			var submit_btn = me.find("button");

			console.log(form_data)
			spinner.show();
			submit_btn.addClass('disabled');
			submit_btn.css({
				"cursor" : "unset"
			})

			$.ajax({
		        url : url,
		        type : "POST",
		        responseType : "json",
		        dataType : "json",
		        data : form_data,
		        success : function (response) {
		        	spinner.hide();
					submit_btn.removeClass('disabled');
					submit_btn.css({
						"cursor" : "pointer"
					})
	        		if(response.empty == true){
		    			swal({
		                  title: 'Error',
		                  text: "Sorry, This Field Cannot Be Empty",
		                  type: 'error',						                  
		                })
		            }    
		        	else if(response.no_post == true){
		        		$.notify({
		                	message:"Sorry Something Went Wrong"
		                },{
		                  	type : "warning"  
		                });
		    		
		    		}else if(response.success == true && response.mobile !== "" && response.full_name !== "" && response.user_id !== ""){
		    			var email = response.email;
		    			var mobile = response.mobile;
		    			var full_name = response.full_name;
		    			var user_id = response.user_id;
		    			var url = response.url;

		    			global_email = email;

		    			swal({
				            title: 'Choose Action',
				            html: "<h4>Are These Your Details?</h4><p style='color: black;'>Full Name: <span class='text-primary' style='font-style: italic;'>"+ full_name +"</span></p><p style='color: black;'>Mobile Number :<span class='text-primary' style='font-style: italic;'>"+ mobile +"</span></p><p style='color: black;'>Email Adress :<span class='text-primary' style='font-style: italic;'>"+ email +"</span></p>",
				            type: 'success',
				            showCancelButton: true,
				            confirmButtonColor: '#3085d6',
				            cancelButtonColor: '#d33',
				            confirmButtonText: 'Yes',
				            cancelButtonText : "No"
				        }).then((result) => {
							if (result.value) {

								sendForgotPassOtp(this,event);

						    }
				        },function(dismiss){
				            if(dismiss == 'cancel'){
				            	
				            }
			            });
		    		}else{
		    			swal({
		                  title: 'Error',
		                  text: "Sorry, This Username Is Not Associated With Any Registered Account",
		                  type: 'error',						                  
		                })
		    		}
	            },error : function () {
	            	spinner.hide();
					submit_btn.removeClass('disabled');
					submit_btn.css({
						"cursor" : "pointer"
					})
	            	swal({
	                    title: 'Ooops',
	                    text: "Something Went Wrong. Please Check Your Internet Connection",
	                    type: 'error',						                  
	                })
	            }
	        });

		})

		$("#login-form").submit(function (evt) {
			evt.preventDefault();
			var me = $(this);
			var url = me.attr("action");
			var form_data = me.serializeArray();
			var spinner = me.find(".spinner-border");
			var submit_btn = me.find("button");

			console.log(form_data)
			spinner.show();
			submit_btn.addClass('disabled');
			submit_btn.css({
				"cursor" : "unset"
			})

			$.ajax({
		        url : url,
		        type : "POST",
		        responseType : "json",
		        dataType : "json",
		        data : form_data,
		        success : function (response) {
		        	spinner.hide();
					submit_btn.removeClass('disabled');
					submit_btn.css({
						"cursor" : "pointer"
					})
	        		if(response.success){
                        var url = response.url;
                        window.location.assign(url);
                    }else if(response.half_registered){
                        var url = response.url;
                        var user_name = response.user_name;
                        window.location.assign(url);
                    }
                    else if(response.user_exists == false){
                        swal({
                          title: 'Error',
                          text: "This User Does Not Exist",
                          type: 'error',                                          
                        })
                    }else if(response.wrong_password == true){
                        swal({
                          title: 'Error',
                          text: "Wrong Credentials Entered. Try Again",
                          type: 'error',                                          
                        })
                    }else if(response.user_deactivated == true){
                        swal({
                          title: 'Error',
                          text: "You Have Been Deactivated By The Admin. Please Contact Him To Reactivate Your Account.",
                          type: 'error',                                          
                        })
                    }else{
                    	$.each(response.messages, function (key,value) {

			              var element = $('#'+key);
			              
			              element.closest('div.form-group')
			                      
			                      .find('.form-error').remove();
			              element.after(value);
			              
			            });

			            $.notify({
			              message:"Some Values Where Not Valid. Please Enter Valid Values"
			            },{
			              type : "warning"  
			            });
                    }
	            },error : function () {
	            	spinner.hide();
					submit_btn.removeClass('disabled');
					submit_btn.css({
						"cursor" : "pointer"
					})
	            	swal({
	                    title: 'Ooops',
	                    text: "Something Went Wrong. Please Check Your Internet Connection",
	                    type: 'error',						                  
	                })
	            }
	        });

		})

		$("#signup-otp-form").submit(function (evt) {
			evt.preventDefault();
			var me = $(this);
			var url = me.attr("action");
			var form_data = me.serializeArray();
			var spinner = me.find(".spinner-border");
			var submit_btn = me.find("button");

			console.log(form_data)
			spinner.show();
			submit_btn.addClass('disabled');
			submit_btn.css({
				"cursor" : "unset"
			})

			$.ajax({
		        url : url,
		        type : "POST",
		        responseType : "json",
		        dataType : "json",
		        data : form_data,
		        success : function (response) {
		        	spinner.hide();
					submit_btn.removeClass('disabled');
					submit_btn.css({
						"cursor" : "pointer"
					})
	        		if(response.success){
                        var url = response.url;
                        window.location.assign(url);
                    }else{
                        // console.log('test');
                        if(response.expired){
                            swal({
                              title: 'Error',
                              text: "This OTP Has Expired. Please Request Another One.",
                              type: 'error',                                          
                            })
                        }else if(response.incorrect_otp){
                            swal({
                              title: 'Error',
                              text: "This OTP Entered Is Incorrect. Please Enter The Valid One",
                              type: 'error',                                          
                            })
                        }else if(response.phone_used){
                            swal({
                              title: 'Error',
                              text: "This Phone Number Has Already Been Used.",
                              type: 'error',                                          
                            })
                        }else{
                        	swal({
			                    title: 'Ooops',
			                    text: "Something Went Wrong.",
			                    type: 'error',						                  
			                })
                        }
                    }
	            },error : function () {
	            	spinner.hide();
					submit_btn.removeClass('disabled');
					submit_btn.css({
						"cursor" : "pointer"
					})
	            	swal({
	                    title: 'Ooops',
	                    text: "Something Went Wrong. Please Check Your Internet Connection",
	                    type: 'error',						                  
	                })
	            }
	        });

		})

		$("#signup-form").submit(function (evt) {
			evt.preventDefault();
			var me = $(this);
			var url = me.attr("action");
			var form_data = me.serializeArray();
			var spinner = me.find(".spinner-border");
			var submit_btn = me.find("button");

			console.log(form_data)
			spinner.show();
			submit_btn.addClass('disabled');
			submit_btn.css({
				"cursor" : "unset"
			})

			$.ajax({
		        url : url,
		        type : "POST",
		        responseType : "json",
		        dataType : "json",
		        data : form_data,
		        success : function (response) {
		        	spinner.hide();
					submit_btn.removeClass('disabled');
					submit_btn.css({
						"cursor" : "pointer"
					})
	        		if(response.success){
			        	url1 = response.url;
                        var code = "+" + response.code;
                        var phone_number = response.phone_number;
                        var email = response.email;
                        

                        $("#signup-div").hide();
                        $("#signup-otp-div .heading-text").html("OTP Sent To <br> <small><em>" + email + "</em></small>");
                        $("#signup-otp-div").show();
	                }else if(response.half_registered){
                        var url = response.url;
                        var user_name = response.user_name;
                        window.location.assign(url);
                    }else if(response.phone_used){
                        $.notify({
                          message:"This Phone Number Has Already Been Used."
                          },{
                            type : "warning"  
                        });
                    }else{
	                	$.each(response.messages, function (key,value) {

			              var element = $('#'+key);
			              
			              element.closest('div.form-group')
			                      
			                      .find('.form-error').remove();
			              element.after(value);
			              
			            });

			            $.notify({
			              message:"Some Values Where Not Valid. Please Enter Valid Values"
			            },{
			              type : "warning"  
			            });
	                }
	            },error : function () {
	            	spinner.hide();
					submit_btn.removeClass('disabled');
					submit_btn.css({
						"cursor" : "pointer"
					})
	            	swal({
	                    title: 'Ooops',
	                    text: "Something Went Wrong. Please Check Your Internet Connection",
	                    type: 'error',						                  
	                })
	            }
	        });

		})
	})
</script>