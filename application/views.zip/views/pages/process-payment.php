      
      <script>
         function addCommas(nStr)
  {
      nStr += '';
      x = nStr.split('.');
      x1 = x[0];
      x2 = x.length > 1 ? '.' + x[1] : '';
      var rgx = /(\d+)(\d{3})/;
      while (rgx.test(x1)) {
          x1 = x1.replace(rgx, '$1' + ',' + '$2');
      }
      return x1 + x2;
  }
       </script>
      <div class="spinner-overlay" >
        <div class="spinner-well">
          <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading...">
        </div>
        <p>Processing....</p>
      </div>
      <div class="content">
        <div class="container-fluid">
          
          <div class="row">
          </div>
        </div>
      </div>
      <footer class="footer">
        <div class="container-fluid">
          
        </div>
      </footer>
      <?php 

      ?>
    
      <script>
        $(document).ready(function() {
        });
      </script>
    </div>
  </div>
  <!--   Core JS Files   -->
 