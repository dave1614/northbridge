         <!-- End Navbar -->
      <script>
         function addCommas(nStr)
          {
              nStr += '';
              x = nStr.split('.');
              x1 = x[0];
              x2 = x.length > 1 ? '.' + x[1] : '';
              var rgx = /(\d+)(\d{3})/;
              while (rgx.test(x1)) {
                  x1 = x1.replace(rgx, '$1' + ',' + '$2');
              }
              return x1 + x2;
          }

          function withdrawFunds(elem) {
            $("#withdraw-funds-modal").modal({
              "show" : true,
              "backdrop" : false,
              "keyboard" : false
            })
          }

          function selectUser(elem,id) {
            var user_name = elem.getAttribute("data-user-name");
            var full_name = elem.getAttribute("data-full-name");
            var modal_title = $("#fundUserModal .modal-title").html();
            $("#fundUserModal .modal-title").html(modal_title + "" + user_name);
            $("#fundUserModal #enter_amount_form").attr("data-id",id);
            $("#fundUserModal #enter_amount_form").attr("data-name",full_name);
            $("#fundUserModal").modal({
              "show" : true,
              "backdrop" : false,
              "keyboard" : false
            })
          }

          function reloadPage (elem) {
            document.location.reload(); 
          }
      </script>
      <div class="content">
        <div class="container-fluid">
          <div class="spinner-overlay" style="display: none;">
            <div class="spinner-well">
              <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading..." style="">
            </div>
          </div>
          <h2>Fund Users</h2>
          <div class="row justify-content-center">
            <div class="col-sm-10 text-center">
              <div class="card" id="main-card">
                <div class="card-header">
                  <h3 class="card-title">Enter User Name</h3>
                </div>
                <div class="card-body">
                  <?php 
                    $attr = array('id' => 'user_name_form');
                    echo form_open("meetglobal/submit_user_name",$attr);
                  ?>

                    <div class="form-group">
                      <input type="text" placeholder="User Name" id="user_name" name="user_name" class="form-control">
                    </div>
                    <input type="submit" class="btn btn-primary">
                  </form>
                </div>
              </div>

              <div class="card" id="display-users-card" style="display: none;">
                <div class="card-header">
                  <h3 class="card-title">Search Results</h3>
                  <div class="text-left">
                    <button class="btn btn-warning text-left" onclick="reloadPage(this)">Go Back</button>
                  </div>
                </div>
                <div class="card-body">
                  
                </div>
              </div>
            </div>

            <div class="modal fade" id="fundUserModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLabel">Enter Amount To Fund </h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                   <?php
                    $attr = array('id' => 'enter_amount_form','data-id' => '','data-name' => '');
                    echo form_open('',$attr); 
                   ?>
                   <div class="form-group col-sm-12">
                     <input type="number" class="form-control" placeholder="Amount...." id="amount" name="amount" step="any">
                   </div>
                   </form>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
      <footer class="footer">
        <div class="container-fluid">
          <footer></footer>
        </div>
      </footer>
      
      <script>
        $(document).ready(function () {

          $("#enter_amount_form").submit(function (evt) {
            evt.preventDefault();
            var full_name = $(this).attr("data-name");
            var user_id = $(this).attr("data-id");
            var amount = $("#enter_amount_form #amount").val();
            swal({
              title: 'Proceed?',
              text: "<span class='text-primary'>Are You Sure You Want To Credit " + full_name + " With ₦" + addCommas(amount) + " ?</span>",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes',
              cancelButtonText : "No"
            }).then(function(){
              $(".spinner-overlay").show();
              var url = "<?php echo site_url('meetglobal/credit_user') ?>";
              var form_data = "credit_user=true&amount="+amount+"&full_name="+full_name+"&user_id="+user_id;
              $.ajax({
                url : url,
                type : "POST",
                responseType : "json",
                dataType : "json",
                data : form_data,
                success : function(response){
                  $(".spinner-overlay").hide();
                  
                  if(response.success == true){
                    document.location.reload();
                  }else{
                    swal({
                      title: 'Error',
                      text: "Something Went Wrong. Try Again",
                      type: 'error'
                    })
                  }  
                },
                error : function () {
                  $(".spinner-overlay").hide();
                  $.notify({
                  message:"Something Went Wrong Please Check Your Internet Connection"
                  },{
                    type : "danger"  
                  });
                }
              });
            });  
          })
          
          $("#user_name_form").submit(function (evt) {
            evt.preventDefault();
            $(".spinner-overlay").show();
            var url = $(this).attr("action");
            var form_data = $(this).serializeArray();
            $.ajax({
              url : url,
              type : "POST",
              responseType : "text",
              dataType : "text",
              data : form_data,
              success : function(response){
                $(".spinner-overlay").hide();
                if(response !== ""){
                  $("#main-card").hide();
                  $("#display-users-card").show();
                  $("#display-users-card .card-body").html(response);
                  $("#full-user-results-table").DataTable();
                }else{
                  $.notify({
                  message:"Your Search Doesn't Match With Any Results"
                  },{
                    type : "warning"  
                  });
                }  
              },
              error : function () {
                $(".spinner-overlay").hide();
                $.notify({
                message:"Something Went Wrong Please Check Your Internet Connection"
                },{
                  type : "danger"  
                });
              }
            }); 
          })

        <?php
         if($this->session->credit_success && $this->session->amount && $this->session->full_name){ 
          $amount = $this->session->amount;
          $full_name = $this->session->full_name;
          unset($_SESSION['credit_success']);
          unset($_SESSION['amount']);
          ?>
          
          swal({
            title: 'Success',
            text: "You Have Successfully Credited <?php echo $full_name; ?> With ₦<?php echo number_format($amount); ?>",
            type: 'success'
          })
        <?php } ?>
        })
        
      </script>
    </div>
  </div>
  <!--   Core JS Files   -->
 