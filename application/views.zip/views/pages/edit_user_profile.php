<?php
  $phone = "0" . $phone;
?>
<style>
  .facility-logo-img{
   
  }
</style>

<script>
  function submitImage (elem,evt) {
    evt.preventDefault()
    var file_input = elem.querySelector("input");
    
    var file_name = file_input.getAttribute("name");
    console.log(file_name)
    var file = file_input.files;
    console.log(file)
    var form_data = new FormData();
    var error = '';
    if(file_input.value !== ""){
      if(file.length == 1){
        var name = file[0].name;
        console.log(name)
        var extension = name.split('.').pop().toLowerCase();
        
        if(jQuery.inArray(extension,['gif','png','jpg','jpeg']) == -1){
          error += "Invalid Image File Selected, Please Reselect A Valid Image";
        }else{                 
          form_data.append(file_name,file[0]);
        }
      }else{
        $.notify({
        message:"Sorry You Can Only Select One Image"
        },{
          type : "danger"  
        });
        file_input.val("");
        return false;
      }

      if(error == ''){
        var url = elem.getAttribute("action");
        $(".spinner-overlay").show();
          $.ajax({
            url : url,
            type : "POST",
            responseType : "json",
            dataType : "json",
            data : form_data,
            contentType : false,
            cache : false,
            processData : false,
            success : function (response) {
            console.log(response)             
              $(".spinner-overlay").hide();
              if(response.empty == true){
                 $.notify({
                message:"No Image Was Uploaded"
                },{
                  type : "danger"  
                });
                 file_input.val("");
              }
              else if(response.success == true && response.new_image_name !== ""){
                var new_image_name = response.new_image_name;
                
                $("#logo").remove();
                $("#submit-logo").before('<img src="' + new_image_name + '" alt="..." class="user-logo-img" width="200" height="200" id="logo">');
                $("#change-logo-modal").modal('hide');
                $(".sidebar-wrapper .user .photo").html('<img src="' + new_image_name + '" class="small-profile-img" />')
                $.notify({
                message:"Logo Changed Successfully"
                },{
                  type : "success"  
                });        
              }else if (response.success == false && response.errors !== "") {
                $.notify({
                message:"Logo Upload Was Unsuccessful"
                },{
                  type : "danger"  
                });
                swal({
                  title: 'Error',
                  text: response.errors,
                  type: 'error',
                  
                })
                file_input.val("");
              }
              
            },
            error : function () {
              $(".spinner-overlay").hide();
               $.notify({
                message:"Something Went Wrong When Trying To Upload Your Images"
                },{
                  type : "danger"  
                });
               file_input.val("");
            } 
          });
      }else{
        swal({
            title: 'Error!',
            text: error,
            type: 'error'         
          })
        file_input.val("");
      }

    }else{
       $.notify({
        message:"Sorry You Must Select One Image"
        },{
          type : "danger"  
        });
       file_input.val("");
      return false;
    }           
  }

  function buttonClicked (evt,elem) {
    evt.preventDefault();
  }

  function closeEditContactDetailsModal (elem,evt) {
    $("#edit-contact-info-btn").show("fast");
  }

  function editContactInfo (elem,evt) {
    evt.preventDefault();

    var url = "<?php echo site_url('meetglobal/get_contact_details_edit_profile') ?>"

    $(".spinner-overlay").show();
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true",
      success : function (response) {
        $(".spinner-overlay").hide();
        if(response.success && response.email != "" && response.phone_number != ""){
          var email = response.email;
          var phone_number = response.phone_number;

          var text_html = "";

          text_html += "<h4 class='text-center'>These Are Your Current Contact Details</h4>";
          text_html += "<p>Email Address: <em class='text-primary'>"+email+"</em></p>";
          text_html += "<p>Mobile Number: <em class='text-primary'>"+phone_number+"</em></p>";

          text_html += "<p style='margin-top: 20px;'>If You Wish To Edit These Details, <a href='#' onclick='editContactInfoStep1(this,event)'>Click Here</a></h5>";

          $("#edit-contact-info-modal #contact-info-div").html(text_html)
          $("#edit-contact-info-modal #contact-info-div").show();
          $("#edit-contact-info-modal #enter-otp-form").hide();
          $("#edit-contact-info-modal #enter-new-contact-details-form").hide();
          $("#edit-contact-info-modal").modal("show");

          $("#edit-contact-info-btn").hide("fast");

        }else{
          swal({
            title: 'Error',
            text: "Sorry Something Went Wrong.",
            type: 'error'
          })
        }
      },error : function () {
        $(".spinner-overlay").hide();
        swal({
          title: 'Error',
          text: "Something Went Wrong. Please Check Your Internet Connection",
          type: 'error'
        })
      }
    });
  }

  function editContactInfoStep1(elem,evt){
    evt.preventDefault();
    swal({
      title: 'Proceed?',
      text: "Are You Sure You Want To Proceed?" ,
      type: 'info',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes Proceed!',
      cancelButtonText : "No"
    }).then(function(){
    
      var url = "<?php echo site_url('meetglobal/send_otp_for_contact_details_edit') ?>"

      $(".spinner-overlay").show();
      $.ajax({
        url : url,
        type : "POST",
        responseType : "json",
        dataType : "json",
        data : "show_records=true",
        success : function (response) {
          console.log(response)
          $(".spinner-overlay").hide();
          if(response.success && response.email != "" && response.phone_number != ""){
            var email = response.email;
            var phone_number = response.phone_number;

            $("#edit-contact-info-modal #enter-otp-form .subtitle").html("An Otp Has Been Sent To <em class='text-primary'>" + email + "</em>")
            $("#edit-contact-info-modal #contact-info-div").hide();
            $("#edit-contact-info-modal #enter-new-contact-details-form").hide();
            $("#edit-contact-info-modal #enter-otp-form").show();
          }else{
            swal({
              title: 'Error',
              text: "Sorry Something Went Wrong.",
              type: 'error'
            })
          }
        },error : function () {
          $(".spinner-overlay").hide();
          swal({
            title: 'Error',
            text: "Something Went Wrong. Please Check Your Internet Connection",
            type: 'error'
          })
        }
      });
    });
  }
</script>
    
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="spinner-overlay" style="display: none;">
            <div class="spinner-well">
              <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading..." style="">
            </div>
          </div>
         
          <!-- <h2 class="text-secondary" style="text-transform: capitalize;"><?php echo $user_name; ?>'s Profile.</h2> -->
          

          <div class="row">
            <div class="col-sm-9">
              <div class="card">
                <div class="card-header card-header-icon card-header-blue">
                  <div class="card-icon">
                    <i class="material-icons">perm_identity</i>
                  </div>
                  <h4 class="card-title">Edit Your Profile</h4>

                </div>
                <div class="card-body">
                 
                  
                    <div class="row">
                      <div class="col-sm-6 text-center">
                        <div class="avatar">
                        <?php
                            if(is_null($logo)){
                              $logo_url = base_url('assets/images/avatar.jpg');
                             $logo = "<img width='200' height='200' id='logo' class='img-raised img-fluid logo-link-cont' src='".$logo_url."'  rel='tooltip' data-original-title='Change Your Profile Picture' data-toggle='modal' data-target='#change-logo-modal' data-backdrop='false' class='user-logo-img'>";
                              echo $logo;
                            }else{
                            ?>
                              <img src="<?php if(is_null($logo)){ echo base_url('assets/images/avatar.jpg'); } else{ echo base_url('assets/images/'.$logo); } ?>" alt="..." class="user-logo-img" width="200" height="200" id="logo">
                            <?php
                            }
                          ?>  
                        <button id="submit-logo" data-target="#change-logo-modal" data-toggle="modal" style="margin-top: 30px;" class="btn btn-round btn-info" onclick="return buttonClicked(event,this)">Change Profile Picture</button> 
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <?php $attr = array('id' => 'edit-user-form') ?>
                        <?php echo form_open('meetglobal/process-edit-profile',$attr); ?>
                        <div class="form-row">
                        

                        <div class="form-group col-sm-12">
                          <label for="address" class="text-primary">Edit Address: </label>
                          <textarea required class="form-control" name="address" id="address" rows="3">
                            <?php 
                             echo $address;
                            ?>
                          </textarea>
                          <span class="form-error"></span>
                        </div>
  

                        <div class="form-group col-sm-12">
                          <label for="bio" class="text-primary">Edit Bio: </label>
                          <textarea required class="form-control" name="bio" id="bio" rows="3">
                            <?php 
                              if($form_error == false){ 
                                echo trim($bio);
                              }else{
                                echo set_value('bio');
                              } 
                            ?>
                          </textarea>
                          <span class="form-error"></span>
                        </div>
                        
                        <input type="submit" name="submit" class="btn btn-round btn-primary" style="cursor: pointer;">
                      </div>

                     </div>
                    </div>
                  <?php echo form_close(); ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <a target="_blank" onclick="editContactInfo(this,event)" id="edit-contact-info-btn" rel="tooltip" data-toggle="tooltip" title="Edit Your Contact Info" style="background: #9c27b0; cursor: pointer; position: fixed; bottom: 0; right: 0;  border-radius: 50%; cursor: pointer; fill: #fff; height: 56px; outline: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.2);">
        <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
          <i class="fas fa-pen" style="font-size: 25px; color: #fff;" aria-hidden="true"></i>
        </div>
      </a>

      <div id="edit-contact-info-modal" class="modal fade " tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            
            <div class="modal-header">
              <h3 class="modal-title text-center">Edit Your Contact Info</h3>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="closeEditContactDetailsModal (this,event)">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div class="modal-body">

              <div id="contact-info-div" style="display: none;">
                
              </div>
              
              <?php $attr = array('id' => 'enter-otp-form','display' => 'none'); ?>
              <?php echo form_open("meetglobal/verify_otp_edit_profile",$attr); ?>
                <h4 class="subtitle">An Otp Has Been Sent To </h4>
                <div class="form-group">
                  
                  <input type="number" maxlength="5" name="otp" class="form-control" id="otp" placeholder="OTP... ">
                </div>
                <input type="submit" class="btn btn-primary">
              </form>

              <?php $attr = array('id' => 'enter-new-contact-details-form','display' => 'none'); ?>
              <?php echo form_open("meetglobal/edit_contact_details",$attr); ?>
                <h4 class="subtitle" style="margin-bottom: 30px;">Enter New Contact Details</h4>
                <div class="form-group">
                  <label for="email">Edit Email: </label>
                  <input type="email" name="email" class="form-control" id="email">
                  <span class="form-error"></span>
                </div>

                <div class="form-group">
                  <label for="phone_number">Edit Mobile Number: </label>
                  <input type="number" name="phone_number" class="form-control" id="phone_number">
                  <span class="form-error"></span>
                </div>
                <input type="submit" class="btn btn-primary">
              </form>
                
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal" aria-label="Close" onclick="closeEditContactDetailsModal (this,event)">Close</button>
            </div>
           
          </div>
        </div>
      </div>

      <div id="change-logo-modal" class="modal fade text-center" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <?php $attr = array('id' => 'change_user_form','onsubmit' => 'return submitImage(this,event)'); ?>
              <?php echo form_open_multipart("meetglobal/index/".$addition."/change_user_logo",$attr); ?>
            <div class="modal-header">
              <h3 class="modal-title">Change Profile Picture</h3>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div class="modal-body">
                    
              <input type="file" name="image" id="image" class="inputfile inputfile-1" accept="image/*"/>
              <label for="image"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"/></svg> <span>Choose a file&hellip;</span></label>
              <div class="text-left">
                <span class="form-error">1. Max Image Size: 5 Mb.</span><br>
                
                <span class="form-error">2. Allowed Types:PNG,JPG,JPEG</span>
                <span class="text-primary" style="display:block;">Note: The Bigger The Picture, The Longer It Takes To Upload.</span>

              </div>

          </div>
            <div class="modal-footer">
              
              <button type="submit" class="btn btn-primary text-right">Upload</button>
            </div>
            </form>
          </div>
        </div>
      </div>

      <div id="enter-otp-modal" class="modal fade text-center" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            
            <div class="modal-header">
              <h3 class="modal-title"></h3>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div class="modal-body">
              
              <?php $attr = array('id' => 'enter-otp-form'); ?>
              <?php echo form_open_multipart("meetglobal/verify_otp_edit",$attr); ?>
                <div class="form-group">

                  <input type="text" name="otp" class="form-control" autofocus="true" id="otp" placeholder="Enter Verification Code... ">
                </div>
              </form>
                
            </div>
            <div class="modal-footer">

            </div>
           
          </div>
        </div>
      </div>
      <footer class="footer">
        <div class="container-fluid">
          
        </div>
      </footer>
    </div>
  </div>
  <!--   Core JS Files   -->
 <script>
   $(document).ready(function(){

    $("#enter-new-contact-details-form").submit(function (evt) {     
      evt.preventDefault();
      var me = $(this);
      var action = me.attr("action");
      console.log(action)
      var data = me.serializeArray();
      swal({
        title: 'Proceed?',
        text: "Are You Sure You Want To Proceed?" ,
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes Proceed!',
        cancelButtonText : "No"
      }).then(function(){
        
        $(".spinner-overlay").show();
        $.ajax({
          url : action,
          type : "POST",
          responseType : "json",
          dataType : "json",
          data : data,
          success : function (response) {
            console.log(response)
            $(".spinner-overlay").hide();
            if(response.success){
              
              $.notify({
                message:"Your Contact Details Successfully Edited."
              },{
                  type : "success"  
              });

              setTimeout(function () {
                document.location.reload()
              }, 1500);

              
            }else if(response.expired){
              swal({
                title: 'Error',
                text: "Your Verification Has Expired. Please Try Again.",
                type: 'error',                              
              })
            }else{
              $.each(response.messages, function (key,value) {

              var element = $('#'+key);
              
              element.closest('div.form-group')
                      
                      .find('.form-error').remove();
              element.after(value);
              
             });
              $.notify({
              message:"Some Values Where Not Valid. Please Enter Valid Values"
              },{
                type : "warning"  
              });
            }
          },error : function () {
            $(".spinner-overlay").hide();
             
              swal({
                title: 'Error',
                text: "Something Went Wrong. Check Internet Connection And Try Again",
                type: 'error',                              
              })
            }
        });          
      });       
    })
    

    $("#enter-otp-form").submit(function (evt) {     
      evt.preventDefault();
      var me = $(this);
      var action = me.attr("action");
      var data = me.serializeArray();
      $(".spinner-overlay").show();
      $.ajax({
        url : action,
        type : "POST",
        responseType : "json",
        dataType : "json",
        data : data,
        success : function (response) {
          console.log(response)
          $(".spinner-overlay").hide();
          if(response.success && response.email != "" && response.phone_number != ""){
            var email = response.email;
            var phone_number = "0" + response.phone_number;
            $.notify({
              message:"Successfully Verified. You Can Now Edit Your Contact Information."
            },{
                type : "success"  
            });

            $("#edit-contact-info-modal #contact-info-div").hide();
            $("#edit-contact-info-modal #enter-new-contact-details-form #email").val(email);
            $("#edit-contact-info-modal #enter-new-contact-details-form #phone_number").val(phone_number);
            $("#edit-contact-info-modal #enter-new-contact-details-form").show();
            $("#edit-contact-info-modal #enter-otp-form").hide();
            
          }else if(response.expired){
            swal({
              title: 'Error',
              text: "This OTP Has Expired. Please Try Again.",
              type: 'error',                              
            })
          }else if(response.incomplete_detais){
            swal({
              title: 'Error',
              text: "Some Details Were Received By The Server. Please Try Again.",
              type: 'error',                              
            })
          }else if(response.incorrect_otp){
            swal({
              title: 'Error',
              text: "This OTP Entered Is Incorrect. Please Enter The Valid One.",
              type: 'error',                              
            })
          }else{
            swal({
              title: 'Error',
              text: "Sorry Something Went Wrong",
              type: 'error',                              
            })
          }
        },error : function () {
          $(".spinner-overlay").hide();
           
            swal({
              title: 'Error',
              text: "Something Went Wrong. Check Internet Connection And Try Again",
              type: 'error',                              
            })
          }
      });                 
    })

    $("#edit-user-form").submit(function (evt) {
      evt.preventDefault();
      var form_data = $(this).serializeArray();
      var url = $(this).attr("action");
      console.log(form_data)
      $(".form-error").html("");
      $(".spinner-overlay").show();
      $.ajax({
        url : url,
        type : "POST",
        responseType : "json",
        dataType : "json",
        data : form_data,
        success : function (response) {
          console.log(response)
          $(".spinner-overlay").hide();
          if(response.success == true){                 
            $.notify({
            message:"Your Profile Has Been Edited Successfully.",
              type : "success"  
            });            
          }
          else{
           $.each(response.messages, function (key,value) {

            var element = $('#'+key);
            
            element.closest('div.form-group')
                    
                    .find('.form-error').remove();
            element.after(value);
            
           });
            $.notify({
            message:"Some Values Where Not Valid. Please Enter Valid Values"
            },{
              type : "warning"  
            });
          }
        },
        error : function () {
          $(".spinner-overlay").hide();
          $.notify({
          message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
          },{
            type : "warning"  
          });
        }
      });
      // console.log(form_data);
    })

      $(".fileinput").fileinput({
        "name" : "logo"
      })
      var old_val = $("#address").val().trim();
      $("#address").val(old_val)
      
      <?php if($this->session->form_submitted){ ?>
         $.notify({
          message:"Your Details Have Been Changed Successfully"
        },{
          type : "success"  
        });
      <?php }  ?>

      <?php if($this->session->form_error){ ?>
         $.notify({
          message:"Sorry, Something Went Wrong."
        },{
          type : "danger"  
        });
      <?php }  ?>

      <?php if($this->session->file_upload_error){ ?>
         $.notify({
          message:"Sorry, Your Logo Wasn't Uploaded. Reason: <?php echo $this->session->file_upload_error ?>"
        },{
          type : "danger"  
        });
      <?php }  ?>
       
    });
   
 </script>