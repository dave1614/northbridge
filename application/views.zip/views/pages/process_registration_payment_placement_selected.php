<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Processing Registration Payment</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/vendor/bootstrap/css/bootstrap.min.css'); ?>">
</head>
<body>
	<?php if($success){ ?>
	<p>Processing Registration Payment... Please Do Not Reload Or Leave This Page</p>
	<?php }else{ ?>
	<p>Something Went Wrong ... Please Reload This Page</p>
	<?php } ?>
	<script src="<?php echo base_url('assets/vendor/jquery/jquery-3.2.1.min.js');?>"></script>
	<script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>
	<script src="<?php echo base_url('assets/js/bootstrap-notify.js')?> "></script>
	<script src="<?php echo base_url('assets/js/sweetalert2.all.min.js') ?>"></script>
	<script src="<?php echo base_url('assets/js/sweetalert2.min.js') ?>"></script>
	<script src="<?php echo base_url('assets/js/swal-forms.js') ?>"></script>
	<script>
		window.onbeforeunload = function() {
            return "If You Reload Or Leave This Page You Could Lose Your Money!";
        }
		$(document).ready(function () {
			var url = "<?php echo site_url('meetglobal/index/verify_registration_payment_placement_selected/'.$second_addition.'/?reference='.$_GET['reference'] . '&sponsor_id='.$_GET['sponsor_id'] . '&placement_id='.$_GET['placement_id'].'&package='.$_GET['package'] . '&positioning=' .$_GET['positioning'].'&date=' .$_GET['date'].'&time='.$_GET['time'].'&sponsor_username='.$_GET['sponsor_username'] )?>";
			

	        $.ajax({
	            url : url,
	            type : "POST",
	            responseType : "json",
	            dataType : "json",
	            data : "",
	            success : function (response) {
	                if(response.success){
	                	window.location.assign(response.url);
	                }else{
	                	$.notify({
	                      message:"Sorry Something Went Wrong. Please Reload This Page"
	                      },{
	                        type : "warning"  
	                      });
	                }
	            },error : function () {
	            	$.notify({
	                  message:"Sorry Something Went Wrong. Please Reload This Page"
	                  },{
	                    type : "danger"  
	                  });
	            }   
	        }); 
		})
	</script>
</body>
</html>