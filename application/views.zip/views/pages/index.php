
<!-- Page Content -->
  <div class="container-fluid">
    <div class="container-fluid">
      
      <div class="" id="carousel-div">
        <div class="card border-0 shadow" >
          <div class="card-body" style="padding: 0;">
            <div class="owl-carousel">
              <div> <img src="<?php echo base_url('assets/images/Office1.PNG') ?>" alt=""></div>
              <div><a href="<?php echo site_url('sabicapital/carousel-img?pos=2') ?>">  <img src="<?php echo base_url('assets/images/Meeting edit.PNG') ?>" alt=""> </a></div>
              <div><a href="<?php echo site_url('sabicapital/carousel-img?pos=3') ?>">  <img src="<?php echo base_url('assets/images/contest2.PNG') ?>" alt=""> </a></div>
              <div><a href="<?php echo site_url('sabicapital/carousel-img?pos=4') ?>">  <img src="<?php echo base_url('assets/images/sabi manager.PNG') ?>" alt=""> </a></div>
              <div><a href="<?php echo site_url('sabicapital/carousel-img?pos=5') ?>">  <img src="<?php echo base_url('assets/images/TOOLS.PNG') ?>" alt=""> </a></div>
              
            </div>
          </div>
        </div>
      </div>

      <div class="container" id="main-content-section" style="margin-top: 30px;">
        <h3 class="text-center " style="text-transform: capitalize;" id="introductory-heading">Welcome to Sabi Capital official website</h3>
        <div class="border-bottom-first-container" >
          <div class="border-bottom-second-container" >
            <span class="border-bottom-green text-center"></span>
          </div>
        </div>

      </div>
        
      <div class="" id="first-left-sidebar" style="margin-top: 30px;">
        <div class="card border-0 shadow" >

          <div class="list-group flex-md-row">
            <a href="<?php echo site_url('sabicapital/open_live_account') ?>" class="list-group-item list-group-item-action list-group-item-custom" ><i class="fas fa-circle"></i>&nbsp;<span>Open Live Account</span></a>
            <a href="<?php echo site_url('sabicapital/fund_superforex_account') ?>" class="list-group-item list-group-item-action list-group-item-custom" ><i class="fas fa-circle"></i>&nbsp;<span>Fund Account</span></a>
            <a href="<?php echo site_url('sabicapital/withdraw_superforex_account') ?>" class="list-group-item list-group-item-action list-group-item-custom" ><i class="fas fa-circle"></i>&nbsp;<span>Withdraw</span></a>
            <a href="#" class="list-group-item list-group-item-action list-group-item-custom" ><i class="fas fa-circle"></i>&nbsp;<span>Trade Forex</span></a>
            <a href="<?php echo site_url('sabicapital/carousel-img?pos=2') ?>" class="list-group-item list-group-item-action list-group-item-custom" ><i class="fas fa-circle"></i>&nbsp;<span>Sabi Traders Forum</span></a>
            <a href="<?php echo site_url('sabicapital/carousel-img?pos=6') ?>" class="list-group-item list-group-item-action list-group-item-custom" ><i class="fas fa-circle"></i>&nbsp;<span>Business / Oppurtunity</span></a>
            <a href="#" class="list-group-item list-group-item-action list-group-item-custom" ><i class="fas fa-circle"></i>&nbsp;<span>Products / Services</span></a>
            
          </div>

        </div>
      </div>

      

    </div>
  </div>

  