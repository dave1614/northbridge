         <!-- End Navbar -->
      <style>
        .sum{
          font-style: italic;
        }
      </style>
      <script>
         function addCommas(nStr)
          {
              nStr += '';
              x = nStr.split('.');
              x1 = x[0];
              x2 = x.length > 1 ? '.' + x[1] : '';
              var rgx = /(\d+)(\d{3})/;
              while (rgx.test(x1)) {
                  x1 = x1.replace(rgx, '$1' + ',' + '$2');
              }
              return x1 + x2;
          }

          

          function reloadPage (elem) {
            document.location.reload(); 
          }

          function transferToMainAcct(elem,evt){
            $("#transfer-to-main-acct-modal").modal("show");
          }
      </script>
      <div class="content">
        <div class="container-fluid">
          <div class="spinner-overlay" style="display: none;">
            <div class="spinner-well">
              <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading..." style="">
            </div>
          </div>
          <h2>Admins Earnings</h2>
          <div class="row justify-content-center">
            <div class="col-sm-8">
              <div class="card">
                <div class="card-header">
                  <!-- <h3 class="card-title">Meet Global Resources(MGR)</h3> -->
                </div>
                <div class="card-body">
                  <div class="table-div material-datatables table-responsive" style="">
                    <table class="table table-striped table-bordered nowrap hover display" id="all-earnings-table" cellspacing="0" width="100%" style="width:100%">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th></th>
                          <th>Earnings</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          $admin_basic_sponsor_bonus = $this->meetglobal_model->getAdminBasicSponsorBonus();
                          $admin_business_sponsor_bonus = $this->meetglobal_model->getAdminPlacementSponsorBonus();
                          $admin_center_leader_selection_income = $this->meetglobal_model->getUserParamById("admin_center_leader_selection_income",$this->meetglobal_model->getAdminId());
                          $total_vat_accrued = $this->meetglobal_model->getUserParamById("admin_vat_total",$this->meetglobal_model->getAdminId());

                          $total_earnings = $admin_basic_sponsor_bonus + $admin_business_sponsor_bonus + $admin_center_leader_selection_income + $total_vat_accrued;

                          $total_mlm_withdrawn = $this->meetglobal_model->getUserParamById("admin_mlm_withdrawn",$this->meetglobal_model->getAdminId());
                          $grand_total_balance = $total_earnings - $total_mlm_withdrawn;
                        ?>

                        <tr>
                          <td>1</td>
                          <td>Admin Basic Sponsor Earnings</td>
                          <td><?php echo '₦'.number_format($admin_basic_sponsor_bonus,2);?></td>
                        </tr>
                        <tr>
                          <td>2</td>
                          <td>Admin Business Sponsor Earnings</td>
                          <td><?php echo '₦'.number_format($admin_business_sponsor_bonus,2);?></td>
                        </tr>
                        <tr>
                          <td>3</td>
                          <td>Admin Center Leader Selection Earnings</td>
                          <td><?php echo '₦'.number_format($admin_center_leader_selection_income,2);?></td>
                        </tr>
                        <tr>
                          <td>4</td>
                          <td>Total Vat Accrued</td>
                          <td><?php echo '₦'.number_format($total_vat_accrued,2);?></td>
                        </tr>
                        <tr>
                          <td><p style="visibility: hidden;">5</p></td>
                          <td></td>
                          <td></td>
                        </tr>
                        <tr>
                          <td><p style="visibility: hidden;">6</p></td>
                          <td style="font-weight: 900;">Total Earnings</td>
                          <td style="font-weight: 900;"><?php echo '₦'.number_format($total_earnings,2);?></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  <div class="container">
                    <h4>Grand Total Withdrawable Earnings: <em class="text-primary"><?php echo '₦'.number_format($total_earnings,2); ?></em></h4>

                    <h4>Total Withdrawn: <em class="text-primary"><?php echo '₦'.number_format($total_mlm_withdrawn,2); ?></em></h4>

                    <h4>Grand Total Balance: <em class="text-primary"><?php echo '₦'.number_format($grand_total_balance,2); ?></em></h4>

              
              
                    <button class="btn btn-primary" onclick="transferToMainAcct(this,event)">Transfer To Your Main Account</button>
                  </div>

                  

                  


                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
     
           
          </div>
        </div>

        <div class="modal fade" data-backdrop="static" id="transfer-to-main-acct-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content" >
              <div class="modal-header">
                <h3 class="modal-title">Transfer To Main Account.</h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>

              <div class="modal-body" id="modal-body">
                <?php 
                  $attr = array('id' => 'transfer-to-main-acct-form');
                  echo form_open('meetglobal/transfer_to_main_acct_admin',$attr);
                ?>
                <div class="form-group">
                  <label for="amount">Enter Amount: </label>
                  <input type="number"  class="form-control" name="amount" id="amount" placeholder="in ₦(Naira)" required>
                  <span class="form-error"></span> 
                </div>

                <input type="submit" class="btn btn-primary">

                </form>

              </div>

              <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal" aria-label="Close">Close</button>
              </div>
            </div>
          </div>
        </div>
      <footer class="footer">
        <div class="container-fluid">
          <footer></footer>
        </div>
      </footer>
      
      <script>
        $(document).ready(function () {

          $("#transfer-to-main-acct-form").submit(function (evt) {
            evt.preventDefault();
            var me = $(this);
            var url = me.attr("action");
            var form_data = me.serializeArray();
            $(".spinner-overlay").show();
            
            $.ajax({
              url : url,
              type : "POST",
              responseType : "json",
              dataType : "json",
              data : form_data,
              success : function (response) {
                $(".spinner-overlay").hide();
                if(response.success && response.amount > 0){
                  $.notify({
                  message:"You Have Successfully Transferred ₦ " + addCommas(response.amount) + " To Your Main Account."
                  },{
                    type : "success"  
                  });

                  setTimeout(function () {
                    document.location.reload();
                  }, 1500);
                  
                }else if(response.not_enough_money){
                  swal({
                    title: 'Ooops',
                    text: "Amount Entered Exceeds Your Grand Withdrawable Income",
                    type: 'error'
                  })
                }else{
                  swal({
                    title: 'Ooops',
                    text: "Something Went Wrong",
                    type: 'warning'
                  })
                }
              },error : function () {
                $(".spinner-overlay").hide();
                swal({
                  title: 'Ooops',
                  text: "Something Went Wrong",
                  type: 'error'
                })
              }
            });
          })
          $("#all-earnings-table").DataTable();
        })
        
      </script>
    </div>
  </div>
  <!--   Core JS Files   -->
 