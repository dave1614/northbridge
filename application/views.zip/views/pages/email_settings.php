         <!-- End Navbar -->
      <style>
        tr{
          cursor: pointer;
        } 
      </style>
      <script>
        var global_user_name = "";
        var global_full_name = "";
        var global_user_id = "";

        
        var global_search = false;
         function addCommas(nStr)
          {
              nStr += '';
              x = nStr.split('.');
              x1 = x[0];
              x2 = x.length > 1 ? '.' + x[1] : '';
              var rgx = /(\d+)(\d{3})/;
              while (rgx.test(x1)) {
                  x1 = x1.replace(rgx, '$1' + ',' + '$2');
              }
              return x1 + x2;
          }

          function withdrawFunds(elem) {
            $("#withdraw-funds-modal").modal({
              "show" : true,
              "backdrop" : false,
              "keyboard" : false
            })
          }

          function selectUser(elem,id) {
            var user_name = elem.getAttribute("data-user-name");
            var full_name = elem.getAttribute("data-full-name");
            var modal_title = $("#fundUserModal .modal-title").html();
            $("#fundUserModal .modal-title").html(modal_title + "" + user_name);
            $("#fundUserModal #enter_amount_form").attr("data-id",id);
            $("#fundUserModal #enter_amount_form").attr("data-name",full_name);
            $("#fundUserModal").modal({
              "show" : true,
              "backdrop" : false,
              "keyboard" : false
            })
          }

          function reloadPage (elem) {
            document.location.reload(); 
          }

          function viewAllMembers (elem,evt) {
          
            $(".spinner-overlay").show();
            var url = "<?php echo site_url('meetglobal/load_users_for_viewing_history'); ?>";
            
            $.ajax({
              url : url,
              type : "POST",
              responseType : "json",
              dataType : "json",
              data : "show_records=true",
              success : function(response){
                $(".spinner-overlay").hide();
                if(response.success && response.messages != ""){
                  $("#display-users-card .card-body").html(response.messages);
                  $("#display-users-card #full-user-results-table").DataTable();
                  $("#main-card").hide();
                  $("#display-users-card").show();
                }else{
                  $.notify({
                  message:"Sorry Something Went Wrong"
                  },{
                    type : "warning"  
                  });
                }  
              },
              error : function () {
                $(".spinner-overlay").hide();
                $.notify({
                message:"Something Went Wrong Please Check Your Internet Connection"
                },{
                  type : "danger"  
                });
              }
            }); 
          }

          function goBackFromDisplayUsersCard (elem,evt) {
            $("#main-card").show();
            $("#display-users-card").hide();
          }

          function goBackFromDisplayUsersCardSearch (elem,evt) {
            $("#search-users-card").show();
            $("#display-users-card-search").hide();
          }

          function searchMembers (elem,evt) {
            $("#main-card").hide();
            $("#search-users-card").show();

          }

          function goBackFromSearchUsersCard (elem,evt) {
            $("#main-card").show();
            $("#search-users-card").hide();
          }

          function viewUserHistory (elem,evt,search = false) {
            elem = $(elem);
            var user_name = elem.attr("data-user-name");
            var full_name = elem.attr("data-full-name");
            var user_id = elem.attr("data-user-id");

            if(user_name != "" && full_name != "" && user_id != ""){
              global_user_name = user_name;
              global_full_name = full_name;
              global_user_id = user_id;

              if(search){
                global_search = true;
              }

              $("#choose-history-to-view-modal .modal-title").html("Choose History To View For <em class='text-primary'>"+global_full_name+"</em>");
              $("#choose-history-to-view-modal").modal("show");
            }
          }

          function viewHistoryForThisMember(elem,evt,type){
            $(".spinner-overlay").show();
            var url = "<?php echo site_url('meetglobal/load_days_for_user_selected_history'); ?>";
            
            $.ajax({
              url : url,
              type : "POST",
              responseType : "json",
              dataType : "json",
              data : "show_records=true&type="+type+"&user_id="+global_user_id,
              success : function(response){
                $(".spinner-overlay").hide();
                if(response.success && response.messages != "" && response.title != ""){
                  var title = response.title;
                  $("#user-history-dates-card .card-body").html(response.messages);
                  $("#user-history-dates-card #user-history-dates-table").DataTable();
                  $("#choose-history-to-view-modal").modal("hide");
                  if(!global_search){
                    $("#display-users-card").hide();
                  }else{
                    $("#display-users-card-search").hide();
                  }
                  $("#user-history-dates-card .card-title").html(title);
                  $("#user-history-dates-card").show();
                }else{
                  $.notify({
                  message:"Sorry Something Went Wrong"
                  },{
                    type : "warning"  
                  });
                }  
              },
              error : function () {
                $(".spinner-overlay").hide();
                $.notify({
                message:"Something Went Wrong Please Check Your Internet Connection"
                },{
                  type : "danger"  
                });
              }
            }); 
          }

          function goBackFromUserHistoryDatesCard(elem,evt){
            $("#choose-history-to-view-modal").modal("show");
            if(!global_search){
              $("#display-users-card").show();
            }else{
              $("#display-users-card-search").show();
            }
            
            $("#user-history-dates-card").hide();
          }

          function loadAccountCredithistoryByDate(elem,evt){
            elem = $(elem);
            var date = elem.attr("data-date");
            if(date != ""){
              $(".spinner-overlay").show();
              var url = "<?php echo site_url('meetglobal/load_account_credit_history_for_user_by_date'); ?>";
              
              $.ajax({
                url : url,
                type : "POST",
                responseType : "json",
                dataType : "json",
                data : "show_records=true&date="+date+"&user_id="+global_user_id,
                success : function(response){
                  $(".spinner-overlay").hide();
                  if(response.success && response.messages != ""){
                    $("#account-credit-history-card .card-body").html(response.messages);
                    $("#account-credit-history-card .card-title").html("Account Credit History <br> Full Name: <em class='text-primary'>"+global_full_name+"</em><br> User Name: <em class='text-primary'>"+global_user_name+"</em><br> Date: <em class='text-primary'>"+date+"</em>");
                    $("#account-credit-history-card #account-credit-history-table").DataTable();
                    
                    
                    $("#user-history-dates-card").hide();
                    $("#account-credit-history-card").show();
                  }else{
                    $.notify({
                    message:"Sorry Something Went Wrong"
                    },{
                      type : "warning"  
                    });
                  }  
                },
                error : function () {
                  $(".spinner-overlay").hide();
                  $.notify({
                  message:"Something Went Wrong Please Check Your Internet Connection"
                  },{
                    type : "danger"  
                  });
                }
              }); 
            }
          }

          function goBackFromAccountCreditHistoryCard (elem,evt) {
            $("#user-history-dates-card").show();
            $("#account-credit-history-card").hide();
          }

          function loadWithdrawalhistoryByDate(elem,evt){
            elem = $(elem);
            var date = elem.attr("data-date");
            if(date != ""){
              $(".spinner-overlay").show();
              var url = "<?php echo site_url('meetglobal/load_withdrawal_history_for_user_by_date'); ?>";
              
              $.ajax({
                url : url,
                type : "POST",
                responseType : "json",
                dataType : "json",
                data : "show_records=true&date="+date+"&user_id="+global_user_id,
                success : function(response){
                  $(".spinner-overlay").hide();
                  if(response.success && response.messages != ""){
                    $("#withdrawal-history-card .card-body").html(response.messages);
                    $("#withdrawal-history-card .card-title").html("Withdrawal History <br> Full Name: <em class='text-primary'>"+global_full_name+"</em><br> User Name: <em class='text-primary'>"+global_user_name+"</em><br> Date: <em class='text-primary'>"+date+"</em>");
                    $("#withdrawal-history-card #withdrawal-history-table").DataTable();
                    
                    
                    $("#user-history-dates-card").hide();
                    $("#withdrawal-history-card").show();
                  }else{
                    $.notify({
                    message:"Sorry Something Went Wrong"
                    },{
                      type : "warning"  
                    });
                  }  
                },
                error : function () {
                  $(".spinner-overlay").hide();
                  $.notify({
                  message:"Something Went Wrong Please Check Your Internet Connection"
                  },{
                    type : "danger"  
                  });
                }
              }); 
            }
          }

          function goBackFromWithdrawalHistoryCard (elem,evt) {
            $("#user-history-dates-card").show();
            $("#withdrawal-history-card").hide();
          }

          function loadVtuHistoryByDate(elem,evt){
            elem = $(elem);
            var date = elem.attr("data-date");
            if(date != ""){
              $(".spinner-overlay").show();
              var url = "<?php echo site_url('meetglobal/load_vtu_history_for_user_by_date'); ?>";
              
              $.ajax({
                url : url,
                type : "POST",
                responseType : "json",
                dataType : "json",
                data : "show_records=true&date="+date+"&user_id="+global_user_id,
                success : function(response){
                  $(".spinner-overlay").hide();
                  if(response.success && response.messages != ""){
                    $("#vtu-history-card .card-body").html(response.messages);
                    $("#vtu-history-card .card-title").html("VTU Transactions History <br> Full Name: <em class='text-primary'>"+global_full_name+"</em><br> User Name: <em class='text-primary'>"+global_user_name+"</em><br> Date: <em class='text-primary'>"+date+"</em>");
                    $("#vtu-history-card #vtu-history-table").DataTable();
                    
                    
                    $("#user-history-dates-card").hide();
                    $("#vtu-history-card").show();
                  }else{
                    $.notify({
                    message:"Sorry Something Went Wrong"
                    },{
                      type : "warning"  
                    });
                  }  
                },
                error : function () {
                  $(".spinner-overlay").hide();
                  $.notify({
                  message:"Something Went Wrong Please Check Your Internet Connection"
                  },{
                    type : "danger"  
                  });
                }
              }); 
            }
          }

          function goBackFromVtuHistoryCard (elem,evt) {
            $("#user-history-dates-card").show();
            $("#vtu-history-card").hide();
          }

          function loadTransferHistoryByDate(elem,evt){
            elem = $(elem);
            var date = elem.attr("data-date");
            if(date != ""){
              $(".spinner-overlay").show();
              var url = "<?php echo site_url('meetglobal/load_transfer_history_for_user_by_date'); ?>";
              
              $.ajax({
                url : url,
                type : "POST",
                responseType : "json",
                dataType : "json",
                data : "show_records=true&date="+date+"&user_id="+global_user_id,
                success : function(response){
                  $(".spinner-overlay").hide();
                  if(response.success && response.messages != ""){
                    $("#transfer-history-card .card-body").html(response.messages);
                    $("#transfer-history-card .card-title").html("Transfers History <br> Full Name: <em class='text-primary'>"+global_full_name+"</em><br> User Name: <em class='text-primary'>"+global_user_name+"</em><br> Date: <em class='text-primary'>"+date+"</em>");
                    $("#transfer-history-card #transfer-history-table").DataTable();
                    
                    
                    $("#user-history-dates-card").hide();
                    $("#transfer-history-card").show();
                  }else{
                    $.notify({
                    message:"Sorry Something Went Wrong"
                    },{
                      type : "warning"  
                    });
                  }  
                },
                error : function () {
                  $(".spinner-overlay").hide();
                  $.notify({
                  message:"Something Went Wrong Please Check Your Internet Connection"
                  },{
                    type : "danger"  
                  });
                }
              }); 
            }
          }

          function goBackFromTransferHistoryCard (elem,evt) {
            $("#user-history-dates-card").show();
            $("#transfer-history-card").hide();
          }

          function loadAdminCreditHistoryByDate(elem,evt){
            elem = $(elem);
            var date = elem.attr("data-date");
            if(date != ""){
              $(".spinner-overlay").show();
              var url = "<?php echo site_url('meetglobal/load_admin_credit_history_for_user_by_date'); ?>";
              
              $.ajax({
                url : url,
                type : "POST",
                responseType : "json",
                dataType : "json",
                data : "show_records=true&date="+date+"&user_id="+global_user_id,
                success : function(response){
                  $(".spinner-overlay").hide();
                  if(response.success && response.messages != ""){
                    $("#admin-credit-history-card .card-body").html(response.messages);
                    $("#admin-credit-history-card .card-title").html("Admin Credit History <br> Full Name: <em class='text-primary'>"+global_full_name+"</em><br> User Name: <em class='text-primary'>"+global_user_name+"</em><br> Date: <em class='text-primary'>"+date+"</em>");
                    $("#admin-credit-history-card #admin-credit-history-table").DataTable();
                    
                    
                    $("#user-history-dates-card").hide();
                    $("#admin-credit-history-card").show();
                  }else{
                    $.notify({
                    message:"Sorry Something Went Wrong"
                    },{
                      type : "warning"  
                    });
                  }  
                },
                error : function () {
                  $(".spinner-overlay").hide();
                  $.notify({
                  message:"Something Went Wrong Please Check Your Internet Connection"
                  },{
                    type : "danger"  
                  });
                }
              }); 
            }
          }

          function goBackFromAdminCreditHistoryCard (elem,evt) {
            $("#user-history-dates-card").show();
            $("#admin-credit-history-card").hide();
          }
      </script>
      <div class="content">
        <div class="container-fluid">
          <div class="spinner-overlay" style="display: none;">
            <div class="spinner-well">
              <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading..." style="">
            </div>
          </div>
          <h2 class="text-center" style="margin-bottom: 50px;">Edit Email Settings</h2>
          <div class="row justify-content-center">
            <div class="col-sm-6">

              
              
              <div class="card text-center" id="main-card">
                <div class="card-header">
                  <h3 class="card-title">Edit Default Email Address And Password </h3>
                </div>
                <div class="card-body">
                  <?php
                  $attr = array('id' => 'default-email-address-form');
                  echo form_open("meetglobal/edit_default_email_address_and_password",$attr);
                  ?>
                    <div class="form-group">
                      <label for="email_address">Email Address: </label>
                      <input type="email" class="form-control" name="email_address" id="email_address" value="<?php echo $this->meetglobal_model->getDefaultEmailAdress(); ?>" required>
                    </div>
                    <div class="form-group">
                      <label for="password">Password: </label>
                      <input type="text" class="form-control" name="password" id="password"  value="<?php echo $this->meetglobal_model->getDefaultEmailAdressPassword(); ?>" required>
                    </div>

                    <input type="submit" class="btn btn-primary" style="margin-top: 20px;">
                  </form>
                </div>
              </div>

            </div>

            <div class="modal fade" id="choose-history-to-view-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLabel">Choose History To View  For dave1614</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <table class="table">
                      <tbody>
                        <tr onclick="viewHistoryForThisMember(this,event,'account_credit')">
                          <td>1</td>
                          <td>Account Credit History</td>
                        </tr>
                        <tr onclick="viewHistoryForThisMember(this,event,'withdrawal')">
                          <td>2</td>
                          <td>Withdrawal History</td>
                        </tr>
                        <tr onclick="viewHistoryForThisMember(this,event,'vtu')">
                          <td>3</td>
                          <td>VTU History</td>
                        </tr>
                        <tr onclick="viewHistoryForThisMember(this,event,'transfer')">
                          <td>4</td>
                          <td>Transfer History</td>
                        </tr>
                        <tr onclick="viewHistoryForThisMember(this,event,'admin_credit')">
                          <td>5</td>
                          <td>Admin Credit History</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
      <footer class="footer">
        <div class="container-fluid">
          <footer></footer>
        </div>
      </footer>
      
      <script>
        $(document).ready(function () {

          
          $("#default-email-address-form").submit(function (evt) {
            evt.preventDefault();
            var  me = $(this);
            $(".spinner-overlay").show();
            
            var url = me.attr("action");
            
            var form_data = me.serializeArray();
            $.ajax({
              url : url,
              type : "POST",
              responseType : "json",
              dataType : "json",
              data : form_data,
              success : function(response){
                $(".spinner-overlay").hide();
                if(response.success){
                  $.notify({
                  message:"Default Email Address Set Successfully"
                  },{
                    type : "success"  
                  });

                  setTimeout(function () {
                    document.location.reload()
                  }, 1500);
                }else if(response.error != ""){
                  var error = response.error;
                  swal({
                    title: 'Sign In Error',
                    text: "Your Attempt To Sign In This Email Address Failed Because Of The Following Reasons <br> <em class='text-primary'>"+error+"</em>",
                    type: 'error'
                  })
                }else{
                  swal({
                    title: 'Ooops',
                    text: "Something Went Wrong.",
                    type: 'error'
                  })
                }
              },
              error : function () {
                $(".spinner-overlay").hide();
                
                swal({
                  title: 'Ooops',
                  text: "Something Went Wrong Please Check Your Internet Connection",
                  type: 'error'
                })
              }
            }); 
          })

        })
        
      </script>
    </div>
  </div>
  <!--   Core JS Files   -->
 