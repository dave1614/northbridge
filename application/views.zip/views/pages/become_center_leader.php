         <!-- End Navbar -->
      <style>
        tr{
          cursor: pointer;
        }
      </style>
      <script>
        
      </script>
      <div class="spinner-overlay" style="display: none;">
        <div class="spinner-well">
          <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading...">
        </div>
      </div>
      <div class="content">
        <div class="container-fluid">
          <h2 class="text-center">Become A Center Leader</h2>
          <h6 class="text-secondary">To Become A Center Leader You Must Pay A Fee Of 1,500 Coins</h6>
          <div class="row justify-content-center">
            <div class="col-sm-10">
              
            </div>
          </div>

        </div>
      </div>
      <footer class="footer">
        <div class="container-fluid">
          <!-- <footer>&copy; <?php echo date("Y"); ?> Copyright (meetglobal Issues Global Limited). All Rights Reserved</footer> -->
        </div>
      </footer>
      
      <script>
        $(document).ready(function () {
          
        })
      </script>
    </div>
  </div>
  <!--   Core JS Files   -->
 