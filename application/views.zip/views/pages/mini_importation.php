         <!-- End Navbar -->

<script>

function verifyThatIHaveReceivedMyOrder(elem,evt){
  elem = $(elem);
  var order_id = elem.attr("data-order-id");
  console.log(order_id);
  swal({
    title: 'Proceed? ',
    text: "You Are About To Mark This Product In This Order As Received By You. Do You Want To Proceed?",
    type: 'question',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes Proceed!',
    cancelButtonText : 'No'
  }).then(function(){
    $(".spinner-overlay").show();

    var url = "<?php echo site_url('meetglobal/mark_order_as_picked_up_by_user'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "order_id="+order_id,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true){
          swal({
            title: 'Success',
            text: "Product Successfully Marked As Received From Center Leader",
            type: 'success'
          }).then(function(){
            document.location.reload();
          })
        }else{
          swal({
            title: 'Error',
            text: "Sorry Something Went Wrong",
            type: 'error'
          })
        }
      },error : function () {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      } 
    }); 
  });  
}

function loadCenterLeaderUsersOrderInfoByOrderCode (elem,evt) {
  elem = $(elem);
  var order_code = $(elem).attr("data-order-code");
  console.log(order_code)
}

function goBackCenterLeaderRequestsUndelivered (elem,evt) {
  $("#choose-action-center-leader-requests-card").show();
  $("#center-leader-requests-card-undelivered").hide();
}

function goBackCenterLeaderRequestsDelivered (elem,evt) {
  $("#choose-action-center-leader-requests-card").show();
  $("#center-leader-requests-card-delivered").hide();
}

function loadCenterLeaderUndeliveredOrders (elem,evt) {
  evt.preventDefault();
  $(".spinner-overlay").show();

  var url = "<?php echo site_url('meetglobal/get_users_who_used_you_as_center_leader'); ?>";
  
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : "show_records=true&type=undelivered",
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success == true){
        var messages = response.messages;
        $("#choose-action-center-leader-requests-card").hide();
        $("#center-leader-requests-card-undelivered .card-body").html(messages);
        $("#center-leader-requests-card-undelivered #center-leader-requests-table").DataTable();
        $("#center-leader-requests-card-undelivered").show();
      }
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
      message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
      },{
        type : "danger"  
      });
    } 
  });   
}

function loadCenterLeaderDeliveredOrders (elem,evt) {
  evt.preventDefault();
  $(".spinner-overlay").show();

  var url = "<?php echo site_url('meetglobal/get_users_who_used_you_as_center_leader'); ?>";
  
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : "show_records=true&type=delivered",
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success == true){
        var messages = response.messages;
        $("#choose-action-center-leader-requests-card").hide();
        $("#center-leader-requests-card-delivered .card-body").html(messages);
        $("#center-leader-requests-card-delivered #center-leader-requests-table").DataTable();
        $("#center-leader-requests-card-delivered").show();
      }
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
      message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
      },{
        type : "danger"  
      });
    } 
  });   
}

function goBackChooseActionCenterLeaderRequestsCard (elem,evt) {
  $("#choose-action-card").show();
  $("#choose-action-center-leader-requests-card").hide();
}

function becomeCenterLeader (elem,evt) {
  evt.preventDefault();
  $(".spinner-overlay").show();

  var url = "<?php echo site_url('meetglobal/get_user_center_leader_info'); ?>";
  
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : "show_records=true",
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success == true){
        var messages = response.messages;
        
        if(response.type == "already"){
          swal({
            title: 'Choose Action: ',
            text: "Do You Want To? ",
            type: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Edit Your Center Leader Info',
            cancelButtonText : 'View Center Leader Requests'
          }).then(function(){
            $("#choose-action-card").hide();
            $("#edit-center-leader-info-card").show();
            $("#submit-edit-center-leader-form-btn").show("fast");
          },function(dismiss){
            if(dismiss == 'cancel'){
              $("#choose-action-card").hide();
              $("#choose-action-center-leader-requests-card").show();
            }
          });
          // $("#choose-action-card").hide();
        }else if(response.type == "not_yet"){
          $("#choose-action-card").hide();
          $("#become-center-leader-card").show();
          $("#submit-become-center-leader-form-btn").show("fast");
        }
      }else if(!response.success && response.messages != ""){
        swal({
          title: 'An Error Error Occured',
          text: "<em class='text-primary'>" + response.messages + "</em>",
          type: 'warning',                                          
        })
      }
      else{
       $.notify({
        message:"Sorry Something Went Wrong"
        },{
          type : "warning"  
        });
      }
    },
    error: function (jqXHR,textStatus,errorThrown) {
      $(".spinner-overlay").hide();
      $.notify({
      message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
      },{
        type : "danger"  
      });
    }
  });
  
}

function goBackFromBecomeCenterLeadetrCard (elem,evt) {
  $("#become-center-leader-card").hide();
  $("#choose-action-card").show();
  $("#submit-become-center-leader-form-btn").hide("fast");
}

function goBackFromEditCenterLeaderInfoCard (elem,evt) {
  $("#edit-center-leader-info-card").hide();
  $("#choose-action-card").show();
  $("#submit-edit-center-leader-form-btn").hide("fast");
}

function submitBecomeCenterLeaderForm (elem,evt) {
  $("#become-center-leader-form").submit();
}

function submitEditCenterLeaderForm (elem,evt) {
  $("#edit-center-leader-info-form").submit();
}

function shopOurProducts (elem,evt) {
  evt.preventDefault();
  $("#choose-action-card").hide();
  $("#view-cart-btn").show("fast");
  $("#shop").show();
}

function viewCart (elem,evt) {

  $(".spinner-overlay").show();

  var url = "<?php echo site_url('meetglobal/get_cart_info_mini_importation'); ?>";
  
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : "show_records=true",
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success == true){
        var messages = response.messages;
        var cart_num = response.cart_num;
        $(".cart-num").html(cart_num)
        $("#cart-modal .modal-body").html(messages);
        $("#cart-modal").modal("show");
      }
      else{
       $.notify({
        message:"Sorry Something Went Wrong"
        },{
          type : "warning"  
        });
      }
    },
    error: function (jqXHR,textStatus,errorThrown) {
      $(".spinner-overlay").hide();
      $.notify({
      message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
      },{
        type : "danger"  
      });
    }
  });
  
}

function cartQuantityChange (elem,evt) {
  elem = $(elem);
  var quantity = elem.val();
  var price = elem.attr("data-price");
  var total_quantity_disp = elem.closest("div.card").find("#total-price");
  var grand_total_price_disp = $("#grand-total-price");
  var grand_total_price = grand_total_price_disp.attr("data-price");
  var previous_quantity = elem.attr("data-previous-quantity");
  // console.log(grand_total_price)
  if(quantity > 0 && price != "" && grand_total_price != "" && previous_quantity != ""){
    quantity = Number(quantity);
    previous_quantity = Number(previous_quantity);
    price = parseFloat(price);
    grand_total_price = parseFloat(grand_total_price);
    var new_price = parseFloat((price * quantity).toFixed(2));
    total_quantity_disp.html("₦" + addCommas(new_price));
    console.log(quantity)
    console.log(previous_quantity)
    console.log(price)
    console.log(grand_total_price)
    
    var new_grand_total_price = parseFloat((((quantity - previous_quantity) * price) + grand_total_price).toFixed(2));
    grand_total_price_disp.html("₦" + addCommas(new_grand_total_price));
    grand_total_price_disp.attr("data-price",new_grand_total_price);
    elem.attr("data-previous-quantity",quantity);
  }
}

function goBackFromProductInfoCard (elem,evt) {
  $("#shop").show();
  
  $("#product-info-card").hide();
}

function addToCart (elem,e) {
  if (!e) var e = window.event;                // Get the window event
  e.cancelBubble = true;                       // IE Stop propagation
  if (e.stopPropagation) e.stopPropagation();  // Other Broswers
  var id = $(elem).attr("data-id");
  if(id != ""){
    var url = "<?php echo site_url('meetglobal/add_mini_importation_product_to_cart') ?>";
    var form_data = {
      id : id
    };
    console.log(form_data)
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : form_data,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success){
          var cart_products_num =Number($("#cart-products-num").html());
          if(!response.already_there){
            cart_products_num++;
            
            $(".cart-num").html(cart_products_num)
          }
          $.notify({
          message:"Successfully Added To Cart"
          },{
            type : "success"  
          });
        }else if(response.invalid_product_id){
          swal({
            title: 'Error',
            text: "Invalid Product Selected",
            type: 'error'
          })
        }else if(response.out_of_stock){
          swal({
            title: 'Error',
            text: "This Product Is Out Of Stock",
            type: 'error'
          })
        }else if(response.expired){
          swal({
            title: 'Error',
            text: "The Duration Set For This Product Has Expired",
            type: 'error'
          })
        }else if(response.exceeded_slots){
          swal({
            title: 'Error',
            text: "Sorry You Cannot Exceed The Number Of Available Slots.",
            type: 'error'
          })
        }else{
          $.notify({
          message:"Something Went Wrong."
          },{
            type : "warning"  
          });
        }
      },error : function () {
        $.notify({
        message:"Something Went Wrong . Please Check Your Internet Connection"
        },{
          type : "danger"  
        });
      }
    });  
  }
}

function removeProductFromCart (elem,evt) {
  elem = $(elem);
  var id = elem.attr("data-id");
  if(id != ""){
    swal({
      title: 'Warning!',
      text: "Are You Sure You Want To Remove This Product From Cart? ",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes Remove!'
      
    }).then(function(){
      $(".spinner-overlay").show();
      var url = "<?php echo site_url('meetglobal/remove_product_mini_importation_info') ?>";
      var form_data = {
        cart_id : id
      };
      $.ajax({
        url : url,
        type : "POST",
        responseType : "json",
        dataType : "json",
        data : form_data,
        success : function (response) {
          console.log(response)
          $(".spinner-overlay").hide();
          if(response.success){
            var messages = response.messages;
            var row = elem.closest('.main-row');

            var price = parseFloat(row.find('.quantity_requested').attr("data-price"));
            var quantity = parseFloat(row.find('.quantity_requested').val());
            console.log(price)
            console.log(quantity)
            var sub_total = parseFloat((price * quantity).toFixed(2));
            var grand_total_price_disp = $("#grand-total-price");
            var grand_total_price = grand_total_price_disp.attr("data-price");
            var new_grand_total_price = parseFloat((grand_total_price - sub_total).toFixed(2));
            grand_total_price_disp.html("₦" + addCommas(new_grand_total_price));
            grand_total_price_disp.attr("data-price",new_grand_total_price);
            row.remove();

            var row_num = $("#cart-modal .modal-body .main-row").length;
            
            

            if(row_num == 0){
              $(".cart-num").html(0);
              $("#label-row").remove();
              // $("#checkout-btn").remove();
              $("#grand-total-price").remove();
              $("#grand-total-cont-h5").remove();
            }else{
              $(".cart-num").html(row_num);
            }

            $.notify({
              message:"Product Removed From Cart Successfully"
              },{
                type : "success" 
            });

          }else{
            $.notify({
              message:"Sorry Something Went Wrong."
              },{
                type : "warning" 
            });
          } 
        },error : function () {
          $(".spinner-overlay").hide();
          $.notify({
            message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
            },{
              type : "danger" 
          });
        } 
      });
    });      
  }
}

function stateChanged (elem,evt) {
  elem = $(elem);
  var state_id = elem.val();
  $(".spinner-overlay").show();
  var url = "<?php echo site_url('meetglobal/get_local_govts_for_state_select') ?>";
  var form_data = {
    state_id : state_id
  };
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : form_data,
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success){
        var messages = response.messages;
        $("#become-center-leader-form #local_government").closest('div.form-group').replaceWith(messages);
        
        $("#become-center-leader-form #local_government").selectpicker();
      }else{
        $.notify({
          message:"Sorry Something Went Wrong."
          },{
            type : "warning" 
        });
      } 
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    } 
  });
}

function stateChangedEditCenterLeaderInfo (elem,evt) {
  elem = $(elem);
  var state_id = elem.val();
  $(".spinner-overlay").show();
  var url = "<?php echo site_url('meetglobal/get_local_govts_for_state_select') ?>";
  var form_data = {
    state_id : state_id
  };
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : form_data,
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success){
        var messages = response.messages;
        $("#edit-center-leader-info-form #local_government").closest('div.form-group').replaceWith(messages);
        
        $("#edit-center-leader-info-form #local_government").selectpicker();
      }else{
        $.notify({
          message:"Sorry Something Went Wrong."
          },{
            type : "warning" 
        });
      } 
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    } 
  });
}

function stateChanged1 (elem,evt) {
  elem = $(elem);
  var state_id = elem.val();
  $(".spinner-overlay").show();
  var url = "<?php echo site_url('meetglobal/get_local_govts_for_state_select') ?>";
  var form_data = {
    state_id : state_id
  };
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : form_data,
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success){
        var messages = response.messages;
        $(".center-leader-card .card-body .body #local_government").closest('div.form-group').replaceWith(messages);
        
        $(".center-leader-card .card-body .body #local_government").selectpicker();
        $(".center-leader-display").html(response.center_leader_html);
      }else{
        $.notify({
          message:"Sorry Something Went Wrong."
          },{
            type : "warning" 
        });
      } 
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    } 
  });
}

function changeUserAddress (elem,evt) {
  var address = $(".details-card .card-body .details-div .address").html();
  $("#change-address-form #address").html(address);
  $("#change-address-modal").modal({
    "show" : true
  })
}

function localGovernmentChanged (elem,evt) {
  elem = $(elem);
  var local_government_id = elem.val();
  $(".spinner-overlay").show();
  var url = "<?php echo site_url('meetglobal/get_center_leaders_in_local_govt') ?>";
  var form_data = {
    local_government_id : local_government_id
  };
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : form_data,
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success && response.messages != ""){
        var messages = response.messages;
        
        $(".center-leader-display").html(messages);
      }else{
        $.notify({
          message:"Sorry Something Went Wrong."
          },{
            type : "warning" 
        });
      } 
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    } 
  });

  
}

function modifyCart (elem,evt) {
  $("#cart-modal").modal("show");
  $("#shop").show();
  $("#checkout-container").hide()
}

function proceedToPayment(elem,evt,center_leader_user_id){

  elem = $(elem);
  console.log(center_leader_user_id)
  var url = "<?php echo site_url('meetglobal/get_final_sum_mini_importation') ?>";
  var form_data = {
    show_records : true
  };
  
  $(".spinner-overlay").show();
  
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : form_data,
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success && response.amount > 0){
        var amount = response.amount;
        swal({
          title: 'Proceed?',
          text: "You Are About To Be Debited Of <em class='text-primary'>₦ " + addCommas(amount) + "</em> Which Includes Cost Of Products Requested And Shipping Fees. Are You Sure You Want To Proceed?",
          type: 'success',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes Proceed!',
          cancelButtonText : "Cancel"
        }).then(function(){
          var url = "<?php echo site_url('meetglobal/checkout_cart_mini_importation') ?>";
          var form_data = {
            center_leader_user_id : center_leader_user_id
          };
          
          $(".spinner-overlay").show();
          
          $.ajax({
            url : url,
            type : "POST",
            responseType : "json",
            dataType : "json",
            data : form_data,
            success : function (response) {
              console.log(response)
              $(".spinner-overlay").hide();
              if(response.success){
                swal({
                  title: 'Success',
                  text: "Your Order Has Been Submitted Successfully And You Have Been Debited. Please Check The Orders Section To Find Out More Information About Requested Products.",
                  type: 'success',
                  confirmButtonColor: '#3085d6',
                  confirmButtonText: 'Ok'
                }).then(function(){
                  document.location.reload();
                });
              }else if(response.not_center_leader){
                swal({
                  title: 'Ooops',
                  text: "User Selected Is Not A Center Leader",
                  type: 'error'
                })
              }else if(response.not_enough_money){
                swal({
                  title: 'Ooops',
                  text: "You Do Not Have Enough Funds In Your Account. Please Credit Your Account And Try Again",
                  type: 'error'
                })
              }else{
                
                swal({
                  title: 'Ooops',
                  text: "Something Went Wrong",
                  type: 'error'
                })
              }
            },error : function () {
              $(".spinner-overlay").hide();
              swal({
                title: 'Ooops',
                text: "Something Went Wrong",
                type: 'error'
              })
            }
          });
        });
      }else{
        setTimeout(function () {
          swal({
            title: 'Ooops',
            text: "Sorry You Have Nothing In Your Cart. Select An Item To Proceed",
            type: 'error'
          })
        }, 2000);
      }
    },error : function () {
      $(".spinner-overlay").hide();
      swal({
        title: 'Ooops',
        text: "Something Went Wrong",
        type: 'error'
      })
    }
  });
}

function yourOrders (elem,evt) {
  evt.preventDefault();
  
  var url = "<?php echo site_url('meetglobal/get_your_orders_mini_importation') ?>";
  var form_data = {
    show_records : true
  };
  
  $(".spinner-overlay").show();
  
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : form_data,
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success){
        $("#choose-action-card").hide();
        $("#your-orders-card .card-body").html(response.messages);
        $("#your-orders-card #your-orders-table").DataTable({
          aLengthMenu: [
              [25, 50, 100, 200, -1],
              [25, 50, 100, 200, "All"]
          ],
          iDisplayLength: -1
        });
        $("#your-orders-card").show();
      }
    },error : function () {
      $(".spinner-overlay").hide();
      swal({
        title: 'Ooops',
        text: "Something Went Wrong",
        type: 'error'
      })
    }
  });
  
}

function goBackFromOrdersCard (elem,evt) {
  $("#choose-action-card").show();
  $("#your-orders-card").hide();
}

function loadOrderInfo (elem,evt,order_code) {
  console.log(order_code)
  var url = "<?php echo site_url('meetglobal/order_info_mini_importation') ?>";
  var form_data = {
    show_records : true,
    order_code : order_code
  };
  
  $(".spinner-overlay").show();
  
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : form_data,
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success && response.order_code != ""){
        $("#your-orders-card").hide();
        $("#order-info-card .card-title").html("Order: " + response.order_code);
        $("#order-info-card .card-body").html(response.messages);
        $("#order-info-card #orders-info-table").DataTable({
          aLengthMenu: [
              [25, 50, 100, 200, -1],
              [25, 50, 100, 200, "All"]
          ],
          iDisplayLength: -1
        });
        $("#order-info-card").show();
        
      }
    },error : function () {
      $(".spinner-overlay").hide();
      swal({
        title: 'Ooops',
        text: "Something Went Wrong",
        type: 'error'
      })
    }
  });
}

function goBackFromOrderInfoCard (elem,evt) {
  $("#order-info-card").hide();
  $("#your-orders-card").show();
}

function getRefundInfo (elem,evt) {
  window.location.assign("<?php echo site_url('meetglobal/mini_importation_refunds'); ?>")
}


function accessDispatcherFunctions (elem,evt) {
  evt.preventDefault();
  swal({
    title: 'Choose Action',
    text: "Do You Want To View: ",
    type: 'question',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'New Requests',
    cancelButtonText : "Previously Accepted Requests"
  }).then(function(){
    console.log('Loading New Requests');
    
    var url = "<?php echo site_url('meetglobal/get_dispatcher_new_requests') ?>";
    var form_data = {
      show_records : true
    };
    
    $(".spinner-overlay").show();
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : form_data,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success){
          
          $("#choose-action-card").hide();
          
          $("#new-requests-dispatcher-card .card-body").html(response.messages);
          $("#new-requests-dispatcher-card #new-requests-dispatcher-table").DataTable({
            aLengthMenu: [
                [25, 50, 100, 200, -1],
                [25, 50, 100, 200, "All"]
            ],
            iDisplayLength: -1
          });
          $("#new-requests-dispatcher-card").show();
          
        }
      },error : function () {
        $(".spinner-overlay").hide();
        swal({
          title: 'Ooops',
          text: "Something Went Wrong",
          type: 'error'
        })
      }
    });
  },function(dismiss){
    if(dismiss == 'cancel'){
      var url = "<?php echo site_url('meetglobal/get_dispatcher_previous_requests') ?>";
      var form_data = {
        show_records : true
      };
      
      $(".spinner-overlay").show();
      
      $.ajax({
        url : url,
        type : "POST",
        responseType : "json",
        dataType : "json",
        data : form_data,
        success : function (response) {
          console.log(response)
          $(".spinner-overlay").hide();
          if(response.success){
            
            $("#choose-action-card").hide();
            
            $("#previous-requests-dispatcher-card .card-body").html(response.messages);
            $("#previous-requests-dispatcher-card #previous-requests-dispatcher-table").DataTable({
              aLengthMenu: [
                  [25, 50, 100, 200, -1],
                  [25, 50, 100, 200, "All"]
              ],
              iDisplayLength: -1
            });
            $("#previous-requests-dispatcher-card").show();
            
          }
        },error : function () {
          $(".spinner-overlay").hide();
          swal({
            title: 'Ooops',
            text: "Something Went Wrong",
            type: 'error'
          })
        }
      });
    }
  });
}

function goBackNewRequetsDispatcherCard (elem,evt) {
  $("#choose-action-card").show();
          
  $("#new-requests-dispatcher-card").hide();
}
function loadCenterLeaderProductInfo(elem,evt){
  elem = $(elem);
  var product_id = elem.attr("data-product-id");
  var center_leader_id = elem.attr("data-center-leader");
  swal({
    title: 'Confirm?',
    text: "Are You Sure You Accept To Deliver This Package? <p><em class='text-primary'>Note: This Request Expires 3hrs After Request Was Made.</em></p>",
    type: 'question',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes Proceed! ',
    cancelButtonText : "No"
  }).then(function(){
    var url = "<?php echo site_url('meetglobal/accept_dispatcher_request') ?>";
    var form_data = {
      product_id : product_id,
      center_leader : center_leader_id
    };
    
    $(".spinner-overlay").show();
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : form_data,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success){
          $.notify({
          message:"You Have Successfully Accepted To Deliver This Product To The Center Leader"
          },{
            type : "success"  
          });
          setTimeout(function () {
            document.location.reload();
          }, 1000)
        }else{
          swal({
            title: 'Ooops',
            text: "Something Went Wrong",
            type: 'error'
          })
        }
      },error : function () {
        $(".spinner-overlay").hide();
        swal({
          title: 'Ooops',
          text: "Something Went Wrong",
          type: 'error'
        })
      }
    });
  });
}

function loadCenterLeaderProductInfoPrevious(elem,evt){
  elem = $(elem);
  var product_id = elem.attr("data-product-id");
  var center_leader_id = elem.attr("data-center-leader");
  console.log(product_id + " : " + center_leader_id)
  $(".spinner-overlay").show();
  var url = "<?php echo site_url('meetglobal/get_products_on_way_to_center_leader_info_previous_requests') ?>";
  var form_data = {
    show_records : true,
    product_id : product_id,
    center_leader_id : center_leader_id
  }

  $.ajax({
    url : url,
    type : "POST",
    dataType : "json",
    responseType: "json",
    data : form_data,
    success : function (response) {
      $(".spinner-overlay").hide();
      console.log(response);
      if(response.success){
        var messages = response.messages;
        $("#previous-requests-dispatcher-info-card .card-body").html(messages);
        $("#previous-requests-dispatcher-info-card #statuses-table").DataTable({
          aLengthMenu: [
              [25, 50, 100, 200, -1],
              [25, 50, 100, 200, "All"]
          ],
          iDisplayLength: -1
        });
        
        $("#previous-requests-dispatcher-info-card").show();
        $("#mark-product-as-received-by-center-leader-btn").attr("data-product-id",product_id);
        $("#mark-product-as-received-by-center-leader-btn").attr("data-center-leader",center_leader_id);

        
        $("#mark-product-as-received-by-center-leader-btn").show("fast");
        
        $("#previous-requests-dispatcher-card").hide();
      }
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    } 
  }); 
}

function markProductAsReceivedByCenterLeader (elem,evt) {
  elem = $(elem);
  var product_id = elem.attr("data-product-id");
  var center_leader_id = elem.attr("data-center-leader");
  console.log(product_id)
  console.log(center_leader_id)
  swal({
    title: 'Warning',
    text: "Are You Sure You Want To Mark Product As Delivered To Center Leader? ",
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes Please! ',
    cancelButtonText : "No"
  }).then(function(){
    $(".spinner-overlay").show();
    var url = "<?php echo site_url('meetglobal/mark_mini_importation_product_of_center_leader_as_recieved_by_center_leader') ?>";
    var form_data = {
      product_id : product_id,
      center_leader : center_leader_id
    }

    $.ajax({
      url : url,
      type : "POST",
      dataType : "json",
      responseType: "json",
      data : form_data,
      success : function (response) {
        $(".spinner-overlay").hide();
        console.log(response);
        if(response.success){
          $.notify({
            message:"Successfully Marked Product As Delivered To Center Leader."
            },{
              type : "success" 
          });

          setTimeout(function () {
            document.location.reload();
          },1500);
        }else{
          $.notify({
            message:"Sorry Something Went Wrong."
            },{
              type : "warning" 
          });
        }
      },error : function () {
        $(".spinner-overlay").hide();
        $.notify({
          message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
          },{
            type : "danger" 
        });
      } 
    }); 
  });
}

function goBackPreviousRequetsDispatcherInfoCard (elem,evt) {
  $("#previous-requests-dispatcher-info-card").hide();
  $("#mark-product-as-received-by-center-leader-btn").hide("fast");
  $("#previous-requests-dispatcher-card").show();
}

function ordersAwaitingApproval (elem,evt) {
  evt.preventDefault();
  $(".spinner-overlay").show();
  var url = "<?php echo site_url('meetglobal/view_orders_awaiting_approval_on_center_leaders_page_mini_importation') ?>";
  var form_data = {
    show_records : true
  }

  $.ajax({
    url : url,
    type : "POST",
    dataType : "json",
    responseType: "json",
    data : form_data,
    success : function (response) {
      $(".spinner-overlay").hide();
      console.log(response);
      if(response.success){
        var messages = response.messages;
        $("#orders-awaiting-approval-card .card-body").html(messages);
        $("#orders-awaiting-approval-table").DataTable({
          aLengthMenu: [
              [25, 50, 100, 200, -1],
              [25, 50, 100, 200, "All"]
          ],
          iDisplayLength: -1
        });
        $("#orders-awaiting-approval-card").show();
        $("#choose-action-center-leader-requests-card").hide();
      }
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    } 
  }); 
}

function goBackOrdersAwaitingApprovalCard (elem,evt) {
  $("#orders-awaiting-approval-card").hide();
  $("#choose-action-center-leader-requests-card").show();
}

function acceptOrderAwaitingCenterLeaderApproval(elem,evt){
  elem = $(elem);
  var product_id = elem.attr("data-product-id");
  var center_leader_id = elem.attr("data-center-leader");
  swal({
    title: 'Confirm?',
    text: "Dou You Accept That This Package Was Delivered You?",
    type: 'question',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes I Do! ',
    cancelButtonText : "No"
  }).then(function(){
    var url = "<?php echo site_url('meetglobal/accept_that_center_leader_has_received_package') ?>";
    var form_data = {
      product_id : product_id,
      center_leader : center_leader_id
    };
    
    $(".spinner-overlay").show();
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : form_data,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success){
          $.notify({
          message:"You Have Successfully Accepted Delivery Of This Product To You"
          },{
            type : "success"  
          });
          setTimeout(function () {
            document.location.reload();
          }, 2000)
        }else{
          swal({
            title: 'Ooops',
            text: "Something Went Wrong",
            type: 'error'
          })
        }
      },error : function () {
        $(".spinner-overlay").hide();
        swal({
          title: 'Ooops',
          text: "Something Went Wrong",
          type: 'error'
        })
      }
    });
  });
}

function ordersWithApproval (elem,evt) {
  evt.preventDefault();
  $(".spinner-overlay").show();
  var url = "<?php echo site_url('meetglobal/view_orders_with_your_approval_on_center_leaders_page_mini_importation') ?>";
  var form_data = {
    show_records : true
  }

  $.ajax({
    url : url,
    type : "POST",
    dataType : "json",
    responseType: "json",
    data : form_data,
    success : function (response) {
      $(".spinner-overlay").hide();
      console.log(response);
      if(response.success){
        var messages = response.messages;
        $("#orders-with-your-approval-card .card-body").html(messages);
        $("#orders-with-your-approval-table").DataTable({
          aLengthMenu: [
              [25, 50, 100, 200, -1],
              [25, 50, 100, 200, "All"]
          ],
          iDisplayLength: -1
        });
        $("#orders-with-your-approval-card").show();
        $("#choose-action-center-leader-requests-card").hide();
      }
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    } 
  }); 
}

function goBackOrdersAwaitingApprovalCard (elem,evt) {
  $("#orders-with-your-approval-card").hide();
  $("#choose-action-center-leader-requests-card").show();
}

function viewUsersWhoHaveShareInThisOrder(elem,evt){
  elem = $(elem);
  var product_id = elem.attr("data-product-id");
  var center_leader_id = elem.attr("data-center-leader");
  
  var url = "<?php echo site_url('meetglobal/view_users_who_have_share_in_this_order_center_leader') ?>";
  var form_data = {
    show_records : true,
    product_id : product_id,
    center_leader : center_leader_id
  };
  
  $(".spinner-overlay").show();
  
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : form_data,
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success && response.messages != ""){
        var messages = response.messages;
        $("#orders-with-your-approval-card").hide();
        $("#users-who-have-share-in-this-order-card .card-body").html(messages);
        $("#users-who-have-share-in-this-order-card #users-who-have-share-in-this-order-table").DataTable({
          aLengthMenu: [
              [25, 50, 100, 200, -1],
              [25, 50, 100, 200, "All"]
          ],
          iDisplayLength: -1
        });
        $("#users-who-have-share-in-this-order-card").show();
      }else{
        swal({
          title: 'Ooops',
          text: "Something Went Wrong",
          type: 'error'
        })
      }
    },error : function () {
      $(".spinner-overlay").hide();
      swal({
        title: 'Ooops',
        text: "Something Went Wrong",
        type: 'error'
      })
    }
  });
  
}

function goBackUsersWhoHaveShareInThisOrderCard (elem,evt) {
  $("#orders-with-your-approval-card").show();
  
  $("#users-who-have-share-in-this-order-card").hide();
}

function markThisProductAsDelivered(elem,evt,id){
  elem = $(elem);
  
  swal({
    title: 'Confirm?',
    text: "Are You Sure You Want To Mark This Order As Delivered To User? ",
    type: 'question',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes I Do! ',
    cancelButtonText : "No"
  }).then(function(){
    var url = "<?php echo site_url('meetglobal/mark_mini_importatio_order_as_delivered_to_final_user') ?>";
    var form_data = {
      order_id : id,
    };
    
    $(".spinner-overlay").show();
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : form_data,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success){
          $.notify({
          message:"You Have Successfully Marked This Order As Delivered To The Final User"
          },{
            type : "success"  
          });
          setTimeout(function () {
            document.location.reload();
          }, 1000)
        }else{
          swal({
            title: 'Ooops',
            text: "Something Went Wrong",
            type: 'error'
          })
        }
      },error : function () {
        $(".spinner-overlay").hide();
        swal({
          title: 'Ooops',
          text: "Something Went Wrong",
          type: 'error'
        })
      }
    });
  });
}

function loadNotExpiredError(elem,evt){
  elem = $(elem);
  var expiry_days = elem.attr("data-expiry-days");
  swal({
    title: 'Error',
    text: "This Product Has Not Expired Yet. It Will Expire In <em class='text-primary'>"+ expiry_days + " day(s)</em>. Shipping Can Only Start When It Expires And Exceeds 50 % Slots Taken Else Your Funds Will Be Refunded.",
    type: 'error',                                          
  })
}

function loadMoreInfoOnProductInOrder(elem,evt,id){
  var url = "<?php echo site_url('meetglobal/load_more_info_on_product_in_mini_importation_order') ?>";
  var form_data = {
    order_id : id,
    show_records : true
  };
  
  $(".spinner-overlay").show();
  
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : form_data,
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success && response.messages != ""){
        var messages = response.messages;
        $("#more-info-on-product-order-card .card-body").html(messages);
        $("#more-info-on-product-order-card #statuses-table").DataTable({
          aLengthMenu: [
              [25, 50, 100, 200, -1],
              [25, 50, 100, 200, "All"]
          ],
          iDisplayLength: -1
        });
        $("#more-info-on-product-order-card ").show();
        $("#order-info-card").hide();
      }else{
        swal({
          title: 'Ooops',
          text: "Something Went Wrong",
          type: 'error'
        })
      }
    },error : function () {
      $(".spinner-overlay").hide();
      swal({
        title: 'Ooops',
        text: "Something Went Wrong",
        type: 'error'
      })
    }
  });
}

function goBackMoreInfoOnProductOrderCard (elem,evt) {
  $("#more-info-on-product-order-card ").hide();
  $("#order-info-card").show();
}

function becomeMerchant (elem,evt) {
  
    var url = "<?php echo site_url('meetglobal/get_if_user_is_valid_to_be_merchant') ?>";
    var form_data = {
      show_records : true
    };
    
    $(".spinner-overlay").show();
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : form_data,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success){
          swal({
            title: 'Choose Action: ',
            text: "Do You Want To? ",
            type: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#4caf50',
            confirmButtonText: 'Upload New Product',
            cancelButtonText : "View Previous Requests"
          }).then(function(){
            $("#add-new-product-card").show();
            $("#choose-action-card").hide();
           },function(dismiss){
            if(dismiss == 'cancel'){
              swal({
                title: 'Choose Action: ',
                text: "Do You Want To View: ",
                type: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#4caf50',
                confirmButtonText: 'Approved Requests',
                cancelButtonText : "Disapproved Requests"
              }).then(function(){

              },function(dismiss){
                if(dismiss == 'cancel'){
                  var url = "<?php echo site_url('meetglobal/view_dispaproved_merchant_requests') ?>";
                  var form_data = {
                    show_records : true
                  };
                  
                  $(".spinner-overlay").show();
                  
                  $.ajax({
                    url : url,
                    type : "POST",
                    responseType : "json",
                    dataType : "json",
                    data : form_data,
                    success : function (response) {
                      console.log(response)
                      $(".spinner-overlay").hide();
                      if(response.success && response.messages != ""){
                        var messages = response.messages;
                        $("#disapproved-merchant-requests-card .card-body").html(messages);
                        $("#disapproved-merchant-requests-card #disapproved-merchant-requests-table").DataTable({
                          aLengthMenu: [
                              [25, 50, 100, 200, -1],
                              [25, 50, 100, 200, "All"]
                          ],
                          iDisplayLength: -1
                        });
                        $("#disapproved-merchant-requests-card").show();
                        $("#choose-action-card").hide();
                      }else{
                        $.notify({
                          message:"Sorry Something Went Wrong."
                          },{
                            type : "warning" 
                        });
                      }
                    },error : function () {
                      $(".spinner-overlay").hide();
                      $.notify({
                        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
                        },{
                          type : "danger" 
                      });
                    } 
                  }); 
                }
              });
            }    
          }); 
        }else if(!response.has_business_account){ 
          swal({
            title: 'Error',
            text: "Sorry You Need To Have At Least One Business Mlm Account To Become A Merchant.",
            type: 'error',                                          
          })
        }else{
          swal({
            title: 'Ooops',
            text: "Something Went Wrong",
            type: 'error'
          })
        }
      },error : function () {
        $(".spinner-overlay").hide();
        $.notify({
          message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
          },{
            type : "danger" 
        });
      } 
    }); 
  
}

function loadDisapprovedMerchantRequestInfo (elem,evt,id) {
  var url = "<?php echo site_url('meetglobal/view_dispaproved_merchant_request_info') ?>";
  var form_data = {
    show_records : true,
    id : id
  };
  
  $(".spinner-overlay").show();
  
  $.ajax({
    url : url,
    type : "POST",
    responseType : "json",
    dataType : "json",
    data : form_data,
    success : function (response) {
      console.log(response)
      $(".spinner-overlay").hide();
      if(response.success && response.messages != ""){
        var messages = response.messages;
        $("#disapproved-merchant-requests-card .card-body").html(messages);
        $("#disapproved-merchant-requests-card #disapproved-merchant-requests-table").DataTable({
          aLengthMenu: [
              [25, 50, 100, 200, -1],
              [25, 50, 100, 200, "All"]
          ],
          iDisplayLength: -1
        });
        $("#disapproved-merchant-requests-card").show();
        $("#choose-action-card").hide();
      }else{
        $.notify({
          message:"Sorry Something Went Wrong."
          },{
            type : "warning" 
        });
      }
    },error : function () {
      $(".spinner-overlay").hide();
      $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
        },{
          type : "danger" 
      });
    } 
  }); 
}

function goBackDisapprovedRequestsCard (elem,evt) {
  
  $("#disapproved-merchant-requests-card").hide();
  $("#choose-action-card").show();
}

function goBackFromAddNewProductCard (elem,evt) {
  $("#add-new-product-card").hide();
  $("#choose-action-card").show();
}


function submitNewproductMerchant (elem,evt) {
  evt.preventDefault();
  swal({
    title: 'Confirmation Message',
    text: "Are You Sure You Want To Submit Your Product?",
    type: 'question',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#4caf50',
    confirmButtonText: 'Yes Proceed!',
    cancelButtonText : "No"
  }).then(function(){
    var me = $(elem);
    
    var file_input = elem.querySelector("#image");
    var form_info = me.serializeArray();
    console.log(form_info)
    var url = me.attr("action");
    

    var files = file_input.files;
    console.log(files)
    var form_data = new FormData();
    var error = '';
    
    for(var i = 0; i < form_info.length; i++){
      form_data.append(form_info[i].name,form_info[i].value);
    }
    form_data.append("image",files[0]);
    console.log(form_data)
        
    $(".spinner-overlay").show();
    $.ajax({
      url : url,
      type : "POST",
      cache: false,
      dataType : "json",
      contentType: false,
      processData: false,
      data : form_data,
      success : function (response) {
        $(".spinner-overlay").hide();
        console.log(response)
        if(response.wrong_extension){
          $.notify({
            message:"The File Uploaded Is Not A Valid Image Format"
            },{
              type : "warning"  
          });
        }else if(response.too_large){
          $.notify({
            message:"The File Upladed Is Too Large Max Is 200 KB"
            },{
              type : "warning"  
          });
        }else if(response.not_really_json){
          $.notify({
            message:"This File Format Is Not Really An Image File"
            },{
              type : "warning"  
          });
        }else if(response.success && response.image_name != ""){
          $.notify({
          message:"Product Uploaded Successfully"
          },{
            type : "success"  
          });
          setTimeout(function () {
            document.location.reload()
          }, 2000);
        }else{
          me.find(".form-error").html("");
          $.each(response.messages, function (key,value) {

          var element = me.find("#"+key);
          
          element.closest('div.form-group')
                  
                  .find('.form-error').remove();
          element.after(value);
          
         });
          $.notify({
          message:"Some Values Where Not Valid. Please Enter Valid Values"
          },{
            type : "warning"  
          });
        }
      },error : function () {
        $(".spinner-overlay").hide();
        $.notify({
          message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
          },{
            type : "danger" 
        });
      }
    });
  });  
}
</script>

<style>
  tr{
    cursor: pointer;
  }

  #shop .owl-carousel img{
    max-height: 340px;
  }

  .product-card{
    margin: 15px;
    padding: 15px;
    cursor: pointer;
  }

  .product-card .card-body{
    padding: 0;
  }

  .product-card .card-body .product-img{
    height: 170px; 
    width: 170px;
  }

  .product-card .card-body .product-info h3{
    font-size: 16px;
    text-transform: capitalize;
    font-weight: 600;
  }

  .product-card .card-body .product-info .product-price-div{
    padding-top: 7px;
    border-top: 1px solid rgb(242, 242, 242);
    padding-bottom : 7px;
    border-bottom: 1px solid rgb(242, 242, 242);
  }

  .product-card .card-body .product-info .product-real-price{
    font-size: 20px;
    
    font-weight: 700;
  }

  .product-card .card-body .product-info .product-fake-price{
    font-size: 14px;
    text-decoration: line-through;
    font-weight: 400;
    float: right;
  }

  .btn-orange{
    background-color: rgb(0,0,0,0);
    border: 1px solid #FF9900;
    color: #FF9900;
    border-radius: 3px;
    padding: 8px;
    font-size: 14px;
    font-weight: 600;
    margin-top: 20px;
    display: block;
    width: 100%;
    text-transform: none;
    transition-delay: 0s;
    transition-duration: 0.3s;
    transition-property: all;
    transition-timing-function: ease-in-out;
    cursor: pointer;
  }

  .order-summary-card, .order-summary-card .card-body{
    padding: 0;
  }

  .order-summary-card .heading{
    padding: 10px 8px 10px 8px;
  }

  .order-summary-card .heading span{
    font-size:  14px;
    color: #000;
    font-weight: bold;
  }

  .order-summary-card .products-div{
    border-top: 1px solid #f0f0f0;
    height: 200px;
    overflow-y: auto;
  }

  .order-summary-card .products-div .product-row{
    min-height: 90px;
    padding: 6px 8px 6px 8px;
    border-bottom: 1px solid #f0f0f0;
    /*border-top: 1px solid #f0f0f0;*/
  }

  .order-summary-card .products-div .product-row:last-child{
    border-top: 0;
    border-bottom: 1px solid #f0f0f0;;
  }

  .order-summary-card .products-div .product-row:first-child{
    border-bottom: 1px solid #f0f0f0;
    border-top: 0;
  }

  .order-summary-card .products-div .product-row .product-name{
    display: block;
    margin-top: 6px;
    font-size: 13px;
    text-transform: capitalize;
  }

  .order-summary-card .products-div .product-row .sub-total-price{
    display: block;
    margin-top: 6px;
    font-size: 13px;
    text-transform: capitalize;
  }

  .order-summary-card .products-div .product-row .sub-total-price{
    display: block;
    margin-top: 6px;
    font-size: 13px;
    text-transform: capitalize;
  }

  .order-summary-card .total-div{
    padding: 0 8px 0 8px;
    margin-top: 16px;
  }

  .order-summary-card  .total-div .sub-total-label {

  }

  .order-summary-card .total-div .sub-total-val {
    float: right;
  }

  .order-summary-card  .total-div .shipping-label {

  }

  .order-summary-card .total-div .shipping-val {
    float: right;
  }

  .order-summary-card .total-div .service-charge-val {
    float: right;
  }


  .order-summary-card  .total-div .total-label {
    font-weight: bold;
  }

  .order-summary-card .total-div .total-val {
    float: right;
    font-weight: bold;
    font-size: 17px;
  }

  .details-card .heading{
    padding: 10px 8px 10px 8px;
  }

  .details-card .heading span{
    font-size:  14px;
    color: #000;
    font-weight: bold;
  }

  .details-card .card-body{
    padding: 0;
  }

  .details-card .card-body .change-personal-details{
    text-transform: uppercase;
    float: right;
    cursor: pointer;
  }

  .details-card .card-body .details-div{
    padding: 16px 46px 16px 46px;
    border-top: 1px solid #f0f0f0;
  }
  

  .details-card .card-body .details-div .name{
    font-size: 14px;
    font-weight: bold;
    display: block;
  }

  .details-card .card-body .details-div .address{
    font-size: 13px;
    color: gray;
    display: block;
  }

  .details-card .card-body .details-div .phone{
    font-size: 13px;
    color: gray;
    display: block;
  }

  .center-leader-card .heading{
    padding: 10px 8px 10px 8px;
  }

  .center-leader-card .heading span{
    font-size:  14px;
    color: #000;
    font-weight: bold;
  }

  .center-leader-card .card-body{
    padding: 0;
  }

  .center-leader-card .card-body .body{
    border-top: 1px solid #f0f0f0;
    padding: 20px;
  }

  .center-leader-card .card-body .body .country-label{
    font-weight: bold;
  }

  .center-leader-card .card-body .body .country-val{
    
  }
  .center-leader-card .card-body .body .center-leader-display .heading-text{
    font-size: 23px;
    font-weight: bold;
    margin-top: 25px;
    display: block;
  }

  .center-leader-card .card-body .body .center-leaders{
    max-height: 300px;
    overflow-y: auto;
  }

  .center-leader-card .card-body .body .center-leaders .name{
    font-size: 15px;
    font-weight: bold;
    text-transform: capitalize;
    display: block;
  }

</style>
<?php
  $user_state_id = $state_id;
?>
<div class="spinner-overlay" style="display: none;">
  <div class="spinner-well">
    <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading...">
  </div>
</div>
<div class="content">
  <div class="container-fluid">
    <h2 class="text-center sub-head" style="">Mini Importation</h2>

    <section id="checkout-container" class="container" style="display: none;">
      <div class="row">
        <div class="col-sm-3">
          <div class="card col-12 order-summary-card" style="height: fit-content;">
            <div class="card-body" style="">
              <div class="heading text-center">
                <span>YOUR ORDER(2 items)</span>
              </div>

              <div class="products-div">
                <div class="container" id="products-div-container">
                  
                                    
                </div>
              </div>

              <div class="total-div">
                <div class="" style="padding-bottom: 8px;">
                  <span class="sub-total-label">Subtotal</span>
                  <span class="sub-total-val">₦ 80,900</span>
                </div>
                
                <div class="" style="padding-bottom: 8px;">
                  <span class="shipping-label">Shipping Amount</span>
                  <span class="shipping-val">₦ 1,180</span>
                </div>

                <div class="" style="padding-bottom: 8px;">
                  <span class="service-charge-label">Service Charge(5%)</span>
                  <span class="service-charge-val">₦ 1,180</span>
                </div>

                <div class="" style="padding-top: 10px; border-top: 1px solid #f0f0f0; margin-bottom: 10px;">
                  <span class="total-label">Total</span>
                  <span class="total-val text-warning">₦ 82,080</span>
                </div>
              </div>
            </div>
          </div>
            
          <div class="text-center">
            <button class="btn btn-warning btn-round" onclick="modifyCart(this,event)"><i class="fas fa-shopping-cart" style="color: #fff; font-size: 15px;"></i>Modify Cart</button>
          </div>
        </div>
        


        <div class="offset-sm-1">
          
        </div>
        
        <div class="col-sm-8" style="height: fit-content; padding: 0;">
          <div class="card details-card" style="padding: 0;">
            <div class="card-body" style="">
              <div class="heading">
                <span>1. PERSONAL DETAILS</span>
                <span class="change-personal-details text-warning" onclick="changeUserAddress(this,event)"><i class="far fa-edit"></i> CHANGE</span>
              </div>
              <div class="details-div">
                <span class="name">David Nwogo</span>
                <span class="address">3, funsho obikoya street, ikotun,lagos, IKOTUN, Lagos</span>
                <span class="phone">+2348127027321</span>
              </div>
            </div>
          </div>

          

          <div class="card center-leader-card" style="padding: 0;">
            <div class="card-body" style="">
              <div class="heading">
                <span>2. CHOOSE CENTER LEADER</span>
              </div>

              <div class="body">

                <span class="country-label">Country: </span>
                <span class="country-val">Nigeria</span>

                <div class="form-row">
                  <div class="form-group col-sm-6">
                    <label for="state" style="font-weight: bold;">Select State: </label>
                    <select name="state" id="state" class="form-control my-select" data-style="btn btn-primary btn-round"  data-size="7" onchange="stateChanged1(this,event)">
                      <?php
                        $first_regions = $this->meetglobal_model->getFirstRegionsByCountryId($country_id);
                        if(is_array($first_regions)){ 
                          foreach($first_regions as $region){
                            $region_name = $region->name;
                            $country_id = $region->country_id;
                            $region_id = $region->id;
                      ?>
                      <option style="text-transform: capitalize;" value="<?php echo $region_id ?>"><?php echo $region_name; ?></option>
                      <?php
                          }
                        }
                      ?>
                    </select>
                    <span class="form-error"></span>
                  </div>

                  <div class="form-group col-sm-6">
                    <label for="local_government" style="font-weight: bold;">Local Government: </label>
                    <select name="local_government" id="local_government" class="form-control my-select" data-style="btn btn-primary btn-round"  data-size="7" onchange="localGovernmentChanged(this,event)">
                      <?php
                        
                        $first_locals = $this->meetglobal_model->getFirstLocalGovernments();
                        
                        if(is_array($first_locals)){ 
                          foreach($first_locals as $row){
                            $id = $row->id;
                            $state_id = $row->state_id;
                            $name = $row->name;
                      ?>
                      <option style="text-transform: capitalize;"  value="<?php echo $id ?>"><?php echo $name; ?></option>
                      <?php
                          }
                        }
                      ?>
                    </select>
                    <span class="form-error"></span>
                  </div>
                </div>
                
                <div class="center-leader-display">
                  <?php
                    $response_arr = array('messages' => '');
                    $local_government_id = $this->meetglobal_model->getFirstLocalGovtIdOfState(1);
                    $center_leaders = $this->meetglobal_model->getCenterLeadersInLocalGovt($local_government_id);
                    if(is_array($center_leaders)){
                    $response_arr['messages'] .= '<div class="text-center">';
                    $response_arr['messages'] .= '<span class="text-center heading-text">'.count($center_leaders).' CENTER LEADER(S) FOUND</span>';
                    $response_arr['messages'] .= '<span class="text-secondary" style="font-weight: bold;">Please Select Center Leader To Proceed</span>';
                    $response_arr['messages'] .= '</div>';

                    $response_arr['messages'] .= '<div class="center-leaders" style="border: 0;">';
                    foreach($center_leaders as $row){
                      $center_leader_user_id = $row->id;
                      $center_leader_logo = $row->logo;
                      $center_leader_full_name = $row->full_name;
                      $center_leader_user_name = $row->user_name;
                      $center_leader_town = $row->city;
                      $center_leader_address = $row->address;
                      $center_leader_phone_code = $row->phone_code;
                      $center_leader_phone_number = $row->phone;

                      $center_leader_slug = url_title($center_leader_user_name);

                      if(is_null($center_leader_logo)){
                        $center_leader_logo = 'avatar.jpg';
                      }

                  

                      $response_arr['messages'] .= '<div class="card" style="padding-top: 10px; padding-bottom: 10px; ">';
                      $response_arr['messages'] .= '<div class="card-body">';

                      $response_arr['messages'] .= '<div class="row" style="width: 100%;">';
                      $response_arr['messages'] .= '<div class="col-3">';
                      $response_arr['messages'] .= '<img style="width: 100px;" src="'.base_url('assets/images/'.$center_leader_logo).'" class="col-12 img-round" alt="">';
                      $response_arr['messages'] .= '</div>';

                      $response_arr['messages'] .= '<div class="col-9">';
                      $response_arr['messages'] .= '<span class="name"><a href="'.site_url('meetglobal/'.$center_leader_slug).'" target="_blank">'.$center_leader_full_name.'</a></span>';
                      $response_arr['messages'] .= '<div class="">';
                      $response_arr['messages'] .= '<span class="town-label" style="font-weight: bold;">Town: </span>';
                      $response_arr['messages'] .= '<span class="town-val" >'.$center_leader_town.'</span>';
                      $response_arr['messages'] .= '</div>';
                      $response_arr['messages'] .= '<div class="">';
                      $response_arr['messages'] .= '<span class="address-label" style="font-weight: bold;">Address: </span>';
                      $response_arr['messages'] .= '<span class="address-val">'.$center_leader_address.'</span>';
                      $response_arr['messages'] .= '</div>';
                      $response_arr['messages'] .= '<div class="">';
                      $response_arr['messages'] .= '<span class="phone-label" style="font-weight: bold;">Phone: </span>';
                      $response_arr['messages'] .= '<span class="phone-val">+'.$center_leader_phone_code. '' .$center_leader_phone_number.'</span>';
                      $response_arr['messages'] .= '</div>';
                      $response_arr['messages'] .= '<button onclick="proceedToPayment(this,event,'.$center_leader_user_id.')" class="btn btn-success btn-round">';
                      $response_arr['messages'] .= '<i class="fas fa-hand-pointer" style="color: #fff;"></i> Select';
                      $response_arr['messages'] .= '</button>';
                      $response_arr['messages'] .= '</div>';
                      $response_arr['messages'] .= '</div>';

                      $response_arr['messages'] .= '</div>';
                      $response_arr['messages'] .= '</div>';
                    }
                    $response_arr['messages'] .= '</div>';
                  }else{
                    $response_arr['messages'] .= '<h4 class="text-warning">No Center Leaders In This Location.</h4>';
                  }
                    echo $response_arr['messages'];
                    $response_arr = array();
                  ?>
                </div>

              </div>
              
              
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <div class="card" id="product-info-card" style="display: none;">
      <div class="card-header">
        <button class="btn btn-warning btn-round" onclick="goBackFromProductInfoCard(this,event)">Go Back</button>
      </div>
      <div class="card-body" style="padding: 20px;">
        
      </div>
    </div>




    <section id="shop" style="display: none;">
      <div class="owl-carousel owl-theme">
        <?php 
          $banners = $this->meetglobal_model->getMiniImportationBanners();
          if(is_array($banners)){
            foreach($banners as $row){
              $id = $row->id;
              $product_id = $row->id;
              $image = $row->image;
              $date = $row->date;
              $time = $row->time;

        ?>
        <div class="item" data-merge="6"><img src="<?php echo base_url('assets/images/'.$image); ?>" alt=""></div>
      <?php } } ?>
      
      </div>
      <div class="container">
        <?php 
        $products = $this->meetglobal_model->getLiveMiniImportationProducts();
        if(is_array($products)){
          $products = array_values(array_reverse($products));
        ?>
        <div class="row" style="margin-top: 50px;">
        <?php
          foreach($products as $row){
            $date = date("j M Y");
            $time = date("h:i:sa");
            $curr_date = $date . " " . $time;
            $id = $row->id;
            $name = $row->name;
            $image = $row->image;
            $quantity = $row->quantity;
            $old_price = $row->old_price;
            $new_price = $row->new_price;
            $quantity_purchased = $row->quantity_purchased;
            $expiry_date = $row->expiry_date;
            $expiry_time = $row->expiry_time;
            $upload_date = $row->upload_date;
            $upload_time = $row->upload_time;
            $progress_percent = ($quantity_purchased / $quantity) * 100;
            $now = time(); // or your date as well
            $your_date = strtotime($expiry_date);
            $datediff = $your_date - $now;

            $datediff = ceil($datediff / (60 * 60 * 24));
          ?>
          <div class="card product-card col-sm-3" data-id="<?php echo $id; ?>">
            <div class="card-body">
              <div class="text-center">
                <img class="mx-auto product-img" src="<?php echo base_url('assets/images/'.$image) ?>" alt="<?php echo $name; ?>">
              </div>

              <div class="product-info">
                <h3 class="text-center"><?php echo $this->meetglobal_model->custom_echo($name,70); ?></h3>
                <div class="progress" style="margin: 3px;">
                  <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="<?php echo $progress_percent; ?>"
                  aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $progress_percent; ?>%">
                    <span class="sr-only"><?php echo $progress_percent; ?>% Complete</span>
                  </div>
                </div>
                <span><?php echo $quantity_purchased; ?></span>
                <span style="float: right;" class="text-right"><?php echo $quantity; ?></span>
                <div class="product-price-div">
                  <span class="product-real-price">₦<?php echo number_format($new_price,2); ?></span>
                  <span class="product-fake-price text-right">₦<?php echo number_format($old_price,2); ?></span>
                  <h5 style="font-weight: bold; font-size: 12px;" class="text-warning">This Product Will Expire In <?php echo $datediff ?> days</h5>
                </div>
              </div>

              <button class="btn-orange add-to-cart-btn" onclick="addToCart(this,event)" data-id="<?php echo $id; ?>">Add To Cart</button>

            </div>
          </div>
        <?php } ?>  

        </div>
        <?php } ?>
      </div>

    </section>

    <section id="services">

      <div class="card" id="disapproved-merchant-requests-card" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackDisapprovedRequestsCard(this,event)">Go Back</button>
          <h3 class="card-title"></h3>
        </div>
        <div class="card-body">
          
        </div>
      </div>

      <div class="card" id="add-new-product-card" style="display: none;">
        <div class="card-header">
          <button onclick="goBackFromAddNewProductCard(this,event)" class="btn btn-warning btn-round">Go Back</button>
          <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Merchant Product Upload</h3>
          <p class="text-primary">Product Would Have To Be Approved By Admin.</p>
        </div>
        <div class="card-body">
          <?php
            $attr = array('id' => 'add-new-product-form','onsubmit' => 'submitNewproductMerchant(this,event)');
           echo form_open_multipart('meetglobal/submit_add_new_product_for_merchant_form',$attr);
          ?>
          
            <div class="form-group">
              <label for="name">Enter Product Name: </label>
              <input type="text" name="name" id="name" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="quantity">Enter Product Quantity: </label>
              <input type="number" name="quantity" id="quantity" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="old_price">Enter Product Old Price: </label>
              <input type="number" step="any" name="old_price" id="old_price" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="new_price">Enter Product New Price: </label>
              <input type="number" step="any" name="new_price" id="new_price" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="expiry_date">Enter Product Expiry Date: </label>
              <input type="date" name="expiry_date" id="expiry_date" class="form-control">
              <span class="form-error"></span>
            </div>

            <div >
              <label for="image">Select Product Image: </label>
              <input class="" type="file" name="image" id="image" accept="image/*">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="weight">Enter Product Weight(kg): </label>
              <input type="number" step="any" name="weight" id="weight" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="length">Enter Product Length(cm): </label>
              <input type="number" step="any" name="length" id="length" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="width">Enter Product Width(cm): </label>
              <input type="number" step="any" name="width" id="width" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="height">Enter Product Height(cm): </label>
              <input type="number" step="any" name="height" id="height" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="new_price">Enter Product Shipping Fee: </label>
              <input type="number" step="any" name="shipping_fee" id="shipping_fee" class="form-control">
              <span class="form-error"></span>
            </div>

            <div class="form-group">
              <label for="description">Enter Product Description: </label>
              <textarea name="description" id="description" cols="30" rows="10" class="form-control"></textarea>
              <span class="form-error"></span>
            </div>

            <input type="submit" class="btn btn-primary" value="PROCEED">

          </form>
        </div>
      </div>

      <div class="card" id="more-info-on-product-order-card" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackMoreInfoOnProductOrderCard(this,event)">Go Back</button>
          <h3 class="card-title"></h3>
        </div>
        <div class="card-body">
          
        </div>
      </div>

      <div class="card" id="orders-awaiting-approval-card" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackOrdersAwaitingApprovalCard(this,event)">Go Back</button>
          <h3 class="card-title">Orders Awaiting Your Approval</h3>
        </div>
        <div class="card-body">
          
        </div>
      </div>

      <div class="card" id="orders-with-your-approval-card" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackOrdersWithYourApprovalCard(this,event)">Go Back</button>
          <h3 class="card-title">Orders With Your Approval</h3>
        </div>
        <div class="card-body">
          
        </div>
      </div>

      <div class="card" id="users-who-have-share-in-this-order-card" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackUsersWhoHaveShareInThisOrderCard(this,event)">Go Back</button>
          <h3 class="card-title">Users Who Have Share In This Order</h3>
        </div>
        <div class="card-body">
          
        </div>
      </div>

      <div class="card" id="previous-requests-dispatcher-info-card" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackPreviousRequetsDispatcherInfoCard(this,event)">Go Back</button>
          
        </div>
        <div class="card-body">
          
        </div>
      </div>

      <div class="card" id="new-requests-dispatcher-card" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackNewRequetsDispatcherCard(this,event)">Go Back</button>
          <h3 class="card-title">New Dispatcher Requests</h3>
        </div>
        <div class="card-body">
          
        </div>
      </div>

      <div class="card" id="previous-requests-dispatcher-card" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackPreviousRequetsDispatcherCard(this,event)">Go Back</button>
          <h3 class="card-title">Previous Dispatcher Requests</h3>
        </div>
        <div class="card-body">
          
        </div>
      </div>

      <div class="card" id="center-leader-requests-card-undelivered" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackCenterLeaderRequestsUndelivered(this,event)">Go Back</button>
          <h3 class="card-title">Center Leader Requests</h3>
        </div>
        <div class="card-body">
          
        </div>
      </div>

      <div class="card" id="center-leader-requests-card-delivered" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackCenterLeaderRequestsDelivered(this,event)">Go Back</button>
          <h3 class="card-title">Center Leader Requests</h3>
        </div>
        <div class="card-body">
          
        </div>
      </div>


      <div class="card" style="display: none;" id="order-info-card">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackFromOrderInfoCard(this,event)">Go Back</button>
          <h3 class="card-title">Order: jdjdjdj</h3>
        </div>

        <div class="card-body">
          
        </div>
      </div>

      <div class="card" style="display: none;" id="your-orders-card">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackFromOrdersCard(this,event)">Go Back</button>
          <h3 class="card-title">Your Orders</h3>
        </div>

        <div class="card-body">
          
        </div>
      </div>

      <div class="card" id="products-on-way-to-center-leader-info-card" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackProductsOnWayToCenterLeaderInfoCard(this,event)">Go Back</button>
          <h4 class="card-title" id="welcome-heading" style="text-transform: capitalize;"></h4>
        </div>
        <div class="card-body">
          
        </div>
      </div>
      
      <div class="card" id="choose-action-card">
        <div class="card-header">
          <h4 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Choose Option: </h4>
        </div>
        <div class="card-body">
          <table class="table">
            <tbody>
              <tr class="pointer-cursor">
                <td>1</td>
                <td><a href="#" onclick="becomeMerchant(this,event)">Merchant Product Upload</a></td>
              </tr>
              <tr class="pointer-cursor">
                <td>2</td>
                <td><a href="#" onclick="becomeCenterLeader(this,event)">Become A Center Leader/ Edit Your Center Leader Information / View Center Leader Requests</a></td>
              </tr>

              <tr class="pointer-cursor">
                <td>3</td>
                <td><a href="#" onclick="shopOurProducts(this,event)">Shop Our Products</a></td>
              </tr>

              <tr class="pointer-cursor">
                <td>4</td>
                <td><a href="#" onclick="yourOrders(this,event)">Your Orders</a></td>
              </tr>
              
              <?php if($this->meetglobal_model->getUserParamById("dispatcher",$user_id) == 1){ ?>
              <tr class="pointer-cursor">
                <td>5</td>
                <td><a href="#" onclick="accessDispatcherFunctions(this,event)">Access Dispatcher Functions</a></td>
              </tr>
              <?php } ?>
              

            </tbody>
          </table>
        </div>
      </div>

      <div class="card" id="choose-action-center-leader-requests-card" style="display: none;">
        <div class="card-header">
          <button class="btn btn-warning btn-round" onclick="goBackChooseActionCenterLeaderRequestsCard(this,event)">Go Back</button>
          <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Choose Option: </h3>
        </div>
        <div class="card-body">
          <table class="table">
            <tbody>
              <tr class="pointer-cursor">
                <td>1</td>
                <td><a href="#" onclick="ordersAwaitingApproval(this,event)">Orders Awaiting Your Approval</tr>

              <tr class="pointer-cursor">
                <td>2</td>
                <td><a href="#" onclick="ordersWithApproval(this,event)">Orders With Your Approval</a></td>
              </tr>

            </tbody>
          </table>
        </div>
      </div>

      <div class="card" id="edit-center-leader-info-card" style="display: none;">
        <div class="card-header">
          <button onclick="goBackFromEditCenterLeaderInfoCard(this,event)" class="btn btn-warning btn-round">Go Back</button>
          <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Edit Your Center Leader Information: </h3>
        </div>
        <div class="card-body">
          <?php
            $attr = array('id' => 'edit-center-leader-info-form');
           echo form_open('meetglobal/submit_edit_center_leader_info_form',$attr);
          ?>
          <div class="form-row">
            <div class="form-group col-sm-12">
              <label for="">Country:</label>
              <h4><?php echo $this->meetglobal_model->getCountryById($country_id); ?></h4>
              
            </div>
            <div class="form-group col-sm-6">
              <label for="state" style="font-weight: bold;">State: </label>
              <select name="state" id="state" class="form-control my-select" data-style="btn btn-primary btn-round"  data-size="7" onchange="stateChangedEditCenterLeaderInfo(this,event)">
                <?php
                  $first_regions = $this->meetglobal_model->getFirstRegionsByCountryId($country_id);
                  if(is_array($first_regions)){ 
                    foreach($first_regions as $region){
                      $region_name = $region->name;
                      $country_id = $region->country_id;
                      $region_id = $region->id;
                ?>
                <option style="text-transform: capitalize;" <?php if($user_state_id == $region_id){ echo "selected"; } ?> value="<?php echo $region_id ?>"><?php echo $region_name; ?></option>
                <?php
                    }
                  }
                ?>
              </select>
              <span class="form-error"></span>
            </div>

            <div class="form-group col-sm-6">
              <label for="local_government" style="font-weight: bold;">Local Government: </label>
              <select name="local_government" id="local_government" class="form-control my-select" data-style="btn btn-primary btn-round"  data-size="7">
                <?php
                  
                  $first_locals = $this->meetglobal_model->getLocalGovernmentsByStateId($user_state_id);
                  
                  if(is_array($first_locals)){ 
                    foreach($first_locals as $row){
                      $id = $row->id;
                      $state_id = $row->state_id;
                      $name = $row->name;
                ?>
                <option style="text-transform: capitalize;" <?php if($local_government == $id){ echo "selected"; } ?> value="<?php echo $id ?>"><?php echo $name; ?></option>
                <?php
                    }
                  }
                ?>
              </select>
              <span class="form-error"></span>
            </div>

            <div class="form-group col-sm-6">
              <label for="city">Town: </label>
              <input type="text" name="city" id="city" class="form-control" value="<?php echo $city; ?>" required>
              <span class="form-error"></span>
            </div>

            <div class="form-group col-sm-6">
              <label for="address">Address: </label>
              <textarea name="address" id="address" cols="30" rows="10" class="form-control"><?php echo $address; ?></textarea>
              <span class="form-error"></span>
            </div>

            <div class="form-group col-sm-6">
              <label for="place_of_use">Place Of Use: </label>
              <select name="place_of_use" id="place_of_use" class="form-control my-select" data-style="btn btn-primary btn-round"  data-size="7">
                <option value="home" <?php if($place_of_use == "home"){ echo "selected"; } ?>>Home</option>
                <option value="office" <?php if($place_of_use == "office"){ echo "selected"; } ?>>B/Office</option>
                <option value="shop" <?php if($place_of_use == "shop"){ echo "selected"; } ?>>Shop</option>
                
              </select>
              <span class="form-error"></span>
            </div>

            <div class="form-group col-sm-6">
              <p class="label">Whatsapp User? </p>
              
              <div class="form-check form-check-radio form-check-inline">
                <label class="form-check-label">
                  <input type="radio" class="form-check-input" name="whatsapp_user" id="whatsapp_user_yes" value="1"  <?php if($whatsapp_user == 1){ echo "checked"; } ?>> Yes                                   
                  <span class="circle">
                      <span class="check"></span>
                  </span>
                </label>                                                                 
              </div>

              <div class="form-check form-check-radio form-check-inline">
                <label class="form-check-label">
                  <input type="radio" class="form-check-input" name="whatsapp_user" id="whatsapp_user_no" value="0"  <?php if($whatsapp_user == 0){ echo "checked"; } ?>> No                                   
                  <span class="circle">
                      <span class="check"></span>
                  </span>
                </label>                                                                 
              </div>
              
              <span class="form-error"></span> 
            </div>

            
  
          </div>
            <input type="submit" style="display: none;" class="btn btn-success" value="PROCEED">

          </form>
        </div>
      </div>

      <div class="card" id="become-center-leader-card" style="display: none;">
        <div class="card-header">
          <button onclick="goBackFromBecomeCenterLeadetrCard(this,event)" class="btn btn-warning btn-round">Go Back</button>
          <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Become A Center Leader: </h3>
        </div>
        <div class="card-body">
          <?php
            $attr = array('id' => 'become-center-leader-form');
           echo form_open('meetglobal/submit_become_center_leader_form',$attr);
          ?>
          <div class="form-row">
            <div class="form-group col-sm-12">
              <label for="">Country:</label>
              <h4><?php echo $this->meetglobal_model->getCountryById($country_id); ?></h4>
              
            </div>
            <div class="form-group col-sm-6">
              <label for="state" style="font-weight: bold;">State: </label>
              <select name="state" id="state" class="form-control my-select" data-style="btn btn-primary btn-round"  data-size="7" onchange="stateChanged(this,event)">
                <?php
                  $first_regions = $this->meetglobal_model->getFirstRegionsByCountryId($country_id);
                  if(is_array($first_regions)){ 
                    foreach($first_regions as $region){
                      $region_name = $region->name;
                      $country_id = $region->country_id;
                      $region_id = $region->id;
                ?>
                <option style="text-transform: capitalize;" <?php if($state_id == $region_id){ echo "selected"; } ?> value="<?php echo $region_id ?>"><?php echo $region_name; ?></option>
                <?php
                    }
                  }
                ?>
              </select>
              <span class="form-error"></span>
            </div>

            <div class="form-group col-sm-6">
              <label for="local_government" style="font-weight: bold;">Local Government: </label>
              <select name="local_government" id="local_government" class="form-control my-select" data-style="btn btn-primary btn-round"  data-size="7">
                <?php
                  if($state_id == 0){
                    $first_locals = $this->meetglobal_model->getFirstLocalGovernments();
                  }else{
                    $first_locals = $this->meetglobal_model->getLocalGovernmentsByStateId($state_id);
                  }
                  if(is_array($first_locals)){ 
                    foreach($first_locals as $row){
                      $id = $row->id;
                      $state_id = $row->state_id;
                      $name = $row->name;
                ?>
                <option style="text-transform: capitalize;" <?php if($local_government == $id){ echo "selected"; } ?> value="<?php echo $id ?>"><?php echo $name; ?></option>
                <?php
                    }
                  }
                ?>
              </select>
              <span class="form-error"></span>
            </div>

            <div class="form-group col-sm-6">
              <label for="city">Town: </label>
              <input type="text" name="city" id="city" class="form-control" value="<?php echo $city; ?>" required>
              <span class="form-error"></span>
            </div>

            <div class="form-group col-sm-6">
              <label for="address">Address: </label>
              <textarea name="address" id="address" cols="30" rows="10" class="form-control"><?php echo $address; ?></textarea>
              <span class="form-error"></span>
            </div>

            <div class="form-group col-sm-6">
              <label for="place_of_use">Place Of Use: </label>
              <select name="place_of_use" id="place_of_use" class="form-control my-select" data-style="btn btn-primary btn-round"  data-size="7">
                <option value="home" <?php if($place_of_use == "home"){ echo "selected"; } ?>>Home</option>
                <option value="office" <?php if($place_of_use == "office"){ echo "selected"; } ?>>B/Office</option>
                <option value="shop" <?php if($place_of_use == "shop"){ echo "selected"; } ?>>Shop</option>
                
              </select>
              <span class="form-error"></span>
            </div>

            <div class="form-group col-sm-6">
              <p class="label">Whatsapp User? </p>
              
              <div class="form-check form-check-radio form-check-inline">
                <label class="form-check-label">
                  <input type="radio" class="form-check-input" name="whatsapp_user" id="whatsapp_user_yes" value="1"  > Yes                                   
                  <span class="circle">
                      <span class="check"></span>
                  </span>
                </label>                                                                 
              </div>

              <div class="form-check form-check-radio form-check-inline">
                <label class="form-check-label">
                  <input type="radio" class="form-check-input" name="whatsapp_user" id="whatsapp_user_no" value="0"  checked> No                                   
                  <span class="circle">
                      <span class="check"></span>
                  </span>
                </label>                                                                 
              </div>
              
              <span class="form-error"></span> 
            </div>

            <div class="form-group col-sm-6">
              <div class="form-check form-check-inline">
                <label class="form-check-label">
                  <input class="form-check-input" type="checkbox" id="terms_checkbox" value="yes"> I Agree To Terms And Conditions
                  <span class="form-check-sign">
                      <span class="check"></span>
                  </span>
                </label>
              </div>
            </div>
  
          </div>
            <input type="submit" style="display: none;" class="btn btn-success" value="PROCEED">

          </form>
        </div>
      </div>
    </section>
  </div>

  <div class="modal fade" data-backdrop="static" id="cart-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content" style="background: #F8F8F8;">
        <div class="modal-header">
          <h3 class="modal-title">Cart (<span class="cart-num">2</span> items)</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="modal-body" id="modal-body">
          
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-warning" id="checkout-btn" style="font-weight: bold; font-size: 13px;">PROCEED TO CHECKOUT</button>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" data-backdrop="static" id="change-address-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content" >
        <div class="modal-header">
          <h3 class="modal-title">Change Address</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="modal-body" id="modal-body">
          <?php 
            $attr = array('id' => 'change-address-form');
            echo form_open('meetglobal/change_user_address',$attr);
          ?>
          
          <div class="form-group">
            <label for="address">Address</label>
            <textarea name="address" id="address" cols="30" rows="10" class="form-control"></textarea>
            <span class="form-error"></span> 
          </div>

          <input type="submit" class="btn btn-primary" >

          </form>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal" aria-label="Close">Close</button>
        </div>
      </div>
    </div>
  </div>

  <div id="mark-product-as-received-by-center-leader-btn" onclick="markProductAsReceivedByCenterLeader(this,event)" rel="tooltip" data-toggle="tooltip" title="Mark This Product As Received By Center Leader" style="background: #9c27b0; cursor: pointer; position: fixed; bottom: 0; right: 0;  border-radius: 50%; cursor: pointer; display: none; fill: #fff; height: 56px; outline: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.2);">
    <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
      <i class="fas fa-check" style="font-size: 25px; color: #fff;" aria-hidden="true"></i>
    </div>
  </div>
  
  <div id="view-cart-btn" onclick="viewCart(this,event)" rel="tooltip" data-toggle="tooltip" title="View Cart" style="background: #FF9900; cursor: pointer; position: fixed; bottom: 0; right: 0;  border-radius: 50%; cursor: pointer; display: none; fill: #fff; height: 56px; outline: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;">
    <span id="cart-products-num" class="cart-num" style="font-size: 12px;
    line-height: 1.1em;
    background: #f99047;
    padding: 2px;
    border: 2px solid #fff;
    border-radius: 50%;
    position: absolute;
    top: -1px;
    left: 19px;
    color: #fff;
    min-width: 22px;
    min-height: 22px;
    font-weight: 700;
    text-align: center;
    letter-spacing: -1px;
    text-indent: -1px;"><?php echo $this->meetglobal_model->getNumberOfProductsInCart(); ?></span>
    <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
      <i class="fas fa-shopping-cart" style="font-size: 25px;  color: #fff;" aria-hidden="true"></i>
    </div>
  </div>

  <div id="submit-become-center-leader-form-btn" onclick="submitBecomeCenterLeaderForm(this,event)" rel="tooltip" data-toggle="tooltip" title="Submit The Form" style="background: #9c27b0; cursor: pointer; position: fixed; bottom: 0; right: 0;  border-radius: 50%; cursor: pointer; display: none; fill: #fff; height: 56px; outline: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.2);">
    <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
      <i class="fas fa-paper-plane" style="font-size: 25px; font-weight: normal; color: #fff;" aria-hidden="true"></i>
    </div>
  </div>

  <div id="submit-edit-center-leader-form-btn" onclick="submitEditCenterLeaderForm(this,event)" rel="tooltip" data-toggle="tooltip" title="Submit The Form" style="background: #9c27b0; cursor: pointer; position: fixed; bottom: 0; right: 0;  border-radius: 50%; cursor: pointer; display: none; fill: #fff; height: 56px; outline: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.2);">
    <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
      <i class="fas fa-paper-plane" style="font-size: 25px; font-weight: normal; color: #fff;" aria-hidden="true"></i>
    </div>
  </div>

</div>

<footer class="footer">
  <div class="container-fluid">
    <!-- <footer>&copy; <?php echo date("Y"); ?> Copyright (meetglobal Issues Global Limited). All Rights Reserved</footer> -->
  </div>
</footer>

<script>
  $(document).ready(function () {

    $("#edit-center-leader-info-form").submit(function (evt) {
      evt.preventDefault();
      var me = $(this);
      var url = me.attr("action");
      var form_data = me.serializeArray();

      $(".spinner-overlay").show();
      console.log(form_data)
      $.ajax({
        url : url,
        type : "POST",
        responseType : "json",
        dataType : "json",
        data : form_data,
        success : function (response) {
          console.log(response)
          $(".spinner-overlay").hide();
          if(response.success){
            $.notify({
            message:"Center Leader Information Edited Successfully"
            },{
              type : "success"  
            });
          }else if(!response.terms_selected){ 
            swal({
              title: 'Error',
              text: "You Need To Agree To Terms And Conditions To Proceed",
              type: 'error',                                          
            })
          }else{
            $.each(response.messages, function (key,value) {

            var element = me.find("#"+key);
            
            element.closest('div.form-group')
                    
                    .find('.form-error').remove();
            element.after(value);
            
           });
            $.notify({
            message:"Some Values Where Not Valid. Please Enter Valid Values"
            },{
              type : "warning"  
            });
          }
        },error : function () {
          $(".spinner-overlay").hide();
          swal({
            title: 'Ooops',
            text: "Something Went Wrong",
            type: 'error'
          })
        } 
      }); 
    })

    $("#change-address-form").submit(function (evt) {
      evt.preventDefault();
      var me  = $(this);
      var url = me.attr("action");
      var form_data = me.serializeArray();
      var address = me.find('#address').val();
      $(".spinner-overlay").show();
      
      $.ajax({
        url : url,
        type : "POST",
        responseType : "json",
        dataType : "json",
        data : form_data,
        success : function (response) {
          console.log(response)
          $(".spinner-overlay").hide();
          if(response.success){
            $.notify({
            message:"Address Edited Successfully"
            },{
              type : "success"  
            });
            $(".details-card .card-body .details-div .address").html(address);
            $("#change-address-modal").modal("hide");

          }else{
            $.each(response.messages, function (key,value) {

              var element = me.find("#"+key);
              
              element.closest('div.form-group')
                      
                      .find('.form-error').remove();
              element.after(value);
              
             });
              $.notify({
              message:"Some Values Where Not Valid. Please Enter Valid Values"
              },{
                type : "warning"  
              });
            }
          },error : function () {
            $(".spinner-overlay").hide();
            swal({
              title: 'Ooops',
              text: "Something Went Wrong",
              type: 'error'
            })
          }
      });   
    })
    
    $("#checkout-btn").click(function (evt) {

      var obj = [];
      $("#cart-modal .main-row").each(function(index, el) {
        el = $(el);
        var cart_id = el.attr("data-cart-id");
        var quantity = el.find('.quantity_requested').val();

        obj.push({
          cart_id : cart_id,
          quantity : quantity
        })
      });

      console.log(obj)

      var form_data = {
        data : obj
      };
      $(".spinner-overlay").show();
      var url = "<?php echo site_url('meetglobal/submit_cart_final_mini_importation') ?>";
      $.ajax({
        url : url,
        type : "POST",
        responseType : "json",
        dataType : "json",
        data : form_data,
        success : function (response) {
          console.log(response)
          $(".spinner-overlay").hide();
          if(response.success && response.products.length != 0){
            var messages = response.messages;
            var products = response.products;
            var products_info = '';
            for(var i = 0; i < products.length; i++){
              var image = products[i].image;
              var name = products[i].name;
              var price = products[i].new_price;
              var quantity_requested = products[i].quantity_requested;
              var price_times_quantity = parseFloat((price * quantity_requested).toFixed(2));
              var total_price = response.total_price;
              var total_shipping = response.total_shipping;
              var service_charge = response.service_charge;
              var full_name = response.full_name;
              var user_name = response.user_name;
              var address = response.address;
              var phone_number = response.phone_number;

              var grand_total_fee = parseFloat(((total_shipping + total_price) + (total_shipping + total_price) * 0.05).toFixed(2));



              if(name.length > 50){
                name = name.slice(0, 50) + "...";
              }

              products_info += '<div class="product-row row">';
              products_info += '<div class="col-4" style="margin-top: 6px; padding: 0;">';
              products_info += '<img class="col-12" style="padding: 0;" src="<?php echo base_url('assets/images/') ?>'+ image +'" alt="">';
              products_info += '</div>';

              products_info += '<div class="col-8" style="padding: 0">';

              products_info += '<span class="product-name">'+name+'</span>';

              products_info += '<span class="sub-total-price text-warning">₦ '+addCommas(price_times_quantity)+'</span>';
              products_info += '<span class="quantity">Qty: '+quantity_requested+'</span>';
              products_info += '</div>';
              products_info += '</div>';
            }      
            console.log(products_info)
            
            $("#products-div-container").html(products_info);
            $(".order-summary-card .total-div .sub-total-val").html('₦' + addCommas(total_price));
            $(".order-summary-card .total-div .shipping-val").html('₦' + addCommas(total_shipping));
            $(".order-summary-card .total-div .service-charge-val").html('₦' + addCommas(service_charge));
            $(".order-summary-card .total-div .total-val").html('₦' + addCommas(grand_total_fee));
            $(".details-card .card-body .details-div .name").html(full_name);
            $(".details-card .card-body .details-div .address").html(address);
            $(".details-card .card-body .details-div .phone").html(phone_number);
            $(".order-summary-card .heading span").html("YOUR ORDER("+products.length+" items)")
            $("#cart-modal").modal("hide");
            $("#product-info-card").hide();
            $("#shop").hide();
            $("#checkout-container").show()
          }

        },error : function () {
          $(".spinner-overlay").hide();
          $.notify({
            message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
            },{
              type : "danger" 
          });
        } 
      }); 
    })
    

    $(".product-card").click(function (evt) {
      var me = $(this);
      var id = me.attr("data-id");

      var form_data = {
        product_id : id
      };

      $(".spinner-overlay").show();
      var url = "<?php echo site_url('meetglobal/get_product_mini_importation_info') ?>";
      $.ajax({
        url : url,
        type : "POST",
        responseType : "json",
        dataType : "json",
        data : form_data,
        success : function (response) {
          console.log(response)
          $(".spinner-overlay").hide();
          if(response.success && response.messages != ""){
            var messages = response.messages;
            
            $("#shop").hide();
            $("#product-info-card .card-body").html(messages);
            $("#product-info-card").show();
            
          }

        },error : function () {
          $(".spinner-overlay").hide();
          $.notify({
            message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
            },{
              type : "danger" 
          });
        } 
      });   
    })

    $(".product-card").mouseenter(function(event) {
      $(this).css({
        "box-shadow" : "2px 2px #D8D8D8"
      })
    });

    $(".product-card").mouseleave(function(event) {
      $(this).css({
        "box-shadow" : "0 1px 4px 0 rgba(0,0,0,.14)"
      })
    });

    $(".btn-orange").mouseenter(function (evt) {
      $(this).css({
        "background-color" : "#FF9900",
        "border" : "1px solid #FF9900",
        "color" : "#FFF"
      })
    })

    $(".btn-orange").mouseleave(function (evt) {
      $(this).css({
        "background-color" : "rgb(0,0,0,0)",
        "border" : "1px solid #FF9900",
        "color" : "#FF9900"
      })
    })

    $('.owl-carousel').owlCarousel({
        autoplay:true,
        autoplayTimeout:4000,
        autoplayHoverPause:true,
        items:5,
        loop:true,
        margin:10,
        merge:true,
        dots : true,
        responsive:{
            678:{
                mergeFit:true
            },
            1000:{
                mergeFit:false
            }
        }
    });

    $(".my-select").selectpicker();
    $("#become-center-leader-form").submit(function (evt) {
      evt.preventDefault();
      var me = $(this);
      var url = me.attr("action");
      var form_data = me.serializeArray();

      var terms_selected = me.find("#terms_checkbox").prop("checked");
      if(terms_selected){
        form_data = form_data.concat({
          "name" : "terms_checkbox",
          "value" : true
        })
        $(".spinner-overlay").show();
        console.log(form_data)
        $.ajax({
          url : url,
          type : "POST",
          responseType : "json",
          dataType : "json",
          data : form_data,
          success : function (response) {
            console.log(response)
            $(".spinner-overlay").hide();
            if(response.success && response.url != ""){
              swal({
                title: 'Choose Action',
                text: "Do You Want To Pay Through? ",
                type: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Your Wallet',
                cancelButtonText : "Online Payment"
              }).then(function(){
                swal({
                  title: 'Confirm?',
                  text: "You Are About To Pay 1,500 From Your Wallet. Do You Wish To Proceed? ",
                  type: 'question',
                  showCancelButton: true,
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Proceed! ',
                  cancelButtonText : "Cancel"
                }).then(function(){
                  $(".spinner-overlay").show();

                  var url = "<?php echo site_url('meetglobal/center_leader_payment_existing_funds'); ?>";
                  var form_data = {
                    "show_records" : true
                  };
                  $.ajax({
                    url : url,
                    type : "POST",
                    responseType : "json",
                    dataType : "json",
                    data : form_data,
                    success : function (response) {
                      $(".spinner-overlay").hide();
                      if(response.success){
                        document.location.reload();
                      }else if(response.funds_not_enough){
                        swal({
                          title: 'Error',
                          text: "You Do Not Have Enough Funds In Your Account To Proceed. Please Credit Your Account.",
                          type: 'error',                                          
                        })
                      }
                    },error: function () {
                      $(".spinner-overlay").hide();
                      swal({
                        title: 'Ooops',
                        text: "Something Went Wrong",
                        type: 'error'
                      })
                    }
                  });  
                });
              },function(dismiss){
                if(dismiss == 'cancel'){
                  $.notify({
                  message:"Proceeding To Secure Payment Page........"
                  },{
                    type : "success"  
                  });
                  setTimeout(function () {
                    window.location.assign(response.url);
                  }, 2000);
                }
              });  
            }else if(!response.has_business_account){ 
              swal({
                title: 'Error',
                text: "Sorry You Need To Have At Least One Business Mlm Account To Become A Center Leader.",
                type: 'error',                                          
              })
            }else if(response.not_enough_sponsors){ 
              swal({
                title: 'Error',
                text: "Sorry You Need To Have At Least 10 Direct Sponsors On Mlm To Become A Center Leader.",
                type: 'error',                                          
              })
            }else if(!response.terms_selected){ 
              swal({
                title: 'Error',
                text: "You Need To Agree To Terms And Conditions To Proceed",
                type: 'error',                                          
              })
            }else{
              $.each(response.messages, function (key,value) {

              var element = me.find("#"+key);
              
              element.closest('div.form-group')
                      
                      .find('.form-error').remove();
              element.after(value);
              
             });
              $.notify({
              message:"Some Values Where Not Valid. Please Enter Valid Values"
              },{
                type : "warning"  
              });
            }
          },error : function () {
            $(".spinner-overlay").hide();
            swal({
              title: 'Ooops',
              text: "Something Went Wrong",
              type: 'error'
            })
          } 
        }); 
      }else{
        swal({
          title: 'Error',
          text: "You Need To Agree To Terms And Conditions To Proceed",
          type: 'error',                                          
        })
      }
    })

    <?php if($this->session->center_leader_successful){ ?>
      $.notify({
      message:"Congrats! You Are Now A Center Leader"
      },{
        type : "success"  
      });
    <?php } ?>
  })
</script>
</div>
</div>
  <!--   Core JS Files   -->
 