         <!-- End Navbar -->
      <style>
        .sum{
          font-style: italic;
        }
      </style>
      <link href="<?php echo base_url('assets/css/treeflex.css') ?>" rel="stylesheet">
  <style>
    .ratio{
      font-weight: bold;
    }
    .tf-tree{
      text-align: center;
      /*cursor: col-resize;*/
    }
  
    .tf-tree .tf-nc .name{
      font-size: 20px;
    }

    .tf-tree .tf-nc {
      width: 150px;
      height: 220px;
      background: #fff;
      border: 0;
      border-radius: 4px;
      position: relative;
      padding-bottom: 10px;
      /*cursor: pointer;*/

    }

    .tf-tree .tf-nc .icons-div{
      /*margin-top: 10px;
      margin-bottom: 20px;*/
      /*position: absolute; 
      bottom: 0px; */
    }

    .tf-nc.business{
      border: 5px solid #7ea960;
      box-shadow: 0 2px 6px 0 #7ea960;
    }

    .tf-nc.basic{
      border: 5px solid #7ea960;
      box-shadow: 0 2px 6px 0 #7ea960;
    }

    .tf-nc.basic .package{
      color: #7ea960;
      text-transform: uppercase;
      font-weight: 700;
    }

    .tf-nc.business .package{
      color: #7ea960;
      text-transform: uppercase;
      font-weight: 700;
    }
    .tf-nc .register-text{
      line-height: 200px;
      font-size: 19px;
      font-weight: bold;
    }

    .tf-nc.register{
      border: 5px solid #000;
    }

    .tf-tree .tf-nc .user-name{
      font-weight: bold;
      font-size: 18px;
      font-style: italic;
    }

    .tf-custom .tf-nc:before,
    .tf-custom .tf-nc:after {
      /* css here */
    }

    .tf-custom li li:before {
      /* css here */
    }

    .spinner{
      display: none;
    }

    .tf-tree{
      color: #7ea960;
    }

    .tf-tree img{
      display: none;
    }

    .tf-tree .package{
      display: none;
    }
  </style>
      <script>
        var global_user_id = "";
         function addCommas(nStr)
          {
              nStr += '';
              x = nStr.split('.');
              x1 = x[0];
              x2 = x.length > 1 ? '.' + x[1] : '';
              var rgx = /(\d+)(\d{3})/;
              while (rgx.test(x1)) {
                  x1 = x1.replace(rgx, '$1' + ',' + '$2');
              }
              return x1 + x2;
          }

          

          function reloadPage (elem) {
            document.location.reload(); 
          }

          function performFunctionOnUser(elem,evt,user_id){
            global_user_id = user_id;
            console.log(user_id)
            var url = "<?php echo site_url('sabicapital/index/admin/get_user_info_by_id') ?>";
            var form_data = {
              'show_records' : true,
              'user_id' : global_user_id
            }
            $(".spinner-overlay").show();
    
            $.ajax({
              url : url,
              type : "POST",
              responseType : "json",
              dataType : "json",
              data : form_data,
              success : function (response) {
                console.log(response)
                $(".spinner-overlay").hide();
                if(response.success){
                  var user_name = response[0].user_name;
                  $("#perform-function-on-user-modal .modal-title").html("Choose Action To Perform On " + user_name);
                  if(response[0].active == 0){
                    $("#perform-function-on-user-modal .activate-deactive-item").html("Activate User");
                    $("#perform-function-on-user-modal .activate-deactive-item").parent().attr("onclick","activateUser(this,event)");
                  }else{
                    $("#perform-function-on-user-modal .activate-deactive-item").html("Deactivate User");
                    $("#perform-function-on-user-modal .activate-deactive-item").parent().attr("onclick","deactivateUser(this,event)");
                  }
                  $("#perform-function-on-user-modal").modal("show");
                }else{
                  swal({
                    title: 'Error',
                    text: "Sorry Something Went Wrong.",
                    type: 'error',                                          
                  })
                }
              },error : function () {
                $(".spinner-overlay").hide();
                
                swal({
                  title: 'Error',
                  text: "Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again",
                  type: 'error',                                          
                })
              }
            });
          }

          function editUserProfile (elem,evt) {
            var url = "<?php echo site_url('sabicapital/index/admin/get_user_info_by_id') ?>";
            var form_data = {
              'show_records' : true,
              'user_id' : global_user_id
            }
            $(".spinner-overlay").show();
    
            $.ajax({
              url : url,
              type : "POST",
              responseType : "json",
              dataType : "json",
              data : form_data,
              success : function (response) {
                console.log(response)
                $(".spinner-overlay").hide();
                if(response.success){
                  var user_name = response[0].user_name;
                  var full_name = response[0].full_name;
                  var phone = response[0].phone;
                  var email = response[0].email;
                  var dob = response[0].dob;
                  var address = response[0].address;
                  
                  
                  $("#perform-function-on-user-modal").modal("hide");
                  $("#edit-user-profile-card .card-title").html("Edit <em class='text-primary'>" + user_name + "'s</em> Profile");
                  $("#edit-user-profile-card #full_name").val(full_name)
                  $("#edit-user-profile-card #phone").val(phone)
                  $("#edit-user-profile-card #email").val(email)
                  $("#edit-user-profile-card #dob").val(dob)
                  $("#edit-user-profile-card #address").val(address)
                  $("#main-card").hide();
                  $("#edit-user-profile-card").show();
                }else{
                  swal({
                    title: 'Error',
                    text: "Sorry Something Went Wrong.",
                    type: 'error',                                          
                  })
                }
              },error : function () {
                $(".spinner-overlay").hide();
                
                swal({
                  title: 'Error',
                  text: "Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again",
                  type: 'error',                                          
                })
              }
            });
          }

          function goBackFromEditUserProfileCard (elem,evt) {
            $("#perform-function-on-user-modal").modal("show");
            
            $("#main-card").show();
            $("#edit-user-profile-card").hide();
          }

          function deactivateUser (elem,evt) {
            swal({
              title: 'Warning',
              text: "Are You Sure You Want To Deactivate User?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes Proceed!',
              cancelButtonText : "No"
            }).then(function(){
              var url = "<?php echo site_url('sabicapital/index/admin/deactivate_user') ?>";
              var form_data = {
                'show_records' : true,
                'user_id' : global_user_id
              }
              $(".spinner-overlay").show();
      
              $.ajax({
                url : url,
                type : "POST",
                responseType : "json",
                dataType : "json",
                data : form_data,
                success : function (response) {
                  console.log(response)
                  $(".spinner-overlay").hide();
                  if(response.success){
                    $.notify({
                      message:"User Deactivated Successfully"
                    },{
                      type : "success"  
                    });
                    $("#perform-function-on-user-modal .activate-deactive-item").html("Activate User");
                    $("#perform-function-on-user-modal .activate-deactive-item").parent().attr("onclick","activateUser(this,event)");
                  }else if(response.already_deactivated){
                    swal({
                      title: 'Error',
                      text: "This User Is Already Deactivated",
                      type: 'error',                                          
                    })
                  }else{
                    swal({
                      title: 'Error',
                      text: "Sorry Something Went Wrong.",
                      type: 'error',                                          
                    })
                  }
                },error : function () {
                  $(".spinner-overlay").hide();
                  
                  swal({
                    title: 'Error',
                    text: "Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again",
                    type: 'error',                                          
                  })
                }
              });
            });
          }

          function activateUser (elem,evt) {
            swal({
              title: 'Warning',
              text: "Are You Sure You Want To Activate User?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes Proceed!',
              cancelButtonText : "No"
            }).then(function(){
              var url = "<?php echo site_url('sabicapital/index/admin/activate_user') ?>";
              var form_data = {
                'show_records' : true,
                'user_id' : global_user_id
              }
              $(".spinner-overlay").show();
      
              $.ajax({
                url : url,
                type : "POST",
                responseType : "json",
                dataType : "json",
                data : form_data,
                success : function (response) {
                  console.log(response)
                  $(".spinner-overlay").hide();
                  if(response.success){
                    $.notify({
                      message:"User Activated Successfully"
                    },{
                      type : "success"  
                    });
                    $("#perform-function-on-user-modal .activate-deactive-item").html("Deactivate User");
                    $("#perform-function-on-user-modal .activate-deactive-item").parent().attr("onclick","deactivateUser(this,event)");
                  }else if(response.already_activated){
                    swal({
                      title: 'Error',
                      text: "This User Is Already Active",
                      type: 'error',                                          
                    })
                  }else{
                    swal({
                      title: 'Error',
                      text: "Sorry Something Went Wrong.",
                      type: 'error',                                          
                    })
                  }
                },error : function () {
                  $(".spinner-overlay").hide();
                  
                  swal({
                    title: 'Error',
                    text: "Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again",
                    type: 'error',                                          
                  })
                }
              });
            });
          }

          function creditUsersWallet (elem,evt) {
            var url = "<?php echo site_url('sabicapital/index/admin/get_user_info_by_id') ?>";
            var form_data = {
              'show_records' : true,
              'user_id' : global_user_id
            }
            $(".spinner-overlay").show();
    
            $.ajax({
              url : url,
              type : "POST",
              responseType : "json",
              dataType : "json",
              data : form_data,
              success : function (response) {
                console.log(response)
                $(".spinner-overlay").hide();
                if(response.success){
                  var user_name = response[0].user_name;
                  var full_name = response[0].full_name;
                  var phone = response[0].phone;
                  var email = response[0].email;
                  var dob = response[0].dob;
                  var address = response[0].address;
                  var total_income = response[0].total_income;
                  var withdrawn = response[0].withdrawn;
                  var wallet_balance = total_income - withdrawn;
                  
                  $(".spinner-overlay").show();
                  $("#perform-function-on-user-modal").modal("hide");
                  setTimeout(function () {
                    $(".spinner-overlay").hide();
                    $("#credit-user-modal .wallet-balance").html("Wallet Balance: ₦"+ wallet_balance.toFixed(2));
                    $("#credit-user-modal").modal("show");
                  }, 1500)
                  
                }else{
                  swal({
                    title: 'Error',
                    text: "Sorry Something Went Wrong.",
                    type: 'error',                                          
                  })
                }
              },error : function () {
                $(".spinner-overlay").hide();
                
                swal({
                  title: 'Error',
                  text: "Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again",
                  type: 'error',                                          
                })
              }
            });
          }

          function closeCreditUserModal(elem,evt){
            $(".spinner-overlay").show();
            $("#credit-user-modal").modal("hide");
            
            setTimeout(function () {
              $(".spinner-overlay").hide();
              $("#perform-function-on-user-modal").modal("show");
            }, 1500)
          }

          function debitUsersWallet (elem,evt) {
            var url = "<?php echo site_url('sabicapital/index/admin/get_user_info_by_id') ?>";
            var form_data = {
              'show_records' : true,
              'user_id' : global_user_id
            }
            $(".spinner-overlay").show();
    
            $.ajax({
              url : url,
              type : "POST",
              responseType : "json",
              dataType : "json",
              data : form_data,
              success : function (response) {
                console.log(response)
                $(".spinner-overlay").hide();
                if(response.success){
                  var user_name = response[0].user_name;
                  var full_name = response[0].full_name;
                  var phone = response[0].phone;
                  var email = response[0].email;
                  var dob = response[0].dob;
                  var address = response[0].address;
                  var total_income = response[0].total_income;
                  var withdrawn = response[0].withdrawn;
                  var wallet_balance = total_income - withdrawn;
                  
                  $(".spinner-overlay").show();
                  $("#perform-function-on-user-modal").modal("hide");
                  setTimeout(function () {
                    $(".spinner-overlay").hide();
                    $("#debit-user-modal .wallet-balance").html("Wallet Balance: ₦"+ wallet_balance.toFixed(2));
                    $("#debit-user-modal #amount").attr("max",wallet_balance);
                    $("#debit-user-modal").modal("show");
                  }, 1500)
                  
                }else{
                  swal({
                    title: 'Error',
                    text: "Sorry Something Went Wrong.",
                    type: 'error',                                          
                  })
                }
              },error : function () {
                $(".spinner-overlay").hide();
                
                swal({
                  title: 'Error',
                  text: "Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again",
                  type: 'error',                                          
                })
              }
            });
          }

          function closeDebitUserModal(elem,evt){
            $(".spinner-overlay").show();
            $("#debit-user-modal").modal("hide");
            
            setTimeout(function () {
              $(".spinner-overlay").hide();
              $("#perform-function-on-user-modal").modal("show");
            }, 1500)
          }

          function viewUsersDownline (elem,evt) {
            var url = "<?php echo site_url('sabicapital/index/admin/view_members_genealogy_tree') ?>";
            var form_data = {
              'show_records' : true,
              'user_id' : global_user_id
            }
            $(".spinner-overlay").show();
    
            $.ajax({
              url : url,
              type : "POST",
              responseType : "json",
              dataType : "json",
              data : form_data,
              success : function (response) {
                console.log(response)
                $(".spinner-overlay").hide();
                if(response.success && response.messages != ""){
                  var messages = response.messages;
                  
                  $("#perform-function-on-user-modal").modal("hide");
                  $("#view-users-downline-card .card-body").html(messages);
                  $("#view-users-downline-card .card-title").html(response.user_name + "'s Downline");

                  $("#view-users-downline-card .tf-tree .tf-nc .user-name").each(function(index, el) {
                    var user_name = $(this).html();
                    var formatted_username = user_name.slice(0,-4);
                    $(this).html(formatted_username);
                  }); 


                  $("#main-card").hide();
                  $("#view-users-downline-card").show();
                  
                }else{
                  swal({
                    title: 'Error',
                    text: "Sorry Something Went Wrong.",
                    type: 'error',                                          
                  })
                }
              },error : function () {
                $(".spinner-overlay").hide();
                
                swal({
                  title: 'Error',
                  text: "Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again",
                  type: 'error',                                          
                })
              }
            });
          }

          function goBackFromViewUsersDownlineCard (elem,evt) {
            $("#main-card").show();
            $("#view-users-downline-card").hide();
            $("#perform-function-on-user-modal").modal("show");
          }

          function goDownMlm(elem,event,mlm_db_id,your_mlm_db_id){
            elem = $(elem);
            var package = elem.attr("data-package");
            $(".spinner-overlay").show();
            var form_data = {
              show_records : true,
              mlm_db_id : mlm_db_id,
              your_mlm_db_id : your_mlm_db_id,
              user_id: global_user_id,
              package : package
            }
            console.log(form_data)
            var url = "<?php echo site_url('sabicapital/view_your_genealogy_tree_down'); ?>"
            $.ajax({
              url : url,
              type : "POST",
              responseType : "json",
              dataType : "json",
              data : form_data,
              success : function (response) {
                $(".spinner-overlay").hide();
                if(response.success && response.messages != ""){
                  var messages = response.messages;

                  $("#view-users-downline-card .card-body").html(messages);
                  $("#view-users-downline-card .tf-tree .tf-nc .user-name").each(function(index, el) {
                    var user_name = $(this).html();
                    var formatted_username = user_name.slice(0,-4);
                    $(this).html(formatted_username);
                  }); 
                  $("#body-cont").show();
                }else{
                  swal({
                    title: 'Ooops',
                    text: "Something Went Wrong",
                    type: 'warning'
                  })
                }
              },error : function () {
                $(".spinner-overlay").hide();
                swal({
                  title: 'Ooops',
                  text: "Something Went Wrong",
                  type: 'error'
                })
              }
            });
          }

          function goUpMlm(elem,event,mlm_db_id,your_mlm_db_id){
            elem = $(elem);
            var package = elem.attr("data-package");
            $(".spinner-overlay").show();
            var form_data = {
              show_records : true,
              mlm_db_id : your_mlm_db_id,
              user_id: global_user_id,
              package : package
            }
            var url = "<?php echo site_url('sabicapital/view_your_genealogy_tree'); ?>"
            $.ajax({
              url : url,
              type : "POST",
              responseType : "json",
              dataType : "json",
              data : form_data,
              success : function (response) {
                $(".spinner-overlay").hide();
                if(response.success && response.messages != ""){
                  var messages = response.messages;
                  
                  $("#view-users-downline-card .card-body").html(messages);
                  $("#view-users-downline-card .tf-tree .tf-nc .user-name").each(function(index, el) {
                    var user_name = $(this).html();
                    var formatted_username = user_name.slice(0,-4);
                    $(this).html(formatted_username);
                  }); 
                  $("#view-users-downline-card").show();
                }else{
                  swal({
                    title: 'Ooops',
                    text: "Something Went Wrong",
                    type: 'warning'
                  })
                }
              },error : function () {
                $(".spinner-overlay").hide();
                swal({
                  title: 'Ooops',
                  text: "Something Went Wrong",
                  type: 'error'
                })
              }
            });
          }
      </script>
      <style>
        tr{
          cursor: pointer;
        }
      </style>
      <div class="content">
        <div class="container-fluid">
          <div class="spinner-overlay" style="display: none;">
            <div class="spinner-well">
              <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading..." style="">
            </div>
          </div>
          <h2>All Registered Members</h2>
          <div class="row justify-content-center">
            <div class="col-sm-12">

              <div class="card" id="view-users-downline-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-warning" onclick="goBackFromViewUsersDownlineCard(this,event)">Go Back</button>
                  <h3 class="card-title">Users Downline</h3>
                </div>
                <div class="card-body">
                  
                </div>
              </div>

              <div class="card" id="edit-user-profile-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-warning" onclick="goBackFromEditUserProfileCard(this,event)">Go Back</button>
                  <h3 class="card-title">Edit Users Profile</h3>
                </div>
                <div class="card-body">
                  <?php
                  $attr = array('id' => 'edit-user-profile-form');
                  echo form_open('sabicapital/index/admin/process-edit-users-profile',$attr);
                  ?>
                    
                    <div class="form-group">
                      <label for="full_name">Full Name: </label>
                      <input type="text" id="full_name" name="full_name" class="form-control" value="">
                      <span class="form-error"></span>
                    </div>
                    <div class="form-group">
                      <label for="phone">Phone Number: </label>
                      <input type="number" id="phone" name="phone" class="form-control" value="">
                      <span class="form-error"></span>
                    </div>
                   
                    <div class="form-group">
                      <label for="email">Email: </label>
                      <input type="email" id="email" name="email" class="form-control" value="">
                      <span class="form-error"></span>
                    </div>
                    <div class="form-group">
                      <label for="date">Date Of Birth: </label>
                      <input type="date" id="dob" name="dob" class="form-control" value="">
                      <span class="form-error"></span>
                    </div>
                    <div class="form-group">
                      <label for="address">Address: </label>
                      <textarea name="address" id="address" class="form-control" cols="30" rows="10"></textarea>
                      <span class="form-error"></span>
                    </div>

                    <button class="btn btn-primary" type="submit">Submit</button>
                  </form>
                </div>
              </div>

              <div class="card" id="main-card">
                <div class="card-header">
                  
                  <h3 class="card-title"></h3>
                </div>
                <div class="card-body">
                <?php
                  $response_arr = array('messages' => '');
                  if(isset($rows)){
                    // var_dump($rows);
                    
                    $response_arr['messages'] .= "<div class='row justify-content-center'>";
                    $attr = array('id' => 'filter-rows-form','class' => 'col-sm-6','style' => 'margin-bottom: 35px;');
                    $response_arr['messages'] .= form_open('',$attr);
                    // $response_arr['messages'] .= "<div class='form-group'>";
                    // $response_arr['messages'] .= "<input type='text' class='form-control' name='full_name' id='full_name' placeholder='Full Name'";

                    // if(isset($_GET['full_name'])){
                    //   $response_arr['messages'] .= "value='" . $_GET['full_name'] . "'";
                    // }

                    // $response_arr['messages'] .= ">";
                    // $response_arr['messages'] .= "</div>";


                    $response_arr['messages'] .= "<div class='form-group'>";
                    $response_arr['messages'] .= "<input type='text' class='form-control' name='full_name' id='full_name' placeholder='Full Name'";

                    if(isset($_GET['full_name'])){
                      $response_arr['messages'] .= "value='" .  $_GET['full_name'] . "'";
                    }

                    $response_arr['messages'] .= ">";
                    $response_arr['messages'] .= "</div>";


                    $response_arr['messages'] .= "<div class='form-group'>";
                    $response_arr['messages'] .= "<input type='text' class='form-control' name='user_name' id='user_name' placeholder='User Name'";

                    if(isset($_GET['user_name'])){
                      $response_arr['messages'] .= "value='" . $_GET['user_name'] . "'";
                    }

                    $response_arr['messages'] .= ">";


                    $response_arr['messages'] .= "</div>";


                    $response_arr['messages'] .= "<div class='form-group'>";
                    $response_arr['messages'] .= "<input type='text' class='form-control' name='phone' id='phone' placeholder='Phone Number'";

                    if(isset($_GET['phone'])){
                      $response_arr['messages'] .= "value='" . $_GET['phone'] . "'";
                    }

                    $response_arr['messages'] .= ">";


                    $response_arr['messages'] .= "</div>";


                    $response_arr['messages'] .= "<div class='form-group'>";
                    $response_arr['messages'] .= "<input type='email' class='form-control' name='email' id='email' placeholder='Email Address'";

                    if(isset($_GET['email'])){
                      $response_arr['messages'] .= "value='" . $_GET['email'] . "'";
                    }

                    $response_arr['messages'] .= ">";


                    $response_arr['messages'] .= "</div>";


                    $response_arr['messages'] .= "<div class='form-group'>";
                    $response_arr['messages'] .= "<input type='date' class='form-control' name='created_date' id='created_date' placeholder='Registration Date'";

                    if(isset($_GET['created_date'])){
                      $response_arr['messages'] .= "value='" . $_GET['created_date'] . "'";
                    }

                    $response_arr['messages'] .= ">";


                    $response_arr['messages'] .= "</div>";



                    $response_arr['messages'] .= "<button type='submit' class='btn btn-primary'>Filter Results</button>";
                    $response_arr['messages'] .= "<button type='button' class='btn btn-secondary' id='clear-filter-rows-form'>Clear</button>";
                    $response_arr['messages'] .= "</form>";
                    $response_arr['messages'] .= "</div>";

                    if(is_array($rows)){
                      // var_dump($_GET);
                    
                      $j = 0;
                 
                      $response_arr['messages'] .= '<div class="table-div material-datatables table-responsive" style="">';
                      $response_arr['messages'] .= '<table id="all-registered-users-table" class="table table-test table-striped table-bordered nowrap hover display" cellspacing="0" width="100%" style="width:100%">';
                      $response_arr['messages'] .= '<thead>';
                      $response_arr['messages'] .= '<tr>';
                      $response_arr['messages'] .= '<th>#</th>';
                      
                      $response_arr['messages'] .= '<th>Full Name</th>';
                      $response_arr['messages'] .= '<th>User Name</th>';
                      $response_arr['messages'] .= '<th>Date Of Registration</th>';
                      $response_arr['messages'] .= '<th>Phone Number</th>';
                      $response_arr['messages'] .= '<th>Email</th>';
                      $response_arr['messages'] .= '<th>Wallet Balance</th>';
                      $response_arr['messages'] .= '<th>Age</th>';
                      $response_arr['messages'] .= '<th>Address</th>';
                      $response_arr['messages'] .= '</tr>';
                      $response_arr['messages'] .= '</thead>';
                      $response_arr['messages'] .= '<tbody>';

                      foreach($rows as $row){
                        $j++;
                        if($third_addition > 1){
                          $row_num = ($third_addition - 1);
                          $row_num *= 10;
                          $row_num += $j;
                        }else{
                          $row_num = $j;
                        }


                        $user_id = $row->id;
                        $user_name = $row->user_name;
                        $full_name = $row->full_name;
                        $dob = $row->dob;
                        $created_date = $row->created_date;
                        $created_time = $row->created_time;
                        $phone = $row->phone;
                        $email = $row->email;
                        $total_income = $row->total_income;
                        $withdrawn = $row->withdrawn;
                        $address = $row->address;
                        $wallet_balance = $total_income - $withdrawn;
                        $age = "";

                        if($dob != ""){
                          $age = $this->sabicapital_model->getPatientAge($dob);
                        }

                        

                      
                        $response_arr['messages'] .= '<tr onclick="performFunctionOnUser(this,event,'.$user_id.')">';
                        $response_arr['messages'] .= '<td>'.$row_num.'</td>';
                        $response_arr['messages'] .= '<td style="text-transform:capitalize;">'.$full_name.'</td>';
                        $response_arr['messages'] .= '<td>'.$user_name.'</td>';
                        $response_arr['messages'] .= '<td>'.$created_date . ' ' . $created_time . '</td>';
                        $response_arr['messages'] .= '<td>'.$phone.'</td>';
                        $response_arr['messages'] .= '<td>'.$email.'</td>';
                        $response_arr['messages'] .= '<td><em class="text-primary">'.number_format($wallet_balance,2).'</em></td>';
                        $response_arr['messages'] .= '<td>'.$age.'</td>';
                        $response_arr['messages'] .= '<td>'.$this->sabicapital_model->custom_echo($address,20).'</td>';
                        $response_arr['messages'] .= '</tr>';
                          
                      }
                      $response_arr['messages'] .= '</tbody>';
                      $response_arr['messages'] .= '</table>';
                      $response_arr['messages'] .= '</div>';
                                   
                        
                      $response_arr['messages'] .= $str_links;
                      $no_of_pages = round($total_rows / 10);
                      $response_arr['messages'] .=  "<h4 class='text-primary' style='font-weight: bold;'>". $total_rows . " Total Entries</h4>";
                    }else{
                      $response_arr['messages'] .= '<h4 class="text-warning">No Records To Display Here.</h4>';
                    }

                    echo $response_arr['messages'];
                  }
                ?>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

      <div class="modal fade" data-backdrop="static" id="debit-user-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title text-center" style="text-transform: capitalize;">Enter Amount To Debit User</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="closeDebitUserModal(this,event)">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body" id="modal-body">
              <h5><em class="text-primary wallet-balance" >Wallet Balance: ₦ 50,000.00</em></h5>
              <?php
              $attr = array('id' => 'debit-user-form');
              echo form_open('sabicapital/index/admin/debit_user',$attr);
              ?>
                
                <div class="form-group">
                  <label for="amount">Amount: </label>
                  <input type="number" id="amount" name="amount" class="form-control" value="" step="any">
                  <span class="form-error"></span>
                </div>
                <input type="submit" class="btn btn-primary">
              </form>
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal" onclick="closeDebitUserModal(this,event)">Close</button>
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade" data-backdrop="static" id="credit-user-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title text-center" style="text-transform: capitalize;">Enter Amount To Credit User</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="closeCreditUserModal(this,event)">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body" id="modal-body">
              <h5><em class="text-primary wallet-balance" >Wallet Balance: ₦ 50,000.00</em></h5>
              <?php
              $attr = array('id' => 'credit-user-form');
              echo form_open('sabicapital/index/admin/credit_user',$attr);
              ?>
                
                <div class="form-group">
                  <label for="amount">Amount: </label>
                  <input type="number" id="amount" name="amount" class="form-control" value="" step="any">
                  <span class="form-error"></span>
                </div>
                <input type="submit" class="btn btn-primary">
              </form>
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal" onclick="closeCreditUserModal(this,event)">Close</button>
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade" data-backdrop="static" id="perform-function-on-user-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title text-center" style="text-transform: capitalize;">Choose Action To Perform On</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body" id="modal-body">
             
              <div class="table-responsive">
                <table class="table table-test table-striped table-bordered nowrap hover display" id="full-user-results-table" cellspacing="0" width="100%" style="width:100%">
                
                  <tbody>
                    <tr onclick="editUserProfile(this,event)">
                      <td>1.</td>
                      <td class="text-primary">Edit Users Profile</td>
                    </tr>
                    <tr onclick="deactivateUser(this,event)">
                      <td>2.</td>
                      <td class="text-primary activate-deactive-item">Deactivate User</td>
                    </tr>
                    <tr onclick="creditUsersWallet(this,event)">
                      <td>3.</td>
                      <td class="text-primary">Credit Users Wallet</td>
                    </tr>
                    <tr onclick="debitUsersWallet(this,event)">
                      <td>4.</td>
                      <td class="text-primary">Debit Users Wallet</td>
                    </tr>
                    <tr onclick="viewUsersDownline(this,event)">
                      <td>5.</td>
                      <td class="text-primary">View Users Downline</td>
                    </tr>
                  </tbody>
                </table>
              </div>

            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
            </div>
          </div>
        </div>
      </div>
     
           
          </div>
        </div>
      <footer class="footer">
        <div class="container-fluid">
          <footer></footer>
        </div>
      </footer>
      
      <script>
        $(document).ready(function () {
          $("#debit-user-form").submit(function (evt) {
            evt.preventDefault();
            var me = $(this);
            swal({
              title: 'Warning',
              text: "Are You Sure You Want To Debit User?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes Proceed!',
              cancelButtonText : "No"
            }).then(function(){
              
              var url = me.attr("action");
              var form_data = me.serializeArray();

              form_data = form_data.concat({
                "name" : "user_id",
                "value" : global_user_id
              })
              console.log(form_data)
              $(".spinner-overlay").show();

              $.ajax({
                url : url,
                type : "POST",
                responseType : "json",
                dataType : "json",
                data : form_data,
                success : function (response) {
                  $(".spinner-overlay").hide();
                  
                  if(response.success){
                    
                    $.notify({
                      message:"User Debit Successfully"
                    },{
                      type : "success"  
                    });
                    setTimeout(function () {
                      document.location.reload();
                    }, 1000);
                  }else if(response.max){

                    swal({
                      title: 'Ooops',
                      text: "This Users Walle Balance Is " + response.wallet_balance.toFixed(2) + ". You Cannot Debit Him Beyond This.",
                      type: 'error',                              
                    })
                  }else{
                    $.each(response.messages, function (key,value) {

                      var element = $('#'+key);
                      
                      element.closest('div.form-group')
                              
                              .find('.form-error').remove();
                      element.after(value);
                      
                    });

                    $.notify({
                      message:"Some Values Where Not Valid. Please Enter Valid Values"
                    },{
                      type : "warning"  
                    });
                  }
                },error : function () {
                  $(".spinner-overlay").hide();
                  swal({
                    title: 'Ooops',
                    text: "Something Went Wrong. Please Check Your Internet Connection",
                    type: 'error',                              
                  })
                }
              });
            });
          })

          $("#credit-user-form").submit(function (evt) {
            evt.preventDefault();
            var me = $(this);
            swal({
              title: 'Warning',
              text: "Are You Sure You Want To Credit User?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes Proceed!',
              cancelButtonText : "No"
            }).then(function(){
              
              var url = me.attr("action");
              var form_data = me.serializeArray();

              form_data = form_data.concat({
                "name" : "user_id",
                "value" : global_user_id
              })
              console.log(form_data)
              $(".spinner-overlay").show();

              $.ajax({
                url : url,
                type : "POST",
                responseType : "json",
                dataType : "json",
                data : form_data,
                success : function (response) {
                  $(".spinner-overlay").hide();
                  
                  if(response.success){
                    
                    $.notify({
                      message:"User Credited Successfully"
                    },{
                      type : "success"  
                    });
                    setTimeout(function () {
                      document.location.reload();
                    }, 1000);
                  }else{
                    $.each(response.messages, function (key,value) {

                      var element = $('#'+key);
                      
                      element.closest('div.form-group')
                              
                              .find('.form-error').remove();
                      element.after(value);
                      
                    });

                    $.notify({
                      message:"Some Values Where Not Valid. Please Enter Valid Values"
                    },{
                      type : "warning"  
                    });
                  }
                },error : function () {
                  $(".spinner-overlay").hide();
                  swal({
                    title: 'Ooops',
                    text: "Something Went Wrong. Please Check Your Internet Connection",
                    type: 'error',                              
                  })
                }
              });
            });
          })

          $("#edit-user-profile-form").submit(function (evt) {
            evt.preventDefault();
            var me = $(this);
            var url = me.attr("action");
            var form_data = me.serializeArray();

            form_data = form_data.concat({
              "name" : "user_id",
              "value" : global_user_id
            })
            console.log(form_data)
            $(".spinner-overlay").show();

            $.ajax({
              url : url,
              type : "POST",
              responseType : "json",
              dataType : "json",
              data : form_data,
              success : function (response) {
                $(".spinner-overlay").hide();
                
                if(response.success){
                  me.find(".form-error").html("");
                  $.notify({
                    message:"Profile Edited Successfully"
                  },{
                    type : "success"  
                  });
                }else{
                  $.each(response.messages, function (key,value) {

                    var element = $('#'+key);
                    
                    element.closest('div.form-group')
                            
                            .find('.form-error').remove();
                    element.after(value);
                    
                  });

                  $.notify({
                    message:"Some Values Where Not Valid. Please Enter Valid Values"
                  },{
                    type : "warning"  
                  });
                }
              },error : function () {
                $(".spinner-overlay").hide();
                swal({
                  title: 'Ooops',
                  text: "Something Went Wrong. Please Check Your Internet Connection",
                  type: 'error',                              
                })
              }
            });

          })

          $("#main-card #filter-rows-form").submit(function (evt) {
            evt.preventDefault()
            var me  = $(this)
            var form_data = me.serializeArray()
            console.log(form_data)
            // var full_name = me.find("#full_name").val()
            var full_name = me.find("#full_name").val()
            var user_name = me.find("#user_name").val()
            var phone = me.find("#phone").val()
            var email = me.find("#email").val()
            var created_date = me.find("#created_date").val()

            
            var url = "<?php echo site_url('sabicapital/index/'.$addition.'/'.$second_addition); ?>?full_name="+full_name+"&user_name="+user_name+"&phone="+phone+"&email="+email+"&created_date="+created_date;
            

            window.location.assign(url)
          })

          $("#main-card #clear-filter-rows-form").click(function(evt){
            var me = $(this);
            $("#main-card #filter-rows-form input").val("")
            
          })

        })
        
      </script>
    </div>
  </div>
  <!--   Core JS Files   -->
 