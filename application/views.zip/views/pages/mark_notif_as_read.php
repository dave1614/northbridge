         <!-- End Navbar -->
      <style>
        .sum{
          font-style: italic;
        }

        .settings-table tr{
          cursor: pointer;
        }
      </style>
      <script>
         function addCommas(nStr)
          {
              nStr += '';
              x = nStr.split('.');
              x1 = x[0];
              x2 = x.length > 1 ? '.' + x[1] : '';
              var rgx = /(\d+)(\d{3})/;
              while (rgx.test(x1)) {
                  x1 = x1.replace(rgx, '$1' + ',' + '$2');
              }
              return x1 + x2;
          }

          function withdrawFunds(elem) {
            $("#withdraw-funds-modal").modal({
              "show" : true,
              "backdrop" : false,
              "keyboard" : false
            })
          }

          function reloadPage (elem) {
            document.location.reload(); 
          }

          function openAdminSettings(elem) {
            $("#admin-info-card").hide("slow");
            $("#notif-settings-card").show("slow");
            $("#submit-settings").show("slow");
          }

          function goDefault () {
            $("#admin-info-card").show("slow");
            $("#notif-settings-card").hide("slow");
            $("#submit-settings").hide("slow");
          }
      </script>
      <div class="spinner-overlay" style="display: none;">
        <div class="spinner-well">
          <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading...">
        </div>
      </div>
      <div class="content">
        <p>Loading...</p>
      </div>
     
           
          </div>
        </div>
      <footer class="footer">
        <div class="container-fluid">
          <footer></footer>
        </div>
      </footer>
      
      <script>
        $(document).ready(function () {
          $(".spinner-overlay").show();
          var id = <?php echo $_GET['id']; ?>;
          var callback_url = "<?php echo $_GET['callback_url']; ?>";
          var url = "<?php echo site_url('meetglobal/mark_notif_as_read_notif') ?>";
          
          $.ajax({
            type : "POST",
            dataType : "json",
            responseType : "json",
            url : url,
            data : {
              "id" : id
            },
            success : function (response) {
              console.log(response);
              if(response.success){
                window.location.assign(callback_url);
              }else{
                window.location.assign("<?php echo site_url('meetglobal/') ?>");
              }
            },
            error : function () {
              window.location.assign("<?php echo site_url('meetglobal/') ?>");
            }
          });  
        })
        
      </script>
    </div>
  </div>
  <!--   Core JS Files   -->
 