<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Processing Payment To Become A Center Leader</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/vendor/bootstrap/css/bootstrap.min.css'); ?>">
</head>
<body>
	<?php if($success){ ?>
	<p>Processing Payment To Become A Center Leader... Please Do Not Reload Or Leave This Page</p>
	<?php }else{ ?>
	<p>Something Went Wrong ... Please Reload This Page</p>
	<?php } ?>
	<script src="<?php echo base_url('assets/vendor/jquery/jquery-3.2.1.min.js');?>"></script>
	<script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>
	<script src="<?php echo base_url('assets/js/bootstrap-notify.js')?> "></script>
	<script src="<?php echo base_url('assets/js/sweetalert2.all.min.js') ?>"></script>
	<script src="<?php echo base_url('assets/js/sweetalert2.min.js') ?>"></script>
	<script src="<?php echo base_url('assets/js/swal-forms.js') ?>"></script>
	<script>
		window.onbeforeunload = function() {
            return "If You Reload Or Leave This Page You Could Lose Your Money!";
        }
		$(document).ready(function () {
			var url = "<?php echo site_url('meetglobal/index/verify_content_leader_payment/'.'?reference='.$_GET['reference']) ?>";
			

	        $.ajax({
	            url : url,
	            type : "POST",
	            responseType : "json",
	            dataType : "json",
	            data : "",
	            success : function (response) {
	                if(response.success){
	                	window.location.assign(response.url);
	                }else{
	                	$.notify({
	                      message:"Sorry Something Went Wrong. Please Reload This Page"
	                      },{
	                        type : "warning"  
	                      });
	                }
	            },error : function () {
	            	$.notify({
	                  message:"Sorry Something Went Wrong. Please Reload This Page"
	                  },{
	                    type : "danger"  
	                  });
	            }   
	        }); 
		})
	</script>
</body>
</html>