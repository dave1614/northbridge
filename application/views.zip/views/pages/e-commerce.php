         <!-- End Navbar -->
<style>
tr{
  cursor: pointer;
}
</style>
<script>

</script>

<div class="spinner-overlay" style="display: none;">
  <div class="spinner-well">
    <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading...">
  </div>
</div>
<div class="content">
  <div class="container-fluid">
    <section id="services">
      <h2 class="text-center sub-head" style="">E-commerce</h2>
      

      <div class="card" id="choose-action-card">
        <div class="card-header">
          
          <h3 class="card-title">Choose E-commerce Platform: </h3>
        </div>
        <div class="card-body">
          <div class="container">
            <div class="row">

              <div class="card col-sm-2" style="padding: 0; cursor: pointer;" onclick="selectedAirtimeOperator(this,event)">
                <div class="card-body" style="padding: 0;">
                  <a href="http://www.konga.com?k_id=MeetGlobal" target="_blank">
                    <img src="<?php echo base_url('assets/images/konga-logo.jpg') ?>" style="width: 100%; height: 160px;" alt="Konga">
                    <div class="" style="margin-top: 10px;">
                      <h4 class="text-center" style="font-size: 20px; font-weight: bold; color: #000;">Konga</h4>
                    </div>
                  </a>
                </div>
              </div>

              <div class="offset-sm-1">
    
              </div>
              

              <div class="card col-sm-2" style="padding: 0; cursor: pointer;">
                <div class="card-body" style="padding: 0;">
                  <a href="https://c.jumia.io/?a=176180&c=11&p=r&E=kkYNyk2M4sk%3D&ckmrdr=https%3A%2F%2Fjumia.com.ng&utm_campaign=176180" target="_blank">
                    <img src="<?php echo base_url('assets/images/jumia-logo.jpg') ?>" style="width: 100%; height: 160px;" alt="Jumia">
                    <div class="" style="margin-top: 10px;">
                      <h4 class="text-center" style="font-size: 20px; font-weight: bold; color: #000;">Jumia</h4>
                    </div>
                  </a>
                </div>
              </div>

              <div class="offset-sm-1">
    
              </div>
              

              <div class="card col-sm-2" style="padding: 0; cursor: pointer;">
                <div class="card-body" style="padding: 0;">
                  <a href="https://alibaba.com/?spm=a2706.8172434.mod-side-menu.1.3b29284fFcRmN7" target="_blank">
                    <img src="<?php echo base_url('assets/images/alibaba-logo.png') ?>" style="width: 100%; height: 160px;" alt="Alibaba">
                    <div class="" style="margin-top: 10px;">
                      <h4 class="text-center" style="font-size: 20px; font-weight: bold; color: #000;">Alibaba</h4>
                    </div>
                  </a>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <div id="submit-become-center-leader-form-btn" onclick="submitBecomeCenterLeaderForm(this,event)" rel="tooltip" data-toggle="tooltip" title="Submit The Form" style="background: #9c27b0; cursor: pointer; position: fixed; bottom: 0; right: 0;  border-radius: 50%; cursor: pointer; display: none; fill: #fff; height: 56px; outline: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.2);">
    <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
      <i class="fas fa-paper-plane" style="font-size: 25px; font-weight: normal; color: #fff;" aria-hidden="true"></i>
    </div>
  </div>
</div>
<footer class="footer">
  <div class="container-fluid">
    <!-- <footer>&copy; <?php echo date("Y"); ?> Copyright (meetglobal Issues Global Limited). All Rights Reserved</footer> -->
  </div>
</footer>

<script>
  $(document).ready(function () {
    $(".my-select").selectpicker();
    $("#become-center-leader-form").submit(function (evt) {
      evt.preventDefault();
      var me = $(this);
      var url = me.attr("action");
      var form_data = me.serializeArray();

      var terms_selected = me.find("#terms_checkbox").prop("checked");
      if(terms_selected){
        form_data = form_data.concat({
          "name" : "terms_checkbox",
          "value" : true
        })
        $(".spinner-overlay").show();
        console.log(form_data)
        $.ajax({
          url : url,
          type : "POST",
          responseType : "json",
          dataType : "json",
          data : form_data,
          success : function (response) {
            console.log(response)
            $(".spinner-overlay").hide();
            if(response.success && response.url != ""){
              $.notify({
              message:"Form Submitted Successfully. Proceeding To Payment Page"
              },{
                type : "success"  
              });
              setTimeout(function () {
                window.location.assign(url);
              }, 2000);
            }else if(!response.terms_selected){ 
              swal({
                title: 'Error',
                text: "You Need To Agree To Terms And Conditions To Proceed",
                type: 'error',                                          
              })
            }else{
              $.each(response.messages, function (key,value) {

              var element = me.find("#"+key);
              
              element.closest('div.form-group')
                      
                      .find('.form-error').remove();
              element.after(value);
              
             });
              $.notify({
              message:"Some Values Where Not Valid. Please Enter Valid Values"
              },{
                type : "warning"  
              });
            }
          },error : function () {
            $(".spinner-overlay").hide();
            swal({
              title: 'Ooops',
              text: "Something Went Wrong",
              type: 'error'
            })
          } 
        }); 
      }else{
        swal({
          title: 'Error',
          text: "You Need To Agree To Terms And Conditions To Proceed",
          type: 'error',                                          
        })
      }
    })
  })
</script>
</div>
</div>
  <!--   Core JS Files   -->
 