         <!-- End Navbar -->
      <style>
        .sum{
          font-style: italic;
        }

        .settings-table tr{
          cursor: pointer;
        }
      </style>
      <script>
         function addCommas(nStr)
          {
              nStr += '';
              x = nStr.split('.');
              x1 = x[0];
              x2 = x.length > 1 ? '.' + x[1] : '';
              var rgx = /(\d+)(\d{3})/;
              while (rgx.test(x1)) {
                  x1 = x1.replace(rgx, '$1' + ',' + '$2');
              }
              return x1 + x2;
          }

          function withdrawFunds(elem) {
            $("#withdraw-funds-modal").modal({
              "show" : true,
              "backdrop" : false,
              "keyboard" : false
            })
          }

          function reloadPage (elem) {
            document.location.reload(); 
          }

          function openAdminSettings(elem) {
            $("#admin-info-card").hide("slow");
            $("#notif-settings-card").show("slow");
            $("#submit-settings").show("slow");
          }

          function goDefault () {
            $("#admin-info-card").show("slow");
            $("#notif-settings-card").hide("slow");
            $("#submit-settings").hide("slow");
          }
      </script>
      <div class="content">
        <div class="container-fluid">
          <div class="spinner-overlay" style="display: none;">
            <div class="spinner-well">
              <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading..." style="">
            </div>
          </div>
          <h2>Admin Info</h2>
          <div class="row justify-content-center">
            <div class="col-sm-10">
              <div class="card" id="admin-info-card">
                <div class="card-header">
                  <h3 class="card-title">All Info</h3>
                </div>
                <div class="card-body">
                  <div class="wrap">
                    <p class="text-capital">Total No. Of Registered Users: <span class="sum text-primary"><?php echo $this->meetglobal_model->getTotalNoOfRrgisteredUsers(); ?></span></p>
                    <p class="text-capital">Total Subscribed Accounts: <span class="sum text-primary"><?php echo $this->meetglobal_model->getTotalNoOfAccountsSubscribed(); ?></span></p>
                    <p class="text-capital">Total No. Of Recycles: <span class="sum text-primary"> New Ambassador: <b><?php echo $this->meetglobal_model->getTotalNoOfRecycles("new_nigeria"); ?></b><br>
                        
                          Great Ambassador: <b><?php echo $this->meetglobal_model->getTotalNoOfRecycles("great_nigeria"); ?></b></span></p>
                    <p class="text-capital">Total System Sponsor Bonus: <span class="sum text-primary"><?php echo "₦ " . $this->meetglobal_model->getTotalSystemBonus(); ?></span></p>
                    <p class="text-capital">System Sponsor Bonus: <span class="sum text-primary"><?php echo "₦ " . $this->meetglobal_model->getSystemBonus(); ?></span></p>
                    <p class="text-capital">Automatic Recycle Bonus: <span class="sum text-primary"><?php echo "₦ " . $this->meetglobal_model->getAutomaticRecycleSystemBonus(); ?></span></p>
                    <p class="text-capital">Total System Income: <span class="sum text-primary"><?php echo "₦ " . $this->meetglobal_model->getTotalSystemIncome(); ?></span></p>
                    <p class="text-capital">Total Users Income: <span class="sum text-primary"><?php echo "₦ " . $this->meetglobal_model->getTotalUsersIncome(); ?></span></p>
                    <p class="text-capital">Total Amount Withdrawn By The Users: <span class="sum text-primary"><?php echo "₦ " . $this->meetglobal_model->getTotalUsersWithdrawn(); ?></span></p>
                    <p class="text-capital">Users Money In The System: <span class="sum text-primary"><?php echo "₦ " . $this->meetglobal_model->getUsersMoneyInSystem(); ?></span></p>
                  </div>
                  <button class="btn btn-primary" onclick="openAdminSettings(this)">Admin Settings</button>
                </div>
              </div>
              <div class="card" id="notif-settings-card" style="display: none;">
                <div class="card-header">
                  <button onclick="goDefault()" class="btn btn-warning">Go Back</button>
                  <h4 class="card-title">Notifications</h4>
                  <h6>Let Users View Notifications From Users You Are following</h6>
                </div>
                <div class="card-body">
                  
                    <table class="table table-test dt-responsive nowrap hover display settings-table" cellspacing="0" width="100%" style="width:100%">
                      <thead style="display: none;">
                        <tr>
                          <th>Setting</th>
                          <th>CheckBox</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>SMS Notifications</td>
                          <td>
                            <div class="form-check text-right">
                                <label class="form-check-label">
                                    <input class="form-check-input" name="admin_sms_enabled" id="sms-notif" <?php if($this->meetglobal_model->checkIfSmsNotifIsEnabled()){ echo "checked"; } ?> type="checkbox" value="">
                                    <!-- Option one is this and that&mdash;be sure to include why it's great -->
                                    <span class="form-check-sign">
                                        <span class="check"></span>
                                    </span>
                                </label>
                            </div>
                          </td>
                        </tr>
                        
                        <tr>
                          <td>Email Notifications</td>
                          <td>
                            <div class="form-check text-right">
                                <label class="form-check-label">
                                    <input class="form-check-input" <?php if($this->meetglobal_model->checkIfEmailNotifIsEnabled()){ echo "checked"; } ?>  name="admin_email_enabled" id="email-notif" type="checkbox" value="">
                                    <!-- Option one is this and that&mdash;be sure to include why it's great -->
                                    <span class="form-check-sign">
                                        <span class="check"></span>
                                    </span>
                                </label>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>  
                </div>
              </div>
            </div>


            <div rel="tooltip" data-toggle="tooltip" title="Save Settings" id="submit-settings" style="display: none; cursor: pointer; position: fixed; bottom: 0; right: 0; background: #9124a3; border-radius: 50%; cursor: pointer; fill: #fff; height: 56px; outline: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.2);">
              <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
                <i class="fas fa-save" style="font-size: 25px; font-weight: normal; color: #fff;" aria-hidden="true"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
     
           
          </div>
        </div>
      <footer class="footer">
        <div class="container-fluid">
          <footer></footer>
        </div>
      </footer>
      
      <script>
        $(document).ready(function () {
          $("#info-table").DataTable();
          $("#submit-settings").click(function(event) {
            swal({
                title: 'Choose Action',
                html: "Are You Sure You Want To Proceed?",
                type: 'success',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes',
                cancelButtonText : "No"
            }).then(function(){
              var form_data = {};
              var checkedState = false;
              var name = '';

              $(".settings-table").each(function(index, el) {
                // console.log($(this).find('tbody tr').length)
                $(this).find('tbody tr input').each(function(index, el) {
                  if($(this).is(':checked')){
                    checkedState = true;
                  }else{
                    checkedState = false;
                  }
                  name = $(this).attr('name');
                  form_data[name] = checkedState;
                });
              });
              form_data['admin'] = true;
              console.log(form_data);

              var url = "<?php echo site_url('meetglobal/save_settings') ?>";
              
              $.ajax({
                type : "POST",
                dataType : "json",
                responseType : "json",
                url : url,
                data : form_data,
                success : function (response) {
                  console.log(response);
                  if(response.success == true){
                    $.notify({
                      message:"Settings Changed Successfully"
                    },{
                        type : "success"  
                    });
                  }else{
                    $.notify({
                      message:"Something Went Wrong"
                    },{
                        type : "warning"  
                    });
                  }
                },error : function(){
                  $.notify({
                      message:"Something Went Wrong Check Your Internet Connection"
                    },{
                        type : "danger"  
                    });
                }
              }); 
            });
          });

          $(".settings-table tbody tr").click(function(){
            var checkBox = $(this).find('input');
            if(checkBox.is(':checked')){
              checkBox.prop('checked', false);
            }else{
             checkBox.prop('checked', true); 
            }
          });
        })
        
      </script>
    </div>
  </div>
  <!--   Core JS Files   -->
 