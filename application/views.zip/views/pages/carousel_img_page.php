
<style>
  img{
    width: 100%;
    height: 350px;
  }

  .carousel-img-content #carousel-img-text{
    color: #7ea960;
    margin-top: 50px;
  }
  
  .carousel-img-content #carousel-img-heading{
    color: #7ea960;
    font-weight: bolder;
    font-size: 35px;
  }

  .carousel-img-content{
    margin-top: 35px;
  }
  
  #account-manager-form{
    margin-top: 30px;
    margin-bottom: 30px;
  }

  #account-manager-form label{
    color: #7ea960;
  }
  .btn.btn-primary:focus,
  .btn.btn-primary:active,
  .btn.btn-primary:hover{
    color: #7ea960;
    background-color: #fff;
    border-color: #7ea960;
  }

  #submit-button:hover {
    background-image:none;
   }

  .btn.btn-primary{
    color: #fff;
    background-color: #7ea960;
    border-color: #7ea960;
    transition: 2s;
  }

  
</style>
<script>
  function openTermsAndConditionsModal (elem,evt) {
    console.log('heheh')
    $("#terms-and-conditions-modal").modal("show");
    
  }
</script>
<!-- Page Content -->
  <div class="" style="min-height: 400px;">
    <div class="container-fluid">
      
      <div class="carousel-img-div">
        <?php
        $pos = $_GET['pos'];
        
        
        if($pos == 1){
        ?>  
        <img src="<?php echo base_url('assets/images/Office1.PNG') ?>" alt=""> 
        <?php
        }else if($pos == 2){
        ?>
        <img src="<?php echo base_url('assets/images/Meeting edit.PNG') ?>" alt="">
        <?php 
        }else if($pos == 3){
        ?>
        <img src="<?php echo base_url('assets/images/contest2.PNG') ?>" alt="">
        <?php
        }else if($pos == 4){
        ?>
        <img src="<?php echo base_url('assets/images/sabi manager.PNG') ?>" alt="">
        <?php
        }else if($pos == 5){
        ?>
        <img src="<?php echo base_url('assets/images/TOOLS.PNG') ?>" alt="">
        <?php
        }
        ?>
              
      </div>

      <div class="carousel-img-content">
        <?php
        $pos = $_GET['pos'];
        
        
        if($pos == 1){
        ?>  
        <h3 class="text-center " style="text-transform: capitalize;" id="carousel-img-heading">Lorem ipsum dolor sit amet</h3>
        <div class="border-bottom-first-container" >
          <div class="border-bottom-second-container" >
            <span class="border-bottom-green text-center"></span>
          </div>
        </div>

        <p class="text-center" id="carousel-img-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        <?php
        }else if($pos == 2){
        ?>
        <h3 class="text-center " style="text-transform: capitalize;" id="carousel-img-heading">Sabi Traders Meeting</h3>
        <div class="border-bottom-first-container" >
          <div class="border-bottom-second-container" >
            <span class="border-bottom-green text-center"></span>
          </div>
        </div>

        <p class="text-center" id="carousel-img-text">At Sabi Capital monthlyTrader's Meeting you will learn new things, meet fellow traders, share experiences, and stand amazing prizes. 
        Register for the next SCTM here.
        </p>

        <div class="container">
          <div class="row justify-content-center">
            <div class="col-sm-6 shadow-sm">
              <?php
              $attr = array('id' => 'account-manager-form');
              echo form_open('',$attr);
              ?>
                <div class="form-group">
                  <label for="full_name">Full Name: </label>
                  <input type="text" id="full_name" name="full_name" class="form-control">
                </div>
                <div class="form-group">
                  <label for="phone_number">Phone Number: </label>
                  <input type="number" id="phone_number" name="phone_number" class="form-control">
                </div>
                <input id="submit-button" type="submit" class="btn btn-primary col-12">
              </form>
            </div>
          </div>
        </div>
        <?php 
        }else if($pos == 3){
        ?>
        <h3 class="text-center " style="text-transform: capitalize;" id="carousel-img-heading">Sabi Contest</h3>
        <div class="border-bottom-first-container" >
          <div class="border-bottom-second-container" >
            <span class="border-bottom-green text-center"></span>
          </div>
        </div>

        <p class="text-center" id="carousel-img-text">As an active client of Sabi Capital, we are pleased to invite you to participate in any of our follow contest and stand the chance to win some  amazing prizes. <br> <br>

        No contest is running at the moment. <br>
        You will be informed of a new contest.</p>
        <?php
        }else if($pos == 4){
        ?>
        <h3 class="text-center " style="text-transform: capitalize;" id="carousel-img-heading">Sabi Account Manager</h3>
        <div class="border-bottom-first-container" >
          <div class="border-bottom-second-container" >
            <span class="border-bottom-green text-center"></span>
          </div>
        </div>

        <p class="text-center" id="carousel-img-text">It doesn't matter how busy you may be or maybe you don't have the  trading knowledge, you can still make  extra income through forex business. Let Sabi Experts to for you and share profit monthly. To start, fill the form below: </p>
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-sm-6">
              <?php
              $attr = array('id' => 'account-manager-form');
              echo form_open('',$attr);
              ?>
                <div class="form-group">
                  <label for="full_name">Full Name: </label>
                  <input type="text" id="full_name" name="full_name" class="form-control">
                </div>
                <div class="form-group">
                  <label for="phone_number">Phone Number: </label>
                  <input type="number" id="phone_number" name="phone_number" class="form-control">
                </div>
                <div class="form-group">
                  <label for="sfx_account_number">Sfx account number: </label>
                  <input type="number" id="sfx_account_number" name="sfx_account_number" class="form-control">
                </div>
                <div class="form-group">
                  <label for="start_capital">Start Capital: </label>
                  <input type="number" id="start_capital" name="start_capital" class="form-control">
                </div>
                <div class="form-group">
                  <label for="date">Date: </label>
                  <input type="date" id="date" name="date" class="form-control">
                </div>
                <div class="form-group">
                  <label for="email">Email: </label>
                  <input type="email" id="email" name="email" class="form-control">
                </div>
                <div class="form-check" style="margin-bottom: 10px;">
                  <input type="checkbox" class="form-check-input" id="terms-checkbox" value="">
                  <label class="form-check-label" style="color: #7ea960;">
                    By Submitting This Form, You Agree To Our <span onclick="openTermsAndConditionsModal(this,event)" style="color: #3333CC; cursor: pointer;">Terms And Conditions</span>
                  </label>
                </div>

                <input id="submit-button" type="submit" class="btn btn-primary col-12">
              </form>
            </div>
          </div>
        </div>
        <?php
        }else if($pos == 5){
        ?>
        <h3 class="text-center " style="text-transform: capitalize;" id="carousel-img-heading">Sabi Tools</h3>
        <div class="border-bottom-first-container" >
          <div class="border-bottom-second-container" >
            <span class="border-bottom-green text-center"></span>
          </div>
        </div>

        <p class="text-center" id="carousel-img-text">At Sabi Capital we understand that to trade profitably a trader must aquire skills through the use of some special tools, that's why we at the Sabi Capital we provides you with some special tools which includes:
        Sabi Trading Signals and Academy.
        Click here to get Sabi tools.</p>
        <?php
        }else if($pos == 6){
        ?>
        <h3 class="text-center " style="text-transform: capitalize;" id="carousel-img-heading">Business/Opportunities</h3>
        <div class="border-bottom-first-container" >
          <div class="border-bottom-second-container" >
            <span class="border-bottom-green text-center"></span>
          </div>
        </div>

        <p  id="carousel-img-text">Welcome to Sabi Capital Business section.
        Because you are here we want to introduce you to the Sabi Capital Business opportunities, with our business modules you can start earning daily cash from the forex without trading with your hard earned money. <br> <br> How it works <br> <br>
        Simply refer a friend to start using any of Sabi Capital money services and you will always smile to the bank. <br>
        Make up to $1000 monthly. <br>
        Register to get your referral link.</p>
        <?php
        }
        ?>
      </div>
    </div>
  </div>

  <div class="modal fade" data-backdrop="static" id="terms-and-conditions-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title text-center" style="color: #7ea960; text-transform: capitalize;">SABI Manager's terms of contract.</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" id="modal-body">
          <p style="color: #7ea960; font-size: 15px;">Note that Trading the online forex market can bring some financial losses. This means that you can lose part or your entire investment, therefore you are advised to trade with your risk capital. <br><br><br>

          Kindly be informed that no staff of Sabi Capital Ltd will be held responsible in case of any loss of your deposit.
          Sabi Account Manager do not promise any guaranteed return/profit  on your deposited capital at any time.<br><br><br>

          Sabi Account Manager only manages the forex account which is only registered and funded via www.sabicapital.com<br><br><br>

          The generated profits during the trading done on the client's forex account will be shared  50/50 between the Sabi Capital Ltd and the client monthly.<br><br><br>

          When fund is deposited and linked to Sabi manager's trading account, such deposited fund can not be withdrawn till minimum of 30 Trading days.</p>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
        </div>
      </div>
    </div>
  </div>

  <script>
    $(document).ready(function () {
      $("#account-manager-form").submit(function (evt) {
        evt.preventDefault();
        var me = $(this);
        var form_data = me.serializeArray();
        var terms_checkbox = me.find("#terms-checkbox");
        var terms_checkbox_ischecked = terms_checkbox.prop("checked");
        if(terms_checkbox_ischecked){
          form_data.push({
            "name" : "terms_checkbox",
            "value" : terms_checkbox_ischecked
          })
          console.log(form_data)
        }else{
          swal({
            title: 'Ooops',
            text: "You Need To Check The Checkbox To Proceed",
            type: 'error'
          })
        }
        
      })
    })
  </script>