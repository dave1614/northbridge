         <!-- End Navbar -->
      <style>
        tr{
          cursor: pointer;
        }
      </style>
      <script>
        var amount_to_withdraw = 200;
        var account_name = "";
        var transfer_amount = 0;
        var transfer_phone_number = "";
        var transfer_phone_code = "";
        var recepient_id = "";
        var recepients_full_name = "";


         function addCommas(nStr)
          {
              nStr += '';
              x = nStr.split('.');
              x1 = x[0];
              x2 = x.length > 1 ? '.' + x[1] : '';
              var rgx = /(\d+)(\d{3})/;
              while (rgx.test(x1)) {
                  x1 = x1.replace(rgx, '$1' + ',' + '$2');
              }
              return x1 + x2;
          }

          function withdrawFunds(elem) {
            var url = "<?php echo site_url('meetglobal/get_forms_for_funds_withdrawal') ?>";
            var form_data = {
              show_records : true
            };
            $(".spinner-overlay").show();
            $.ajax({
              type : "POST",
              dataType : "json",
              responseType : "json",
              url : url,
              data : form_data,
              success : function (response) {
                $(".spinner-overlay").hide();
                console.log(response)
                if(response.success == true && response.messages != ""){
                  var messages = response.messages;
                  $("#withdraw-funds-modal .modal-body").html(messages);
                  $("#withdraw-funds-modal #bank-details-form #bank_name").selectpicker();
                  $("#withdraw-funds-modal .modal-title").html("Enter Account Details");
                  $("#withdraw-funds-modal").modal("show");
                }else{
                  swal({
                    title: 'Error!',
                    text: "Something Went Wrong.",
                    type: 'error'
                  })
                }
              },error : function () {
                $(".spinner-overlay").hide();
                swal({
                  title: 'Error!',
                  text: "Something Went Wrong. Please Check Your Internet Connection",
                  type: 'error'
                })
              } 
            });   
            
          }

          function reloadPage (elem) {
            document.location.reload(); 
          }

          function creditAccount (elem) {
            swal({
              title: 'Choose Action: ',
              text: "Do You Want To: ",
              type: 'question',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#4caf50',
              confirmButtonText: 'Credit Your Wallet',
              cancelButtonText : "View Account Credit History"
            }).then(function(){
              $("#credit-wallet-modal").modal({
                  "show" : true
              })
            }, function(dismiss){
               if(dismiss == 'cancel'){
                   // function when cancel button is clicked
                var form_data = {
                  show_records : true
                }   
                var url = "<?php echo site_url('meetglobal/index/view_account_credit_history'); ?>";
                $(".spinner-overlay").show();
                $.ajax({
                  type : "POST",
                  dataType : "json",
                  responseType : "json",
                  url : url,
                  data : form_data,
                  success : function (response) {
                    $(".spinner-overlay").hide();
                    console.log(response)
                    if(response.success == true && response.messages !== ""){
                      var messages = response.messages;
                      $("#account-credit-history-card .card-body").html(messages);
                      $("#account-credit-history-card #account-credit-history-table").DataTable();
                      $("#main-card").hide();
                      $("#account-credit-history-card").show();
                    }else{
                      $.notify({
                      message:"Sorry Something Went Wrong"
                      },{
                        type : "warning"  
                      });
                    }
                  },error : function () {
                    $(".spinner-overlay").hide();
                    $.notify({
                    message:"Sorry Something Went Wrong Please Check Your Internet Connection"
                    },{
                      type : "danger"  
                    });
                  } 
                });
               }
            });    
            
          }

          function viewTransferRecords (elem,evt) {
            var form_data = {
              show_records : true
            }   
            var url = "<?php echo site_url('meetglobal/index/view_account_transfer_history'); ?>";
            $(".spinner-overlay").show();
            $.ajax({
              type : "POST",
              dataType : "json",
              responseType : "json",
              url : url,
              data : form_data,
              success : function (response) {
                $(".spinner-overlay").hide();
                console.log(response)
                if(response.success == true && response.messages !== ""){
                  var messages = response.messages;
                  $("#account-transfer-history-card .card-body").html(messages);
                  $("#account-transfer-history-card #account-transfer-history-table").DataTable();
                  $("#transfer-funds-card").hide();
                  $("#account-transfer-history-card").show();
                }else{
                  $.notify({
                  message:"Sorry Something Went Wrong"
                  },{
                    type : "warning"  
                  });
                }
              },error : function () {
                $(".spinner-overlay").hide();
                $.notify({
                message:"Sorry Something Went Wrong Please Check Your Internet Connection"
                },{
                  type : "danger"  
                });
              } 
            });
          }

          function goBackFromAccountTransferHistoryCard (elem,evt) {
            $("#transfer-funds-card").show();
            $("#account-transfer-history-card").hide();
          }

          function goBackFromAccountCreditHistoryCard(elem,evt) {
            
            $("#main-card").show();
            $("#account-credit-history-card").hide();
          }

          function submitBankDetailsForm (elem,evt) {
            elem = $(elem);

            evt.preventDefault();
            var me = elem;
            var form_data = me.serializeArray();
            
            console.log(form_data)
            var url = "<?php echo site_url('meetglobal/index/withdraw_funds_cont'); ?>";
            $(".spinner-overlay").show();
            $.ajax({
              type : "POST",
              dataType : "json",
              responseType : "json",
              url : url,
              data : form_data,
              success : function (response) {
                $(".spinner-overlay").hide();
                console.log(response)
                if(response.success == true && response.account_name !== ""){
                  account_name = response.account_name;
                  swal({
                    title: 'Proceed With Withdrawal?',
                    text: "Is This Your Account Name <span class='text-primary' style='font-style: italic;'>" + response.account_name + "</span>?",
                    type: 'success',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes',
                    cancelButtonText : "No"
                  }).then(function(){
                    $("#withdraw-funds-modal #modal-display").html("");
                    me.hide("slow");
                    $("#withdraw-funds-modal #enter-amount-to-withdraw-form").show("slow");
                    $("#withdraw-funds-modal .modal-title").html("Enter Withdrawal Amount To Proceed");
                  }, function(dismiss){
                     if(dismiss == 'cancel'){
                         // function when cancel button is clicked
                         console.log('cancelled');
                     }
                  });    
                }else if(response.invalid_account == true){
                  swal({
                    title: 'Invalid Account Details',
                    text: "Sorry These Account Details Are Not Linked To Any Account",
                    type: 'error',
                    confirmButtonColor: '#3085d6',                    
                    confirmButtonText: 'Ok'                   
                  });
                }else if(response.messages !== ""){
                  $.each(response.messages, function (key,value) {

                  var element = $('#'+key);
                  
                  element.closest('div.form-group')
                          
                          .find('.form-error').remove();
                  element.after(value);
                  
                 });
                  $.notify({
                  message:"Some Values Where Not Valid. Please Enter Valid Values"
                  },{
                    type : "warning"  
                  });
                }else if(response.bouyant == false){
                   swal({
                    title: 'Insuffecient Balance',
                    text: "Sorry You Do Not Have Enough Funds In Your Account To Complete This Transaction",
                    type: 'error',
                    confirmButtonColor: '#3085d6',                    
                    confirmButtonText: 'Ok'                   
                  });
                }else if(response.no_refer == true){
                   swal({
                    title: 'No Referrals',
                    text: "You Need To Sponsor At Least One Ambassador Or One Great Ambassador To Be Eligible For Your First Withdrawal. Each Sponsorship Earns You ₦400 Commission",
                    type: 'error',
                    confirmButtonColor: '#3085d6',                    
                    confirmButtonText: 'Ok'                   
                  });
                }else{
                  $.notify({
                  message:"Sorry Something Went Wrong Please Check Your Internet Connection"
                  },{
                    type : "danger"  
                  });
                }
              },error : function () {
                $(".spinner-overlay").hide();
                $.notify({
                message:"Sorry Something Went Wrong Please Check Your Internet Connection"
                },{
                  type : "danger"  
                });
              } 
            });
          }

          function submitAmountToWithdrawForm (elem,evt) {
            evt.preventDefault();
            elem = $(elem);
            var me = elem;
            amount = elem.find("#amount").val();
            var form_data = elem.serializeArray();
            var url = "<?php echo site_url('meetglobal/index/enter_amount_withdraw_funds'); ?>";
            $(".spinner-overlay").show();
            $.ajax({
              type : "POST",
              dataType : "json",
              responseType : "json",
              url : url,
              data : form_data,
              success : function (response) {
                $(".spinner-overlay").hide();
                console.log(response)
                if(response.success == true && response.code != "" && response.phone_number != ""){
                  var code = "+" + response.code;
                  var phone_number = response.phone_number;
                  swal({
                    title: 'Proceed With Withdrawal?',
                    text: "Are You Sure You Want To Transfer <em class='text-primary'>₦ " + addCommas(amount) + "</em> From Your Meetglobal Account To Bank Account With Account Name <em class='text-primary'>" + account_name + "</em>?",
                    type: 'success',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes',
                    cancelButtonText : "No"
                  }).then(function(){
                    amount_to_withdraw = amount;
                    
                    var form_data = {
                      amount : amount_to_withdraw
                    }
                    var url = "<?php echo site_url('meetglobal/index/send_withdrwal_otp'); ?>";
                    $(".spinner-overlay").show();
                    $.ajax({
                      type : "POST",
                      dataType : "json",
                      responseType : "json",
                      url : url,
                      data : form_data,
                      success : function (response) {
                        $(".spinner-overlay").hide();
                        console.log(response)
                        if(response.success == true && response.messages != "" && response.email != ""){
                          var messages = response.messages;
                          var email = response.email;
                          $("#withdraw-funds-modal .modal-title").html("An OTP Has Been Sent To <em class='text-primary'>"+email+"</em>");
                          $("#withdraw-funds-modal .modal-body").html(messages);
                        }else if(response.not_bouyant){
                          swal({
                            title: 'Error!',
                            text: "Sorry You Do Not Have Enough Funds For The Amount You Want To Transfer. Credit Your Account And Try Again",
                            type: 'error'
                          });
                        }else if(response.too_small){
                          swal({
                            title: 'Error!',
                            text: "Minimum Withdrawable Amount Is ₦200",
                            type: 'error'
                          });
                        }else{
                          swal({
                            title: 'Error!',
                            text: "Sorry Something Went Wrong.",
                            type: 'error'
                          });
                        }
                      },error : function () {
                        $(".spinner-overlay").hide();
                        swal({
                          title: 'Error!',
                          text: "Sorry Something Went Wrong Please Check Your Internet Connection",
                          type: 'error'
                        });
                      } 
                    });
                  }, function(dismiss){
                     if(dismiss == 'cancel'){
                        // function when cancel button is clicked
                        console.log('cancelled');
                     }
                  });    
                }else if(response.not_bouyant){
                  swal({
                    title: 'Error!',
                    text: "Sorry You Do Not Have Enough Funds For The Amount You Want To Transfer. Credit Your Account And Try Again",
                    type: 'error'
                  });
                }else if(response.too_small){
                  swal({
                    title: 'Error!',
                    text: "Minimum Withdrawable Amount Is ₦200",
                    type: 'error'
                  });
                }else{
                  swal({
                    title: 'Error!',
                    text: "Sorry Something Went Wrong.",
                    type: 'error'
                  });
                }
              },error : function () {
                $(".spinner-overlay").hide();
                swal({
                  title: 'Error!',
                  text: "Sorry Something Went Wrong Please Check Your Internet Connection",
                  type: 'error'
                });
              } 
            });
          }

          function withdrawalVerificationCallBack(response) {
            console.log(response);
            if(response.status === "PARTIALLY_AUTHENTICATED") {
              var code = response.code;
              var state = response.state;
              console.log(code)
              var form_data = {
                  code : code,
                  state : state,
                  amount : amount_to_withdraw
              };
              $(".spinner-overlay").show();
              
              var url = "<?php echo site_url('meetglobal/verify_withdrawal_otp') ?>";
              $.ajax({
              type : "POST",
              dataType : "json",
              responseType : "json",
              url : url,
              data : form_data,
              success : function (response) {
                $(".spinner-overlay").hide();
                console.log(response)
                if(response.success == true){
                  swal({
                    title: 'Success!',
                    text: "You Have Successfully Transfered <em class='text-primary'>₦" + addCommas(amount) + "</em> From Your Meetglobal Account To Bank Account With Name <em class='text-primary'>" + account_name + "</em>.",
                    type: 'success'
                  });

                  setTimeout(function () {
                    reloadPage();
                  }, 2000);
                }else if(response.phone_change){
                  swal({
                    title: 'Error',
                    text: "The Phone Number Was Changed! Try Again And Don't Change It",
                    type: 'error',                              
                  })
                }else if(response.not_bouyant){
                  swal({
                    title: 'Error!',
                    text: "Sorry You Do Not Have Enough Funds For The Amount You Want To Transfer. Credit Your Account And Try Again",
                    type: 'error'
                  });
                }else if(response.too_small){
                  swal({
                    title: 'Error!',
                    text: "Minimum Withdrawable Amount Is ₦200",
                    type: 'error'
                  });
                }else{
                  swal({
                    title: 'Error!',
                    text: "Sorry Something Went Wrong.",
                    type: 'error'
                  });
                }
              },error : function () {
                $(".spinner-overlay").hide();
                swal({
                  title: 'Error!',
                  text: "Sorry Something Went Wrong Please Check Your Internet Connection",
                  type: 'error'
                });
              } 
            });
                  
            }
            else if (response.status === "NOT_AUTHENTICATED") {
              // handle authentication failure
              console.log("Authentication failure");
            }
            else if (response.status === "BAD_PARAMS") {
              // handle bad parameters
              console.log("Bad parameters");
            }
          }

          function transferFunds(elem,evt){
            $("#main-card").hide();
            $("#transfer-funds-card").show();
          }

          function goBackFromTransferFundsCard (elem,evt) {
            $("#main-card").show();
            $("#transfer-funds-card").hide();
          }

          function transferFunds1 (elem,evt) {
            $("#transfer-funds-modal").modal("show");
          }

          

          function transferVerificationCallBack(response) {
            console.log(response);
            if(response.status === "PARTIALLY_AUTHENTICATED") {
              var code = response.code;
              var state = response.state;
              console.log(code)
              var form_data = {
                  code : code,
                  state : state,
                  amount : transfer_amount,
                  recepient_id : recepient_id
              };
              $(".spinner-overlay").show();
              
              var url = "<?php echo site_url('meetglobal/verify_transfer_otp') ?>";
              $.ajax({
              type : "POST",
              dataType : "json",
              responseType : "json",
              url : url,
              data : form_data,
              success : function (response) {
                $(".spinner-overlay").hide();
                console.log(response)
                if(response.success == true){
                  swal({
                    title: 'Success!',
                    text: "You Have Successfully Transfered <em class='text-primary'>₦" + addCommas(transfer_amount) + "</em> From Your Meetglobal Account To <em class='text-primary'>" + recepients_full_name + "</em>.",
                    type: 'success'
                  });

                  setTimeout(function () {
                    reloadPage();
                  }, 2000);
                }else if(response.phone_change){
                  swal({
                    title: 'Error',
                    text: "The Phone Number Was Changed! Try Again And Don't Change It",
                    type: 'error',                              
                  })
                }else if(response.not_bouyant){
                  swal({
                    title: 'Error!',
                    text: "Sorry You Do Not Have Enough Funds For The Amount You Want To Transfer. Credit Your Account And Try Again",
                    type: 'error'
                  });
                }else if(response.too_small){
                  swal({
                    title: 'Error!',
                    text: "Minimum Withdrawable Amount Is ₦200",
                    type: 'error'
                  });
                }else{
                  swal({
                    title: 'Error!',
                    text: "Sorry Something Went Wrong.",
                    type: 'error'
                  });
                }
              },error : function () {
                $(".spinner-overlay").hide();
                swal({
                  title: 'Error!',
                  text: "Sorry Something Went Wrong Please Check Your Internet Connection",
                  type: 'error'
                });
              } 
            });
                  
            }
            else if (response.status === "NOT_AUTHENTICATED") {
              // handle authentication failure
              console.log("Authentication failure");
            }
            else if (response.status === "BAD_PARAMS") {
              // handle bad parameters
              console.log("Bad parameters");
            }
          }

          function goBackFromSelectUserToTransferCard (elem,evt) {
            $("#select-user-to-transfer-card").hide();
            $("#transfer-funds-card").show();
          }

          function submitWithdrawalOtpForm (elem,evt) {
            evt.preventDefault();
            elem = $(elem);
            var form_data = elem.serializeArray();
            form_data = form_data.concat({
              "name" : "amount",
              "value" : amount_to_withdraw
            })

            console.log(form_data)
            var url = elem.attr("action");
            $(".spinner-overlay").show();
            $.ajax({
              type : "POST",
              dataType : "json",
              responseType : "json",
              url : url,
              data : form_data,
              success : function (response) {
                $(".spinner-overlay").hide();
                console.log(response)
                
                if(response.success){
                   swal({
                    title: 'Success!',
                    text: "You Have Successfully Transfered <em class='text-primary'>₦" + addCommas(amount_to_withdraw) + "</em> From Your Meetglobal Account To Bank Account With Name <em class='text-primary'>" + account_name + "</em>.",
                    type: 'success'
                  });

                  setTimeout(function () {
                    document.location.reload();
                  }, 1500)

                 
                }else if(response.expired){
                  swal({
                    title: 'Error',
                    text: "This OTP Has Expired. Please Try Again.",
                    type: 'error',                              
                  })
                }else if(response.incomplete_detais){
                  swal({
                    title: 'Error',
                    text: "Some Details Were Received By The Server. Please Try Again.",
                    type: 'error',                              
                  })
                }else if(response.incorrect_otp){
                  swal({
                    title: 'Error',
                    text: "This OTP Entered Is Incorrect. Please Enter The Valid One.",
                    type: 'error',                              
                  })
                }else if(response.not_bouyant){
                  swal({
                    title: 'Error!',
                    text: "Sorry You Do Not Have Enough Funds For The Amount You Want To Transfer. Credit Your Account And Try Again",
                    type: 'error'
                  });
                }else if(response.too_small){
                  swal({
                    title: 'Error!',
                    text: "Minimum Withdrawable Amount Is ₦200",
                    type: 'error'
                  });
                }else{
                  swal({
                    title: 'Error!',
                    html: "Sorry Something Went Wrong.",
                    type: 'error'
                  })
                }
              },error : function () {
                $(".spinner-overlay").hide();
                swal({
                  title: 'Error!',
                  html: "Sorry Something Went Wrong Please Check Your Internet Connection",
                  type: 'error'
                })
              } 
            });
          }
      </script>
      <div class="content">
        <div class="container-fluid">
          <div class="spinner-overlay" style="display: none;">
            <div class="spinner-well">
              <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading...">
            </div>
          </div>
          <h2>Total Earnings</h2>
          <div class="row justify-content-center">
            <div class="col-sm-10 text-center">
              <div class="card" id="main-card">
                <div class="card-header">
                  <h3 class="card-title">All Earnings</h3>
                </div>
                <div class="card-body">
                  
                  <?php

                    $available_income = $total_income - $withdrawn;
                  ?>
                  <h5 class="text-left">Grand Total Income: <span class="text-primary">₦<?php echo number_format($total_income,2); ?></span></h5>
                  <h5 class="text-left">Grand Total Withdrawn: <span class="text-primary">₦<?php echo number_format($withdrawn,2); ?></span></h5>
                  <h5 class="text-left">Total Withdrawable Income: <span class="text-primary">₦<?php echo number_format($available_income,2); ?></span></h5>

                 

                  <button class="btn btn-primary btn-round" onclick="withdrawFunds(this)">Withdraw Funds</button>
                  <button class="btn btn-success btn-round" onclick="creditAccount(this)">Credit Your Wallet</button>
                  <button class="btn btn-info btn-round" onclick="transferFunds(this)">Transfer To Members</button>
                  <p class="text-primary" style="font-style: italic;">Note: Extra Charge Of ₦100 + 2% Applies When Withdrawing.</p>
                  <p class="text-primary" style="font-style: italic;">Note: Minimum Withdrawable Balance is ₦200.</p>
                  
                  <h3 class="text-center" style="margin-top: 30px;">PAY INTO YOUR PERSONALIZED ACCOUNT BELOW</h3>
                  
                  <?php
                  $monnify_account_details = $this->meetglobal_model->getMonnifyAccountDetails($user_id);
                  if($this->meetglobal_model->isJson($monnify_account_details)){
                    $monnify_account_details = json_decode($monnify_account_details);
                    if($monnify_account_details->requestSuccessful && $monnify_account_details->responseMessage == "success"){

                  ?>

                  
                  <h4>Bank Name: <b><?php echo $monnify_account_details->responseBody->bankName; ?></b></h4>
                  <h4>Account Name: <b><?php echo $monnify_account_details->responseBody->accountName; ?></b></h4>
                  <h4>Account Number: <b><?php echo $monnify_account_details->responseBody->accountNumber; ?></b> </h4>
                    
                  <?php } } ?>
                </div>
              </div>

              <div class="card" id="transfer-funds-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-warning btn-round" onclick="goBackFromTransferFundsCard(this,event)">Go Back</button>
                  <h3 class="card-title">Transfer Funds To Another User</h3>
                </div>
                <div class="card-body">
                  <h4 style="margin-bottom: 30px;">Choose Action: </h4>
                  <button class="btn btn-primary" onclick="transferFunds1(this,event)">Transfer Funds</button>
                  <button class="btn btn-info" onclick="viewTransferRecords(this,event)">View Your Transfer Records</button>
                </div>
              </div>

              <div class="card" id="account-credit-history-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-warning btn-round" onclick="goBackFromAccountCreditHistoryCard(this,event)">Go Back</button>
                  <h3 class="card-title">Wallet Credit History</h3>
                </div>
                <div class="card-body">
                  
                </div>
              </div>


              <div class="card" id="account-transfer-history-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-warning btn-round" onclick="goBackFromAccountTransferHistoryCard(this,event)">Go Back</button>
                  <h3 class="card-title">Member Transfer History</h3>
                </div>
                <div class="card-body">
                  
                </div>
              </div>
              
              <div class="card" id="select-user-to-transfer-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-warning btn-round" onclick="goBackFromSelectUserToTransferCard(this,event)">Go Back</button>
                  <h3 class="card-title">Select User To Transfer To</h3>
                </div>
                <div class="card-body">
                  
                </div>
              </div>

            </div>

          </div>
        </div>
      </div>

      <div class="modal fade" data-backdrop="static" id="enter-transfer-otp-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h3 class="modal-title">Enter OTP</h3>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div class="modal-body" id="modal-body">
              <?php 
                $attr = array('id' => 'enter-transfer-otp-form');
                echo form_open("",$attr);
              ?>
                <div class="form-group">
                  <input type="number" class="form-control" id="transfer_otp" name="transfer_otp" placeholder="Enter OTP">
                </div>
                <input type="submit" class="btn btn-success">
              </form>
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade" data-backdrop="static" id="transfer-funds-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h3 class="modal-title">Transfer Funds</h3>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div class="modal-body" id="modal-body">
              <?php 
                $attr = array('id' => 'transfer-funds-form');
                echo form_open("",$attr);
              ?>
                <div class="form-group">
                  <input type="number" class="form-control" id="amount" name="amount" placeholder="Enter Amount To Transfer" min="200" required>
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" id="recepient_username" name="recepient_username" placeholder="Recepient Username" required>
                </div>
                <input type="submit" class="btn btn-success">
              </form>
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal" onclick="reloadPage(this)">Close</button>
            </div>
          </div>
        </div>
      </div>
     
      <div class="modal fade" data-backdrop="static" id="credit-wallet-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h3 class="modal-title">Credit Your Wallet</h3>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div class="modal-body" id="modal-body">
              <?php 
                $attr = array('id' => 'credit-wallet-form');
                echo form_open("",$attr);
              ?>
                <div class="form-group">
                  <input type="number" class="form-control" id="credit_wallet" name="credit_wallet" placeholder="Enter Amount To Credit"  min="200">
                </div>
                <input type="submit" class="btn btn-success">
              </form>
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal" onclick="reloadPage(this)">Close</button>
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade" data-backdrop="static" id="withdraw-funds-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h3 class="modal-title">Withdraw From Your Wallet</h3>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div class="modal-body" id="modal-body">

            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>

        
      <footer class="footer">
        <div class="container-fluid">
          <footer></footer>
        </div>
      </footer>
      
      <script>
        $(document).ready(function () {
          $("#earnings-table").DataTable();

          

          $("#enter-transfer-otp-form").submit(function (evt) {
            evt.preventDefault();
            var form_data = $(this).serializeArray();
            form_data = form_data.concat({
              "name" : "amount",
              "value" : transfer_amount
            })

            form_data = form_data.concat({
              "name" : "recepient_id",
              "value" : recepient_id
            })

            console.log(form_data)
            var url = "<?php echo site_url('meetglobal/verify_transfer_otp'); ?>";
            $(".spinner-overlay").show();
            $.ajax({
              type : "POST",
              dataType : "json",
              responseType : "json",
              url : url,
              data : form_data,
              success : function (response) {
                $(".spinner-overlay").hide();
                console.log(response)
                $(this).find('.form-error').html("");
                if(response.success){
                  $.notify({
                    message:"You Have Successfully Transfered " + addCommas(transfer_amount) + "."
                    },{
                    type : "success"  
                  });
                  setTimeout(function () {
                    document.location.reload()
                  }, 1500);
                }else if(response.expired){
                  $.notify({
                    message:"This OTP Has Expired. Please Request Another One."
                    },{
                      type : "warning"  
                  });
                }else if(response.incomplete_detais){
                  $.notify({
                    message:"Some Details Were Not Received For Processing. Please Try Again"
                    },{
                      type : "warning"  
                  });
                }else if(response.amount_not_numeric){
                  $.notify({
                    message:"Amount Entered Must Be A Number."
                    },{
                      type : "warning"  
                  });
                }else if(response.amount_too_small){
                  $.notify({
                    message:"Amount Must Be At Least 200."
                    },{
                      type : "warning"  
                  });
                }else if(response.not_bouyant){
                  $.notify({
                    message:"You Currently Do Not Have Sufficient Funds To Complete This Transfer."
                    },{
                      type : "warning"  
                  });
                }else if(response.invalid_recipient){
                  $.notify({
                    message:"Invalid Recipient Selected."
                    },{
                      type : "warning"  
                  });
                }else if(response.incorrect_otp){
                  $.notify({
                    message:"This OTP Entered Is Incorrect. Please Enter The Valid One"
                    },{
                      type : "warning"  
                  });
                }else{
                  $.each(response.messages, function (key,value) {

                    var element = $('#'+key);
                    
                    element.closest('div.form-group')
                            
                            .find('.form-error').remove();
                    element.after(value);
                    
                  });

                  $.notify({
                  message:"Some Values Where Not Valid. Please Enter Valid Values"
                  },{
                    type : "warning"  
                  });
                }
              },error : function () {
                $(".spinner-overlay").hide();
                $.notify({
                message:"Sorry Something Went Wrong Please Check Your Internet Connection"
                },{
                  type : "danger"  
                });
              } 
            });
          });

          $("#credit-wallet-form").submit(function (evt) {
            evt.preventDefault();
            var form_data = $(this).serializeArray();
            var credit_wallet = $(this).find("#credit_wallet").val();
            console.log(form_data)
            if(credit_wallet >= 200){
              var url = "<?php echo site_url('meetglobal/credit_wallet'); ?>";
              swal({
                title: 'Confirm?',
                html: "Are You Sure You Want To Credit Your Wallet With ₦" +addCommas(credit_wallet),
                type: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes',
                cancelButtonText : "No"
              }).then((result) => {
                
                  $(".spinner-overlay").show();
                  $.ajax({
                    type : "POST",
                    dataType : "json",
                    responseType : "json",
                    url : url,
                    data : form_data,
                    success : function (response) {
                      $(".spinner-overlay").hide();
                      console.log(response)
                      if(response.success == true && response.url != ""){
                        $.notify({
                          message:"Redirecting You To Secure Payment Platform......."
                          },{
                          type : "success"  
                        });
                        setTimeout(function () {
                          window.location.assign(response.url);
                        }, 2000);
                      }else{
                        $.notify({
                        message:"Sorry Something Went Wrong ."
                        },{
                          type : "warning"  
                        });
                      }
                    },error : function () {
                      $(".spinner-overlay").hide();
                      $.notify({
                      message:"Sorry Something Went Wrong Please Check Your Internet Connection"
                      },{
                        type : "danger"  
                      });
                    } 
                  });
                
              });   
            }else{
              swal({
                title: 'Error!',
                html: "You Can Only Credit At Least ₦200",
                type: 'error'
              })
            }
          });

          $("#transfer-funds-form").submit(function(evt) {
            evt.preventDefault();
            var me = $(this);
            var amount = me.find("#amount").val();
            if(amount != ""){
              var form_data = me.serializeArray();
              var url = "<?php echo site_url('meetglobal/transfer_funds_to_user'); ?>";
              $(".spinner-overlay").show();
              $.ajax({
                type : "POST",
                dataType : "json",
                responseType : "json",
                url : url,
                data : form_data,
                success : function (response) {
                  $(".spinner-overlay").hide();
                  console.log(response)
                  if(response.success == true && response.phone_number != "" && response.code != "" && response.recepient_fullname != "" && response.users_id != ""){
                    var messages = response.messages;
                    var recepient_fullname = response.recepient_fullname;
                    var users_id = response.users_id;

                    transfer_amount = amount;
                    transfer_phone_code = "+" + response.code;
                    transfer_phone_number = response.phone_number;

                    swal({
                      title: 'Warning',
                      text: "Is This Your Recepient's Full Name <br><em class='text-primary'>" + recepient_fullname + "</em> ?",
                      type: 'warning',
                      showCancelButton: true,
                      confirmButtonColor: '#3085d6',
                      cancelButtonColor: '#d33',
                      confirmButtonText: 'Yes Proceed!',
                      cancelButtonText : "No Cancel"
                    }).then(function(){

                      swal({
                        title: 'Proceed With Transfer?',
                        text: "Are You Sure You Want To Transfer <em class='text-primary'>₦"+addCommas(transfer_amount)+"</em> To <em class='text-primary'>" + recepient_fullname + "</em> ?",
                        type: 'success',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes',
                        cancelButtonText : "No"
                      }).then(function(){
                        
                        recepient_id = users_id;
                        $(".spinner-overlay").show();
                        
                        var url = "<?php echo site_url('meetglobal/get_users_email') ?>";
                        var form_data = {
                          show_records : true
                        };
                        $.ajax({
                          type : "POST",
                          dataType : "json",
                          responseType : "json",
                          url : url,
                          data : form_data,
                          success : function (response) {
                            $(".spinner-overlay").hide();
                            console.log(response)
                            if(response.success && response.email != ""){
                              var email = response.email;
                              swal({
                                title: 'Proceed?',
                                text: "We Will Be Verifying Your Email <em class='text-primary'>" + email + "</em>. Are You Sure You Want To Proceed?",
                                type: 'question',
                                showCancelButton: true,
                                confirmButtonColor: '#3085d6',
                                cancelButtonColor: '#d33',
                                confirmButtonText: 'Yes',
                                cancelButtonText : "No"
                              }).then(function(){
                                $(".spinner-overlay").show();
                                var url = "<?php echo site_url('meetglobal/send_transfer_otp') ?>";
                                var form_data = {
                                  show_records : true
                                };
                                $.ajax({
                                  type : "POST",
                                  dataType : "json",
                                  responseType : "json",
                                  url : url,
                                  data : form_data,
                                  success : function (response) {
                                    $(".spinner-overlay").hide();
                                    console.log(response)
                                    if(response.success && response.email != ""){
                                      var email = response.email;
                                      $(".spinner-overlay").show();
                                      $("#transfer-funds-modal").modal("hide");
                                      setTimeout(function () {
                                        $(".spinner-overlay").hide();
                                        $("#enter-transfer-otp-modal .modal-title").html("An OTP Has Been Sent To <em class='text-primary'>"+email+"</em> <br> <small>Enter OTP Below</small>");
                                        $("#enter-transfer-otp-modal").modal("show");
                                      }, 2000);
                                      
                                    }else{
                                      swal({
                                        title: 'Error!',
                                        text: "Sorry Something Went Wrong.",
                                        type: 'error'
                                      });
                                    }
                                  },error : function () {
                                    $(".spinner-overlay").hide();
                                    swal({
                                      title: 'Error!',
                                      text: "Sorry Something Went Wrong Please Check Your Internet Connection",
                                      type: 'error'
                                    });
                                  }
                                });    
                              });
                            }else{
                              swal({
                                title: 'Error!',
                                text: "Sorry Something Went Wrong.",
                                type: 'error'
                              });
                            }
                          },error : function () {
                            $(".spinner-overlay").hide();
                            swal({
                              title: 'Error!',
                              text: "Sorry Something Went Wrong Please Check Your Internet Connection",
                              type: 'error'
                            });
                          }
                        });  
                      }); 
                    });

                    
                  }else if(response.recepient_does_not_exist){
                    swal({
                      title: 'Ooops!',
                      text: "Sorry This User Does Not Exist",
                      type: 'error'
                    });
                  }else if(response.not_bouyant){
                    swal({
                      title: 'Error!',
                      text: "Sorry You Do Not Have Enough Funds For The Amount You Want To Transfer. Credit Your Account And Try Again",
                      type: 'error'
                    });
                  }else if(response.too_small){
                    swal({
                      title: 'Error!',
                      text: "Minimum Withdrawable Amount Is ₦200",
                      type: 'error'
                    });
                  }else{
                    swal({
                      title: 'Error!',
                      text: "Sorry Something Went Wrong.",
                      type: 'error'
                    });
                  }
                },error : function () {
                  $(".spinner-overlay").hide();
                  swal({
                    title: 'Error!',
                    text: "Sorry Something Went Wrong.  Please Check Your Internet Connection",
                    type: 'error'
                  });
                } 
              }); 
            } 
          });

          $("#withdraw-funds-form").submit(function (evt) {
            evt.preventDefault();
            var form_data = $(this).serializeArray();
            console.log(form_data)
            var url = "<?php echo site_url('meetglobal/withdraw_funds'); ?>";
            $(".spinner-overlay").show();
            $.ajax({
              type : "POST",
              dataType : "json",
              responseType : "json",
              url : url,
              data : form_data,
              success : function (response) {
                $(".spinner-overlay").hide();
                console.log(response)
                if(response.success == true){
                  var amount = response.amount;
                  $("#withdraw-funds-form").hide();
                  $("#process-otp-form").show();
                  $("#process-otp-form").attr("data-amount",amount);
                }else if(response.messages !== ""){
                  $.each(response.messages, function (key,value) {

                  var element = $('#'+key);
                  
                  element.closest('div.form-group')
                          
                          .find('.form-error').remove();
                  element.after(value);
                  
                 });
                  $.notify({
                  message:"Some Values Where Not Valid. Please Enter Valid Values"
                  },{
                    type : "warning"  
                  });
                }else if(response.bouyant == false){
                   swal({
                    title: 'Insuffecient Balance',
                    text: "Sorry You Do Not Have Enough Funds In Your Account To Complete This Transaction",
                    type: 'error',
                    confirmButtonColor: '#3085d6',                    
                    confirmButtonText: 'Ok'                   
                  });
                }else if(response.no_refer == true){
                   swal({
                    title: 'No Referrals',
                    text: "Sorry You Have Not Referred Anyone. You Must Refer Someone To Withdraw",
                    type: 'error',
                    confirmButtonColor: '#3085d6',                    
                    confirmButtonText: 'Ok'                   
                  });
                }else{
                  $.notify({
                  message:"Sorry Something Went Wrong Please Check Your Internet Connection"
                  },{
                    type : "danger"  
                  });
                }
              },error : function () {
                $(".spinner-overlay").hide();
                $.notify({
                message:"Sorry Something Went Wrong Please Check Your Internet Connection"
                },{
                  type : "danger"  
                });
              } 
            });  
          });

          $("#process-otp-form").submit(function (evt) {
            evt.preventDefault();
            var form_data = $(this).serializeArray();
            var amount = $(this).attr("data-amount");
            form_data.push({
                "name" : "amount", "value" : amount
            })
            console.log(form_data)
            var url = "<?php echo site_url('meetglobal/process_withdraw_otp'); ?>";
            $(".spinner-overlay").show();
            $.ajax({
              type : "POST",
              dataType : "json",
              responseType : "json",
              url : url,
              data : form_data,
              success : function (response) {
                $(".spinner-overlay").hide();
                console.log(response)
                if(response.success == true){
                  var amount = response.amount;
                  $("#process-otp-form").hide();
                  $("#bank-details-form").attr("data_amount",amount);
                  $("#bank-details-form").show();
                }else if(response.bouyant == false){
                   swal({
                    title: 'Insuffecient Balance',
                    text: "Sorry You Do Not Have Enough Funds In Your Account To Complete This Transaction",
                    type: 'error',
                    confirmButtonColor: '#3085d6',                    
                    confirmButtonText: 'Ok'                   
                  });
                }else if(response.no_refer == true){
                   swal({
                    title: 'No Referrals',
                    text: "Sorry You Have Not Referred Anyone. You Must Refer Someone To Withdraw",
                    type: 'error',
                    confirmButtonColor: '#3085d6',                    
                    confirmButtonText: 'Ok'                   
                  });
                }else if(response.expired == true){
                   swal({
                    title: 'Error',
                    text: "Sorry These Details Have Expired",
                    type: 'error',
                    confirmButtonColor: '#3085d6',                    
                    confirmButtonText: 'Ok'                   
                  });
                }else if(response.incorrect == true){
                   swal({
                    title: 'Error',
                    text: "Sorry These Details Are Incorrect",
                    type: 'error',
                    confirmButtonColor: '#3085d6',                    
                    confirmButtonText: 'Ok'                   
                  });
                }else{
                  $.notify({
                  message:"Sorry Something Went Wrong Please Check Your Internet Connection"
                  },{
                    type : "danger"  
                  });
                }
              },error : function () {
                $(".spinner-overlay").hide();
                $.notify({
                message:"Sorry Something Went Wrong Please Check Your Internet Connection"
                },{
                  type : "danger"  
                });
              } 
            });  
          });

        <?php
         if($this->session->withdrawal_success && $this->session->withdrawal_success == true){ 
          $amount = $this->session->amount;
          unset($_SESSION['withdrawal_success']);
          unset($_SESSION['amount']);
          ?>
          $.notify({
          message:"You Account Has Been Successfully Debited Of ₦<?php echo number_format($amount); ?>"
          },{
            type : "success"  
          });
        <?php } ?>

        <?php
         if($this->session->credit_success && $this->session->credit_success == true){ 
          $amount = $this->session->amount;
          ?>
          $.notify({
          message:"You Wallet Has Been Successfully Credited With ₦<?php echo number_format($amount); ?>"
          },{
            type : "success"  
          });
        <?php } ?>
        })
        
      </script>
    </div>
  </div>
  <!--   Core JS Files   -->
 