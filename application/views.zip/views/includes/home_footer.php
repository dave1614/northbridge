<footer id="main-page-footer">
    <div class="row">
      <div class="col-sm-6 contact-us-div">
        <h4 class="contact-us-heading">Contact Us</h4>
        <p class="contact-us-detail-p"><i class="fas fa-map-marker-alt address-icon"></i>&nbsp;&nbsp; <span class="address-text">12, Adeola Adewale street, Off Shau kumesi street akesan. By LASU RD, Igando. Lagos</span></p>
        <p class="contact-us-detail-p"><i class="fas fa-envelope address-icon"></i>&nbsp;&nbsp; <span class="address-text">info@sabicapital.com</span></p>
        <p class="contact-us-detail-p" style="margin-bottom: 40px;"><i class="fas fa-phone address-icon"></i>&nbsp;&nbsp; <span class="address-text">0815 726 9196,0706 584 3465</span></p>
      </div>

      <div class="col-sm-6 social-media-div">
        <h4 class="social-media-heading">Connect With Us On Social</h4>
        <a target="_blank" href="https://facebook.com/Sabi-Capital-109273317521172/"><img src="<?php echo base_url('assets/images/facebook.svg') ?>" alt=""></a>
        
        <a target="_blank" href="https://instagram.com/sabicapitalng"><img style="background: transparent;" src="<?php echo base_url('assets/images/instagram-sketched.svg') ?>" alt=""></a>
        
        <a target="_blank" href="https://chat.whatsapp.com/K9kKOgXwgg322X1P7qA6aW"><img style="background: transparent;" src="<?php echo base_url('assets/images/whatsapp.svg') ?>" alt=""></a>
        <a target="_blank" href="mailto: info@sabicapital.com"><img style="background: transparent;" src="<?php echo base_url('assets/images/email.svg') ?>" alt=""></a>
        <a title="12, Adeola Adewale street, Off Shau kumesi street akesan. By LASU RD, Igando. Lagos" target="_blank" href="http://www.google.com/maps/place/6.543338, 3.227609"><img style="background: transparent;" src="<?php echo base_url('assets/images/location.svg') ?>" alt=""></a>
      
      </div>
      
    </div>

    <div class="divider" style="background: #fff;"></div>

    <div class="warning-div">
      <h4 class="warning-heading text-center">Warning</h4>
      <p class="warning-text text-center">Foreign Exchange Trading and Investment in derivatives can be very speculative and may result in losses as well as profits. Foreign Exchange and Derivatives Trading is not suitable for everyone and only risk capital should be applied. Sabi Capital do not take into account special investment goals, the financial institution or specific requirements of individual users. Sabi Capital or any staff will not accept liability for any loss or damage, including without limitation to, any loss of profit, which may arise directly or indirectly from use of or reliance on information contained on this site or in your trading. You should carefully consider your financial situation and consult your financial advisors as to the suitability to your situation prior making any investment or entering into any transactions.</p>
    </div>

    <p class="text-center">&copy; <?php echo date("Y"); ?>, All rights reserved. Sabi Capital Ltd. &reg;</p>
    
  </footer>



  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  <script src="<?php echo base_url('assets/js/bootstrap-notify.js')?> "></script>
  <script src="<?php echo base_url('assets/js/sweetalert2.all.min.js') ?>"></script>
  <script src="<?php echo base_url('assets/js/sweetalert2.min.js') ?>"></script>
  <script src="<?php echo base_url('assets/js/swal-forms.js') ?>"></script>
  <script src="<?php echo base_url('assets/js/owl.carousel.min.js'); ?>"></script>
  <script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap4.min.js"></script>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ef0cfbe4a7c6258179b1dc4/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

  <script>
    $(document).ready(function () {

      $('[rel=tooltip]').tooltip();

      var owl = $('.owl-carousel');
      owl.owlCarousel({
          items:1,
          loop:true,
          margin:10,
          autoplay:true,
          autoplayTimeout:5000,
          autoplayHoverPause:true,
          // singleItem:true
      });
      // $('.play').on('click',function(){
      //     owl.trigger('play.owl.autoplay',[1000])
      // })
      // $('.stop').on('click',function(){
      //     owl.trigger('stop.owl.autoplay')
      // })

      $("#send-message-form").submit(function(evt) {
        evt.preventDefault();
        var me = $(this);
        var form_data = $(this).serializeArray();
        var url = $(this).attr("action");
        var submit_btn1 = $(this).find("button");
        var submit_btn_spinner1 = $(this).find(".spinner");
        submit_btn1.addClass('disabled');
        submit_btn_spinner1.show();
        $.ajax({
            url : url,
            type : "POST",
            responseType : "json",
            dataType : "json",
            data : form_data,
            success : function (response) {
              submit_btn_spinner1.hide();
              submit_btn1.removeClass("disabled");
              console.log(response)
              if(response.success){
                me.find("input").val("");
                me.find("textarea").val("");
                me.find("form-error").html("");
                $.notify({
                  message:"Message Sent Successfully."
                  },{
                    type : "success"  
                });
              }else{
                $.each(response.messages, function (key,value) {

                  var element = $('#'+key);
                  
                  element.closest('div.form-group')
                          
                          .find('.form-error').remove();
                  element.after(value);
                  
                 });
                $.notify({
                  message:"Sorry Something Went Wrong."
                  },{
                    type : "warning"  
                });
              }
            },error : function (jqXHR,error, errorThrown) {
              submit_btn_spinner1.hide();
              submit_btn1.removeClass("disabled");
              $.notify({
              message:"Sorry Something Went Wrong."
              },{
                type : "danger"  
              });
            }
        });  
      });
      // showLogInModal();
      
    })

   
  </script>
  
</body>

</html>